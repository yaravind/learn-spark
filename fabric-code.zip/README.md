# tccc-fabric-data-utils

Reusable utilities for Azure Data Services (ADLS, Synapse Spark, Fabric etc.)

## Setup

### Maven

- Install Java version1.8.0_350 or more
- [Install Maven](https://maven.apache.org/install.html)
- [Eclipse and IntelliJ IDE Integration](https://maven.apache.org/ide.html)

### Fabric Runtime

#### 1.3

* Apache Spark 3.5
* Operating System: Mariner 2.0
* Java: 11
* Scala: 2.12.17
* Python: 3.11
* Delta Lake: 3.2
* R: 4.4.1

## Deployment

`Metadata` feature requires following jars to be added as packages to Spark pool.

```
parquet-tools-1.11.2.jar
parquet-hadoop-1.11.2.jar
Future: parquet-hadoop-1.12.2.jar
```

```
<groupId>org.apache.parquet</groupId>
<artifactId>parquet-hadoop</artifactId>
<version>1.12.2</version>

<groupId>org.apache.parquet</groupId>
<artifactId>parquet-tools</artifactId>
<version>1.11.2</version>
```

## Structure

### Packaging Convention

#### Maven

- Group ID: `com.tccc.dna.<team/org/OU name>`
- Packages/Namespaces
    - `com.tccc.dna`
        - com.tccc.dna.`<function>` E.g. com.tccc.dna.`supplychain`
            - com.tccc.dna.<function>.`<subject-area>` E.g. com.tccc.dna.supplychain.`custsats`
                - com.tccc.dna.<function>.<subject-area>.`<domain/business process>.<sub-domain>`

#### Functions

| Name                                 | Package Name                |
|--------------------------------------|-----------------------------|
| Finance & Strategy                   | `finance`                   |
| Technical, Innovation & Supply Chain | `supplychain`, `innovation` | 
| Marketing                            | `marketing`                 |
| Food Service on Premise              | `fsop`                      |
| Human Resources/People               | `hr`                        |
| Customer and Commercial              | `commercial`, `customer`    |

#### Business Processes

| Name                   | Package Name |
|------------------------|--------------|
| Master Data Management | `mdm`        |
| Order to Cash          | `o2c`        |
| Procure to Pay         | `p2p`        |
| Record to Report       | `r2r`        |
| Forecast to Deploy     | `f2d`        |
| IT Service Management  | `itsm`       |

## Synapse Spark Configuration and Dependencies (As of Nov, 2023)

| Config                          | 3.4.1.5.3-121327941                                                                                                   | 3.3.1.5.2-108696741                                                                            | 3.2.2     |
|---------------------------------|-----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------|-----------|
| Delta version                   | 2.4.0.9                                                                                                               | 2.2.0.9                                                                                        | 1.2       |
| Scala version                   | 2.12.17                                                                                                               | 2.12.15                                                                                        | 2.12.15   | 
| Java version                    | 11.0.22                                                                                                               | 1.8.0_382                                                                                      | 1.8.0_282 |
| Python version                  | 3.10.12, packaged by conda-forge                                                                                      | 3.10                                                                                           | 3.8       |
| JRE name                        | OpenJDK Runtime Environment                                                                                           | OpenJDK Runtime Environment                                                                    |           |
| JRE version                     | 11.0.22+7-LTS                                                                                                         | 1.8.0_382-8u382-ga-1~18.04.1-b05                                                               |           |
| Metastore version               | 2.3.2                                                                                                                 | 2.3.2                                                                                          |           |
| Catalog/Metastore type          | hive                                                                                                                  | hive                                                                                           |           |
| Spark warehouse location        | abfss://xxx-xxx-bbxxx@spark4triprodncus.dfs.core.windows.net/synapse/workspaces/70dynamicdatacloudworkspace/warehouse | abfss://default@storageacct.dfs.core.windows.net/synapse/workspaces/syn-wkscp-dev-01/warehouse |           |
| java.vendor                     | Microsoft                                                                                                             | Private Build                                                                                  |           |
| java.home                       | /usr/lib/jvm/msopenjdk-11                                                                                             | /usr/lib/jvm/java-8-openjdk-amd64/jre                                                          |           |
| user.timezone                   | UTC                                                                                                                   | Etc/UTC                                                                                        |           |
| os.namev Linux                  | Linux                                                                                                                 |                                                                                                |
| spark.sql.session.timeZone      | **Not Available**                                                                                                     | **Not Available**                                                                              |           |
| spark.sql.catalog.spark_catalog | org.apache.spark.sql.delta.catalog.DeltaCatalog                                                                       | org.apache.spark.sql.delta.catalog.DeltaCatalog                                                |           |

#### Older versions

* Apache Spark Version: **3.2.2**
    * Scala Version: 2.12.15
    * Java Version: 1.8.0_282
    * Delta Lake Version: 1.2
    * Python Version: 3.8
* Apache Spark Version: **3.3**
    * Scala Version: 2.12.15
    * Java Version: 1.8.0_282
    * Delta Lake Version: 2.2
    * Python Version: 3.10

### Configuration

#### SQL

* spark.sql.autoBroadcastJoinThreshold = 26214400
* spark.sql.bnlj.codegen.enabled = true
* spark.sql.cardinalityEstimation.enabled = true
* spark.sql.catalog.spark_catalog = org.apache.spark.sql.delta.catalog.DeltaCatalog
* spark.sql.catalogImplementation = hive
* spark.sql.cbo.enabled = true
* spark.sql.cbo.joinReorder.enabled = true
* spark.sql.convertInnerJoinToLeftSemiJoin = true
* spark.sql.crossJoin.enabled = true
* spark.sql.decimalDivision.optimizationEnabled = true
* spark.sql.dpp.size.estimate = true
* spark.sql.exchange.reuse.correction.enabled = true
* spark.sql.execution.arrow.pyspark.enabled = true
* spark.sql.execution.arrow.pyspark.fallback.enabled = true
* spark.sql.execution.collapseAggregateNodes = true
* spark.sql.execution.pyspark.udf.simplifiedTraceback.enabled = true
* spark.sql.extensions =
  com.microsoft.vegas.common.VegasExtensionBuilder,com.microsoft.peregrine.spark.extensions.SparkExtensionsSynapse,io.delta.sql.DeltaSparkSessionExtension,com.microsoft.azure.synapse.ml.predict.SynapsePredictExtensions
* spark.sql.files.maxPartitionBytes = 134217728
* spark.sql.hint.error.handler = org.apache.spark.sql.advise.HintErrorAdvisorHandler
* spark.sql.hive.convertMetastoreOrc = true
* spark.sql.hive.metastore.jars = /opt/hive-metastore/lib/*
* spark.sql.hive.metastore.version = 2.3.2
* spark.sql.joinConditionReorder.enabled = true
* spark.sql.legacy.replaceDatabricksSparkAvro.enabled = false
* spark.sql.local.window.optimization.enabled = true
* spark.sql.normalize.aggregate.enabled = false
* spark.sql.optimizer.dynamicPartitionPruning.reuseBroadcastOnly = false
* spark.sql.optimizer.runtime.bloomFilter.enabled = true
* spark.sql.orc.filterPushdown = true
* spark.sql.orc.impl = native
* spark.sql.parquet.footerCache.size = 1000
* spark.sql.preaggregation.enabled = true
* spark.sql.preaggregation.partition.key.based.stats.enabled = true
* spark.sql.preaggregation.pushdown.below.union.enabled = true
* spark.sql.pruneFileSourcePartitions.enableStats = true
* spark.sql.pushdown.project.below.expand.enabled = true
* spark.sql.sizeBasedJoinReorder.enabled = true
* spark.sql.smart.shuffle.enabled = true
* spark.sql.sources.parallelPartitionDiscovery.parallelism = 200
* spark.sql.spark.cluster.type = synapse
* spark.sql.statistics.fallBackToHdfs = true
* spark.sql.use.codegen.for.window.functions = true
* spark.sql.use.rollup.aggregate = true
* spark.sql.warehouse.dir = abfss:
  //default@storagemai01us2dev.dfs.core.windows.net/synapse/workspaces/syn-tccc-udp-mai-us2-dev-01/warehouse
* spark.sql.window.sort.optimization.enabled = true
* spark.sqlanalyticsconnector.stagingdir.prefix = abfss:
  //default@storagemai01us2dev.dfs.core.windows.net/synapse/workspaces/syn-tccc-udp-mai-us2-dev-01/sparkpools/histsparkpool/sparkpoolinstances/e0bc893b-04ed-4eff-9550-e6c4c599ce77/livysessions/2023/11/21/3/tempdata/

#### Delta

* spark.databricks.delta.vacuum.parallelDelete.enabled = true
* spark.delta.logStore.class = org.apache.spark.sql.delta.storage.AzureLogStore
* spark.microsoft.delta.merge.lowShuffle.enabled = true
* spark.microsoft.delta.optimizeWrite.partitioned.enabled = true

#### AQE

* spark.sql.adaptive.enabled (When true, re-optimizes the query plan in the middle of query execution, based on accurate
  runtime statistics) = true
* spark.sql.adaptive.forceOptimizeSkewedJoin = Some(false)

#### CSV

* spark.sql.csv.filterPushdown.enabled (When true, enable filter pushdown to CSV datasource.) = true

#### JSON

* spark.sql.json.filterPushdown.enabled = true

#### Parquet

* spark.sql.parquet.aggregatePushdown = Some(false)
* spark.sql.parquet.filterPushdown = true
* spark.sql.parquet.outputTimestampType = INT96
* spark.sql.parquet.recordLevelFilter.enabled = false

#### SQL DML/DDL

* spark.sql.charAsVarchar = Some(false)
* spark.sql.groupByAliases (When true, aliases in a select list can be used in group by clauses. When false, an analysis
  exception is thrown in the case.) =
  true
* spark.sql.groupByOrdinal = true

#### Maven

* spark.sql.maven.additionalRemoteRepositories = https://maven-central.storage-download.googleapis.com/maven2/

#### Task

* spark.task.cpus (The number of CPU cores to schedule (allocate) to a task) = None
* spark.task.maxFailures (Number of failures of a single task (of a TaskSet) before giving up on the entire TaskSet and
  then the job) = None

#### Memory

* spark.memory.fraction (Fraction of JVM heap space used for execution and storage) = None
* spark.memory.offHeap.enabled (Controls whether Tungsten memory will be allocated on the JVM heap (false) or
  off-heap) = None
* spark.memory.offHeap.size (Maximum memory (in bytes) for off-heap memory allocation) = None

#### Shuffle

* spark.sql.shuffle.partitions = 200
* spark.shuffle.compress (Controls whether to compress shuffle output when stored) = None
* spark.shuffle.manager = None
* spark.plugins (A comma-separated list of class names implementing org.apache.spark.api.plugin.SparkPlugin to load into
  a Spark application.) = None

#### Driver

* spark.driver.log.dfsDir = None

#### Other

* spark.sql.defaultCatalog = spark_catalog
* spark.sql.ansi.enabled = false
* spark.sql.columnNameOfCorruptRecord (The name of internal column for storing raw/un-parsed JSON and CSV records that
  fail to parse.) = _corrupt_record
* spark.default.parallelism (Default number of partitions in RDDs returned by transformations like join, reduceByKey,
  and parallelize) = None
* spark.sql.leafNodeDefaultParallelism = null
* spark.sql.sources.default = parquet
* spark.sql.files.maxRecordsPerFile (Maximum number of records to write out to a single file. If this value is zero or
  negative, there is no limit.) = 0
* spark.sql.files.minPartitionNum = null

#### Resource manager

* spark.master = yarn
* spark.yarn.maxAppAttempts = 1
* spark.yarn.queue = default

### Dependencies (Provided)

#### Jackson

- file:/usr/hdp/5.2-108696741/spark3/jars/jackson-core-2.13.4.jar
- file:/usr/hdp/5.2-108696741/spark3/jars/jackson-module-scala_2.12-2.13.4.jar
- file:/usr/hdp/5.2-108696741/spark3/jars/json4s-jackson_2.12-3.7.0-M11.jar
- file:/usr/hdp/5.2-108696741/spark3/jars/parquet-jackson-1.12.3.jar
- file:/usr/hdp/5.2-108696741/spark3/jars/jackson-dataformat-cbor-2.13.4.jar
- file:/usr/hdp/5.2-108696741/spark3/jars/jackson-core-asl-1.9.13.jar
- file:/usr/hdp/5.2-108696741/spark3/jars/jackson-databind-2.13.4.1.jar
- file:/usr/hdp/5.2-108696741/spark3/jars/jackson-annotations-2.13.4.jar
- file:/usr/hdp/5.2-108696741/spark3/jars/jackson-mapper-asl-1.9.13.jar

#### Guava & Commons

* file:/usr/hdp/5.2-108696741/spark3/jars/hadoop-shaded-guava-1.1.1.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/guava-14.0.1.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/istack-commons-runtime-3.0.8.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-text-1.10.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-codec-1.15.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-cli-1.5.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-collections-3.2.2.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-collections4-4.4.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-dbcp-1.4.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-pool2-2.11.1.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-crypto-1.1.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-compiler-3.0.16.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-lang-2.6.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-logging-1.1.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-math3-3.6.1.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/junit-platform-commons-1.5.2.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-io-2.11.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-lang3-3.12.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-compress-1.21.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/commons-pool-1.5.4.jar

#### Synapse

* file:/usr/hdp/5.2-108696741/spark3/jars/azure-synapse-ml-pandas_2.12-0.1.1.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/synapseml-deep-learning_2.12-0.11.3-spark3.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/spark-kusto-synapse-connector_3.1_2.12-1.3.4.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/synapseml-opencv_2.12-0.11.3-spark3.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/synapseml-internal_2.12-0.11.3.2-spark3.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/synapseml-cognitive_2.12-0.11.3-spark3.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/synapseml-vw_2.12-0.11.3-spark3.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/synapseml-core_2.12-0.11.3-spark3.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/azure-synapse-ml-predict_2.12-1.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/synapseml_2.12-0.11.3-spark3.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/synapseml-lightgbm_2.12-0.11.3-spark3.3.jar

#### Azure

* file:/usr/lib/library-manager/bin/libraries/scala/tccc-fabric-data-utils-1.0-SNAPSHOT.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/azure-synapse-ml-pandas_2.12-0.1.1.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/azure-eventhubs-spark_2.12-2.3.22.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/azure-storage-7.0.1.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/hadoop-azure-datalake-3.3.3.5.2-108696741.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/azure-data-lake-store-sdk-2.3.9.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/hadoop-azure-3.3.3.5.2-108696741.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/azure-eventhubs-3.3.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/azure-synapse-ml-predict_2.12-1.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/azure-keyvault-core-1.0.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/hadoop-azureml-1.0-fs.jar

#### Azure Connectors

* file:/usr/hdp/5.2-108696741/spark3/jars/sparklyr-connector-1.0.0_spark-3.3.1.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/spark-kusto-synapse-connector_3.1_2.12-1.3.4.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/sqlanalyticsconnector-3.3.0-2.1.2.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/cosmos-analytics-spark-3.3.1-connector-1.8.10.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/spark-cdm-connector-assembly-spark3.3-1.19.5.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/mysql-connector-java-8.0.18.jar

#### Microsoft

* file:/usr/hdp/5.2-108696741/spark3/jars/microsoft-log4j-etwappender-1.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/spark-microsoft-tools_2.12-3.3.1.5.2-108696741.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/microsoft-catalog-metastore-client-1.1.14.jar

#### Parquet

* file:/usr/hdp/5.2-108696741/spark3/jars/parquet-format-structures-1.12.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/parquet-column-1.12.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/sparknativeparquetwriter_2.12-0.8.1-spark-3.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/parquet-common-1.12.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/parquet-encoding-1.12.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/parquet-jackson-1.12.3.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/parquet-hadoop-1.12.3.jar

#### Delta

* file:/usr/hdp/5.2-108696741/spark3/jars/delta-storage-2.2.0.9.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/delta-iceberg_2.12-2.2.0.9.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/delta-core_2.12-2.2.0.9.jar

#### Joda

* file:/usr/hdp/5.2-108696741/spark3/jars/joda-time-2.10.13.jar

#### Scala

* file:/usr/hdp/5.2-108696741/spark3/jars/scala-parser-combinators_2.12-1.1.2.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/jackson-module-scala_2.12-2.13.4.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/scala-reflect-2.12.15.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/scala-library-2.12.15.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/scalactic_2.12-3.2.14.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/scala-xml_2.12-1.2.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/scala-java8-compat_2.12-0.9.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/scala-collection-compat_2.12-2.1.1.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/scala-compiler-2.12.15.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/json4s-scalap_2.12-3.7.0-M11.jar

#### Log4J and Slf4J

* file:/usr/hdp/5.2-108696741/spark3/jars/microsoft-log4j-etwappender-1.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/log4j-api-2.17.2.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/log4j-core-2.17.2.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/log4j-slf4j-impl-2.17.2.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/log4j-1.2-api-2.17.2.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/slf4j-api-1.7.32.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/jcl-over-slf4j-1.7.32.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/jul-to-slf4j-1.7.32.jar

#### Spire

* file:/usr/hdp/5.2-108696741/spark3/jars/spire-util_2.12-0.17.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/spire_2.12-0.17.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/spire-macros_2.12-0.17.0.jar
* file:/usr/hdp/5.2-108696741/spark3/jars/spire-platform_2.12-0.17.0.jar