package com.tccc.dna

import org.scalatest.funsuite.AnyFunSuite
import com.tccc.dna.TextDiffColorizer._

class TextDiffColorizerTest extends AnyFunSuite {
  test("printDiff") {
    TextDiffColorizer.printDiff("apple", "appieot", LIGHT_YELLOW)
    TextDiffColorizer.printDiff("apple", "appieot", LIGHT_GREEN)
    TextDiffColorizer.printDiff("apple", "appieot", LIGHT_RED)
    TextDiffColorizer.printDiff("apple", "appieot", LIGHT_CYAN)
    TextDiffColorizer.printDiff("apple", "appieot", LIGHT_MAGENTA)
  }

  test("printPositionalDiff") {
    TextDiffColorizer.printPositionalDiff("apple", "apprecot")
  }
}
