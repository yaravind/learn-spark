package com.tccc.dna.datacontract

import com.fasterxml.jackson.databind.JsonNode
import com.github.fge.jackson.JsonLoader
import com.github.fge.jsonschema.main.{JsonSchemaFactory, JsonValidator}
import com.google.common.io.Resources
import org.apache.spark.sql.types.{ArrayType, BooleanType, IntegerType, StringType, StructField, StructType}
import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.should.Matchers

import java.nio.charset.Charset

/**
 * TODO assert terms, servers, schema and examples object properties
 */
class JsonSchemaValidatorTest extends AnyFunSuite with Matchers {
  val dataContract: Map[String, Any] = DataContractYAMLFactory.parseFromString(Resources.toString(Resources.getResource("contracts/datacontract.yaml"), Charset.forName("UTF-8")))
  val schema: String = DataContractYAMLFactory.getSchemaSpecification(DataContractYAMLFactory.getSchemaObject(dataContract))

  //Initialize the validator and create schema instance once per partition
  val jsonSchemaNode: JsonNode = JsonLoader.fromString(schema)
  val validator: JsonValidator = JsonSchemaFactory.byDefault.getValidator

  test("validateOptimized function should return isValid == true for valid json instance") {
    assert(dataContract != null)
    dataContract should have size 7

    val jsonInstanceStr = getSchemaAsString("contracts/asset_created.json")
    val result = JsonSchemaValidator.validateOptimized(validator, jsonSchemaNode, jsonInstanceStr)

    assert(result.isValid)
  }

  test("DataContractYAMLFactory.getJsonSchemaAsStr") {
    val jsonSchemaAsStr: String =
      DataContractYAMLFactory.getJsonSchemaAsStr(
        "contracts/datacontract.yaml"
      )
    assert(jsonSchemaAsStr != null)
    assert(jsonSchemaAsStr.length > 1)
  }

  test("validateOptimized function should return isValid == false for invalid json instance") {
    assert(dataContract != null)
    dataContract should have size 7

    val jsonInstanceStr = getSchemaAsString("contracts/asset_created_invalid.json")
    val result = JsonSchemaValidator.validateOptimized(validator, jsonSchemaNode, jsonInstanceStr)

    assert(!result.isValid)
    assert(result.inputJson == jsonInstanceStr)
    assert(result.errorCount == 1)
    assert(result.errorList.size == 1)
  }

  test("validateOptimized function should return isValid == false for syntax errors in json instance") {
    assert(dataContract != null)
    dataContract should have size 7

    val jsonInstanceStr = getSchemaAsString("contracts/syntax_error.json")
    val result = JsonSchemaValidator.validateOptimized(validator, jsonSchemaNode, jsonInstanceStr)
    assert(!result.isValid)
    assert(result.inputJson == jsonInstanceStr)
    assert(result.errorCount == 1)
    assert(result.errorList.size == 1)
  }

  test("validate function should return isValid == true for valid json instance") {
    assert(dataContract != null)
    dataContract should have size 7

    val jsonInstanceStr = getSchemaAsString("contracts/asset_created.json")
    val result = JsonSchemaValidator.validate(schema, jsonInstanceStr)

    assert(result.isValid)
  }

  test("validate function should return isValid == false for invalid json instance") {
    assert(dataContract != null)
    dataContract should have size 7

    val jsonInstanceStr = getSchemaAsString("contracts/asset_created_invalid.json")
    val result = JsonSchemaValidator.validate(schema, jsonInstanceStr)

    assert(!result.isValid)
    assert(result.inputJson == jsonInstanceStr)
    assert(result.errorCount == 1)
    assert(result.errorList.size == 1)
  }

  private def getSchemaAsString(resourcePath: String): String = {
    Resources.toString(Resources.getResource(resourcePath), Charset.forName("UTF-8"))
  }
}