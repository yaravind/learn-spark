package com.tccc.dna.datacontract

import com.google.common.io.Resources
import com.tccc.dna.synapse.AzStorage.ifFileExists
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.should.Matchers

import java.nio.charset.Charset
import scala.io.Source

/**
 * TODO assert terms, servers, schema and examples object properties
 */
class DataContractYAMLFactoryTest extends AnyFunSuite with Matchers {

  test("parseFromFile") {
    val relativeFilePath = "src/test/resources/contracts/datacontract.yaml"
    val dataContract = DataContractYAMLFactory.parseFromFile(relativeFilePath)

    assert(dataContract != null)
    dataContract should have size 7
    assertInfoObject(dataContract)
  }

  private def assertInfoObject(dataContract: Map[String, Any]) = {
    val info = DataContractYAMLFactory.getInfoObject(dataContract)
    assert(info != null)
    info should have size 6
    info should contain key "title"
    info should contain key "version"
    info should contain key "description"
    info should contain key "owner"
    info should contain key "dataProduct"
    info should contain key "contact"

    val contact = info("contact").asInstanceOf[Map[String, String]]
    contact should contain key "name"
    contact should contain key "email"
    contact should contain key "url"
  }

  test("parseFromString") {
    val contractAsString = Resources.toString(Resources.getResource("contracts/datacontract.yaml"), Charset.forName("UTF-8"))
    val dataContract = DataContractYAMLFactory.parseFromString(contractAsString)

    assert(dataContract != null)
    dataContract should have size 7
    assertInfoObject(dataContract)
  }

}