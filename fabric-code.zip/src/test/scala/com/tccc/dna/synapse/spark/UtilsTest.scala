package com.tccc.dna.synapse.spark

import com.tccc.dna.synapse.Utils
import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.should.Matchers

import java.time.{Instant, LocalDate}

class UtilsTest extends AnyFunSuite with Matchers {
  test("upsert map") {
    val initialMap = Map("a" -> "1", "b" -> "2", "c" -> "3")
    val updates =
      Map("b" -> "4", "c" -> "5", "d" -> "6") // update b, c and add d

    val upsertedMap = Utils.merge(initialMap, updates)

    val expectedMap = Map("a" -> "1", "b" -> "4", "c" -> "5", "d" -> "6")

    upsertedMap should contain theSameElementsAs expectedMap
  }

  test("Parse Julian date to Gregorian date") {
    val testCases = Seq(
      (
        Array[Byte](
          128.toByte,
          76.toByte,
          69.toByte,
          116.toByte,
          64.toByte,
          7.toByte,
          0.toByte,
          0.toByte,
          48.toByte,
          131.toByte,
          37.toByte,
          0.toByte
        ),
        LocalDate.parse("2018-10-24"),
        Instant.parse("2018-10-24T02:12:53.410Z")
      )
    )

    for ((input, expectedDate, expectedTime) <- testCases) {
      val result = Utils.int96ToJulian(input)

      val date = result._1
      val time = result._2

      date shouldBe expectedDate
      time shouldBe expectedTime
    }
  }
}