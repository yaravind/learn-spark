package com.tccc.dna.synapse.spark.test

import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.{BeforeAndAfter, BeforeAndAfterAll, Ignore}

@Ignore
class BeforeAfterTest extends AnyFunSuite with BeforeAndAfter with BeforeAndAfterAll {

  override protected def beforeAll(): Unit = println("beforeAll")

  override protected def afterAll(): Unit = println("afterAll")

  before {
    println("before")
  }

  after {
    println("after")
  }

  test("hello1") {
    println("hello1")
  }

  test("hello2") {
    println("hello2")
  }
}
