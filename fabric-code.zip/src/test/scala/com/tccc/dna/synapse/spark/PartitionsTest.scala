package com.tccc.dna.synapse.spark

import com.tccc.dna.synapse.spark.test.SparkTestBaseSpec
import org.scalatest.BeforeAndAfterAll

class PartitionsTest extends SparkTestBaseSpec with BeforeAndAfterAll {

  test("getActiveSession should retrieve current SparkSession") {
    val spark = SynapseSpark.getActiveSession

    logInfo(s"Spark version: ${spark.version}")
    logInfo(s"Spark hashcode: ${spark.hashCode()}")

    assert(spark != null)
  }
}
