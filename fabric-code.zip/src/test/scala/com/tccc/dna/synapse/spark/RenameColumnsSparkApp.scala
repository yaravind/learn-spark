package com.tccc.dna.synapse.spark

import com.tccc.dna.synapse.spark.DataFrames._

/***
 * TODO Refactor to extend [[com.tccc.dna.synapse.spark.test.SparkTestBaseSpec]]
 */
object RenameColumnsSparkApp extends SynapseSparkBase {
  logInfo("Rename Columns Spark Application")
  val spark = getSparkSession("RenameColumnsSparkApp", Some("local[1]"))

  // For implicit conversions like converting RDDs to DataFrames

  import org.apache.spark.sql.functions._
  import spark.implicits._

  val input = Seq(
    (1, 1, 5),
    (1, 2, 5),
    (1, 3, 5),
    (2, 1, 15),
    (2, 2, 5),
    (2, 6, 5)
  ).toDF("Id", "Col. 1", "Col 2")

  //Column rename
  val renamedInputDf = cleanColNames(input)
  renamedInputDf.printSchema()

  renamedInputDf
    .groupBy("id")
    .agg(max(col("col_1")), sum(col("col_2")))
    .show()

  println(s"Schema as DDL: ${input.schema.toDDL}")
}
