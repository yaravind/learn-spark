package com.tccc.dna.synapse.spark

import com.microsoft.spark.notebook.msutils.MSFileInfo
import com.tccc.dna.synapse.AzStorage.{copyFiles, deepLs, ifFileExists, moveFiles}
import com.tccc.dna.synapse.spark.test.SparkTestBaseSpec

import java.io.{File, PrintWriter}
import java.nio.file.{Files, Paths}

class AzStorageTest extends SparkTestBaseSpec {

  test("ifFileExists return true if the file exists") {
    val filePath = "file:///" + getAbsolutePathOfResource("wordcount/test_ds_v2.txt")
    val exists = ifFileExists(filePath)
    assert(exists)
  }

  test("ifFileExists return false if the file does not exist") {
    val filePath = "/tmp/does-not-exist.txt"
    val exists = ifFileExists(filePath)
    assert(!exists)
  }

  test("deepLs works on local env with file:/// prefix") {
    val root = MSFileInfo(name = null,
      path = "file:///" + getAbsolutePath("src/main/resources"),
      size = 0, isDir = true, isFile = false, modifyTime = System.currentTimeMillis)

    val fileList = deepLs(root)
    assert(!fileList.isEmpty)
    assert(fileList.length > 0)
    fileList.foreach(println(_))
  }

  test("deepLs works on local env WITHOUT file:/// prefix") {
    val root = MSFileInfo(name = null,
      path = getAbsolutePath("src/main/resources"),
      size = 0, isDir = true, isFile = false, modifyTime = System.currentTimeMillis)

    val fileList = deepLs(root)
    assert(!fileList.isEmpty)
    assert(fileList.length > 0)
    fileList.foreach(println(_))
  }

  test("copy files from multiple source to single dest"){

    //Source folders
    val baseSourceDirPath = getTempFilePath("source/copy_file_one/")
    val sourceDirPathOne = baseSourceDirPath + "01/"
    val sourceDirPathTwo = baseSourceDirPath + "02/"

    val sourceDirOne = Paths.get(sourceDirPathOne)
    val sourceDirTwo = Paths.get(sourceDirPathTwo)
    if(!Files.exists(sourceDirOne)){
      Files.createDirectories(sourceDirOne)
    }
    if(!Files.exists(sourceDirTwo)){
      Files.createDirectories(sourceDirTwo)
    }
    val filePathOne = sourceDirPathOne + "helloOne.txt"
    var fileObject = new File(filePathOne)
    var printWriter = new PrintWriter(fileObject)
    printWriter.write("Hello world one")
    printWriter.close()

    val filePathTwo = sourceDirPathTwo + "helloTwo.txt"
    fileObject = new File(filePathTwo)
    printWriter = new PrintWriter(fileObject)
    printWriter.write("Hello world two")
    printWriter.close()
    //dest folder locstion
    val destDirPath = getTempFilePath("dest/copy_file_one/")
    val destDir =Paths.get(destDirPath)
    copyFiles(List(filePathOne, filePathTwo), destDirPath, true)
    println(filePathOne)



    assert(Files.list(destDir).toArray().length == 2)
    assert (Files.list(Paths.get(baseSourceDirPath)).toArray.length == 2)
  }

  test("copy files from multiple source to multiple dest") {

    //Source folders
    val baseSourceDirPath = getTempFilePath("source/copy_file_two/")
    val sourceDirPathOne = baseSourceDirPath + "01/"
    val sourceDirPathTwo = baseSourceDirPath + "02/"

    val sourceDirOne = Paths.get(sourceDirPathOne)
    val sourceDirTwo = Paths.get(sourceDirPathTwo)
    if (!Files.exists(sourceDirOne)) {
      Files.createDirectories(sourceDirOne)
    }
    if (!Files.exists(sourceDirTwo)) {
      Files.createDirectories(sourceDirTwo)
    }
    val filePathOne = sourceDirPathOne + "helloOne.txt"
    var fileObject = new File(filePathOne)
    var printWriter = new PrintWriter(fileObject)
    printWriter.write("Hello world one")
    printWriter.close()

    val filePathTwo = sourceDirPathTwo + "helloTwo.txt"
    fileObject = new File(filePathTwo)
    printWriter = new PrintWriter(fileObject)
    printWriter.write("Hello world two")
    printWriter.close()

    val filePathThree = sourceDirPathTwo + "helloThree.txt"
    fileObject = new File(filePathThree)
    printWriter = new PrintWriter(fileObject)
    printWriter.write("Hello world three")
    printWriter.close()

    //dest folder locstion
    val destDirPath = getTempFilePath("dest/copy_file_two/")
    val destDirPathOne = destDirPath + "01/"
    val destDirPathTwo = destDirPath + "02/"

    val destDir = Paths.get(destDirPath)
    copyFiles(List(filePathOne, filePathTwo, filePathThree), List(destDirPathOne, destDirPathTwo, destDirPathTwo), true)
    Files.list(Paths.get(destDirPathTwo)).toArray.foreach(println)
    println("hello")
    Files.list(Paths.get(destDirPathOne)).toArray.foreach(println)

    assert(Files.list(destDir).toArray().length == 2)
    assert(Files.list(Paths.get(baseSourceDirPath)).toArray.length == 2)
    assert(Files.list(Paths.get(destDirPathOne)).toArray.length == 1)
    assert(Files.list(Paths.get(destDirPathTwo)).toArray.length == 2)
  }

  test("move files from multiple source to single dest") {

    //Source folders
    val baseSourceDirPath = getTempFilePath("source/move_file_one/")
    val sourceDirPathOne = baseSourceDirPath + "01/"
    val sourceDirPathTwo = baseSourceDirPath + "02/"

    val sourceDirOne = Paths.get(sourceDirPathOne)
    val sourceDirTwo = Paths.get(sourceDirPathTwo)
    if (!Files.exists(sourceDirOne)) {
      Files.createDirectories(sourceDirOne)
    }
    if (!Files.exists(sourceDirTwo)) {
      Files.createDirectories(sourceDirTwo)
    }
    val filePathOne = sourceDirPathOne + "helloOne.txt"
    var fileObject = new File(filePathOne)
    var printWriter = new PrintWriter(fileObject)
    printWriter.write("Hello world one")
    printWriter.close()

    val filePathTwo = sourceDirPathTwo + "helloTwo.txt"
    fileObject = new File(filePathTwo)
    printWriter = new PrintWriter(fileObject)
    printWriter.write("Hello world two")
    printWriter.close()
    //dest folder locstion
    val destDirPath = getTempFilePath("dest/move_file_one/")
    val destDir = Paths.get(destDirPath)
    moveFiles(List(filePathOne, filePathTwo), destDirPath, true)
    println(filePathOne)


    assert(Files.list(destDir).toArray().length == 2)
    assert(Files.list(Paths.get(baseSourceDirPath)).toArray.length == 2)
    assert(Files.list(Paths.get(sourceDirPathOne)).toArray.length == 0)
    assert(Files.list(Paths.get(sourceDirPathTwo)).toArray.length == 0)
  }

  test("move files from multiple source to multiple dest") {

    //Source folders
    val baseSourceDirPath = getTempFilePath("source/move_file_two/")
    val sourceDirPathOne = baseSourceDirPath + "01/"
    val sourceDirPathTwo = baseSourceDirPath + "02/"

    val sourceDirOne = Paths.get(sourceDirPathOne)
    val sourceDirTwo = Paths.get(sourceDirPathTwo)
    if (!Files.exists(sourceDirOne)) {
      Files.createDirectories(sourceDirOne)
    }
    if (!Files.exists(sourceDirTwo)) {
      Files.createDirectories(sourceDirTwo)
    }
    val filePathOne = sourceDirPathOne + "helloOne.txt"
    var fileObject = new File(filePathOne)
    var printWriter = new PrintWriter(fileObject)
    printWriter.write("Hello world one")
    printWriter.close()

    val filePathTwo = sourceDirPathTwo + "helloTwo.txt"
    fileObject = new File(filePathTwo)
    printWriter = new PrintWriter(fileObject)
    printWriter.write("Hello world two")
    printWriter.close()

    val filePathThree = sourceDirPathTwo + "helloThree.txt"
    fileObject = new File(filePathThree)
    printWriter = new PrintWriter(fileObject)
    printWriter.write("Hello world three")
    printWriter.close()

    //dest folder locstion
    val destDirPath = getTempFilePath("dest/move_file_two/")
    val destDirPathOne = destDirPath + "01/"
    val destDirPathTwo = destDirPath + "02/"
    val destDirPathThree = destDirPath + "03/"

    val destDir = Paths.get(destDirPath)
    moveFiles(List(filePathOne, filePathTwo, filePathThree), List(destDirPathOne, destDirPathTwo, destDirPathThree), true)


    assert(Files.list(destDir).toArray().length == 3)
    assert(Files.list(Paths.get(baseSourceDirPath)).toArray.length == 2)
    assert(Files.list(Paths.get(destDirPathOne)).toArray.length == 1)
    assert(Files.list(Paths.get(destDirPathTwo)).toArray.length == 1)
    assert(Files.list(Paths.get(destDirPathThree)).toArray.length == 1)
    assert(Files.list(Paths.get(sourceDirPathOne)).toArray.length == 0)
    assert(Files.list(Paths.get(sourceDirPathTwo)).toArray.length == 0)

  }

}