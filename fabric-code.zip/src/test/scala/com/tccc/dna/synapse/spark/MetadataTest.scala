package com.tccc.dna.synapse.spark

import com.tccc.dna.synapse.spark.test.SparkTestBaseSpec
import org.apache.spark.sql.Encoders

class MetadataTest extends SparkTestBaseSpec {
  private val BlogParquetPath = "src/test/resources/parquet/blogs.parquet"
  private val ParquetBasePath = Seq("src/test/resources/parquet/")

  test("Metadata.printParquetMetadata should succeed") {
    Metadata.printParquetMetadata(BlogParquetPath)
  }

  test("MetadataUtils.showDetails should succeed") {
    Metadata.printParquetMetadata(BlogParquetPath, System.out)
  }

  test("Happy path - FileMeta") {
    val result = Metadata.getParquetMetadata(BlogParquetPath)
    result match {
      case Right((fileMeta, schema, rowGroupMeta, colMeta, colStats)) =>
        assert(fileMeta != null)

        fileMeta.createdBy shouldBe "parquet-mr version 1.10.1 (build a89df8f9932b6ef6633d06069e50c9b7970bebd1)"
        fileMeta.formatVersion shouldBe None
        fileMeta.numColumns shouldBe 3
        fileMeta.numRows shouldBe 500
        fileMeta.numRowGroups shouldBe 1
        fileMeta.uncompressedSize shouldBe 4064
        fileMeta.compressedSize shouldBe 4064 // returns the actual size when compression is not applied
        fileMeta.compression.get shouldBe "UNCOMPRESSED"
        fileMeta.sizeReducedByPercent shouldBe 0.0
        fileMeta.customProps should have size 3

        // fileMeta.customProps should contain(Entry("writer.model.name", "protobuf"))
        fileMeta.customProps should contain key "parquet.proto.descriptor"

        fileMeta.customProps should contain key "parquet.proto.class"
        fileMeta.customProps should contain value "org.apache.arrow.rust.example.Blogs$Blog"

        fileMeta.customProps should contain key "writer.model.name"
        fileMeta.customProps should contain value "protobuf"

      case Left(errorMsg) => println(errorMsg)
    }
  }

  test("Happy path - Schema") {
    val result = Metadata.getParquetMetadata(ParquetBasePath(0) + "/cust-sats-asn-c000.snappy.parquet")
    result match {
      case Right((fileMeta, schema, rowGroupMeta, colMeta, colStats)) =>
        assert(schema != null)

      case Left(errorMsg) => println(errorMsg)
    }
  }

  test("Happy path - should return 5 tuples") {
    val result = Metadata.getParquetMetadata(BlogParquetPath)
    result match {
      case Right((fileMeta, schema, rowGroupMeta, colMeta, colStats)) =>
        println(Metadata.getMetaJson(colStats, prettyPrint = true))
        assert(fileMeta != null)
        assert(schema != null)
        assert(rowGroupMeta != null)
        assert(colMeta != null)
        assert(colStats != null)
      case Left(errorMsg) => println(errorMsg)
    }
  }

  test("Happy path - print metadata") {
    println("Nested parquet:")
    Metadata.printParquetMetadata(BlogParquetPath)

    /*
    For testing purpose only.
    println("\nUn-nested parquet:")
    Metadata.printParquetMetadata("/Users/o60774/Downloads/data/new_york_taxi/parquet/part-00045.snappy.parquet")*/
  }

  test("Error path should return error message") {
    val result = Metadata.getParquetMetadata("src/test/resources/non-existent-file.parquet")
    result match {
      case Right((fileMeta, schema, rowGroupMeta, colMeta, colStats)) =>
      case Left(errorMsg) => assert(errorMsg == "File src/test/resources/non-existent-file.parquet does not exist")
    }
  }

  test("timestamp min max shown as hexadecimal min : 0x800299E58F3C0000B7892500") {
    val result = Metadata.getParquetMetadata("src/test/resources/parquet/cust-sats-asn-c000.snappy.parquet")
    result match {
      case Right((fileMeta, schema, rowGroupMeta, colMeta, colStats)) =>
        println(Metadata.getMetaJson(colStats, prettyPrint = true))
      case Left(errorMsg) => assert(errorMsg == "File src/test/resources/non-existent-file.parquet does not exist")
    }
  }

  test("getFiles and getFileMetaAsDataFrame should succeed") {
    val filesDf =
      Metadata
        .getFiles(null, Some(1), ParquetBasePath, (_, file) => file.filePath)(Encoders.STRING)
        .toDF
    filesDf.show(100, truncate = false)
    assert(filesDf.count() >= 2)

    val fileMetaDf = Metadata.getFileMetaAsDataFrame(ParquetBasePath)
    assert(fileMetaDf.count() >= 2)
    fileMetaDf.show(100, truncate = false)
  }

  test("getRowGroupMetaAsDataFrame should succeed") {
    val filesDf =
      Metadata
        .getFiles(null, Some(1), ParquetBasePath, (_, file) => file.filePath)(Encoders.STRING)
        .toDF

    val rgMetaDf = Metadata.getRowGroupMetaAsDataFrame(ParquetBasePath)
    assert(rgMetaDf.count() >= 2)
    rgMetaDf.show(100, truncate = false)
  }

  test("getColSummaryMetaAsDataFrame should succeed") {
    val filesDf =
      Metadata
        .getFiles(null, Some(1), ParquetBasePath, (_, file) => file.filePath)(Encoders.STRING)
        .toDF

    val rgMetaDf = Metadata.getColSummaryMetaAsDataFrame(ParquetBasePath)
    assert(rgMetaDf.count() == 15)
    rgMetaDf.show(100, truncate = false)
  }

  test("getColStasAsDataFrame should succeed") {
    val filesDf =
      Metadata
        .getFiles(null, Some(1), ParquetBasePath, (_, file) => file.filePath)(Encoders.STRING)
        .toDF

    val colStatsDf = Metadata.getColStatsAsDataFrame(ParquetBasePath)
    assert(colStatsDf.count() == 15)
    colStatsDf.show(100, truncate = false)
  }
}