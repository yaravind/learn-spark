package com.tccc.dna.synapse.spark

import com.tccc.dna.synapse.spark.test.SparkTestBaseSpec
import io.delta.tables.DeltaTable
import org.apache.commons.io.FileUtils
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{DataFrame, Row}
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType, TimestampType}
import org.scalatest.BeforeAndAfterAll

import java.nio.file.{Files, Path}
import java.sql.Timestamp
import java.util.Date
import scala.Console.println
import scala.collection.mutable

class LocalDeltaDeleteTest extends SparkTestBaseSpec with BeforeAndAfterAll{
  val Today: Timestamp = createTimestamp(new Date())
  private val IgnoreColsDuringAssert = List("upd_ts", "upd_usr")

  private val TargetSchema = StructType(
    Seq(
      StructField("id", IntegerType, nullable = false),
      StructField("name", StringType, nullable = false),
      StructField("crt_ts", TimestampType, nullable = true),
      StructField("crt_usr", StringType, nullable = true),
      StructField("upd_ts", TimestampType, nullable = true),
      StructField("upd_usr", StringType, nullable = true)
    )
  )
  private val SourceSchema = StructType(
    Seq(
      StructField("id", IntegerType, nullable = false),
      StructField("name", StringType, nullable = false),
      StructField("crt_ts", TimestampType, nullable = true),
      StructField("crt_usr", StringType, nullable = true)
    )
  )

  test("Delete record from delta file") {
    val targetPath = getTempFilePath("deleteRecord")
    println(targetPath)
    var targetDf = createTargetDf()
    println("Target table: ")
    targetDf.show()
    println("Create Target table at " + targetPath)
    targetDf.write.format("delta").save(targetPath)

    val sourceDf = createDataframeFromCollection(
      SourceSchema,
      Seq(
        Row(1, "Alice", Today, "user1", null, null), //delete
      )
    )
    println("Source table: ")
    sourceDf.show()

    println("Call delete ...")

    val targetTable = DeltaTable.forPath(SynapseSpark.getActiveSession, targetPath)
    val conditionList = new scala.collection.mutable.ListBuffer[String]()
    val mergeOnCols =List("id")
    for (key <- mergeOnCols) {
      conditionList += sourceDf.withColumn(key, col(key).cast(StringType)).select(key).distinct().collect().map(_.getString(0)).toList.map(value => s"$key ='$value'").mkString(" OR ")
    }
    val condition = conditionList.map(value => s"($value)").mkString(" AND ")
    println(s"count before deleting: ${targetTable.toDF.count()}")
    targetTable.delete(condition)
    println(s"count after deleting: ${targetTable.toDF.count()}")
    logInfo("Deletion ended")

    val expectedDf = createDataframeFromCollection(
      TargetSchema,
      Seq(
        // id, name, crt_ts, crt_user, upd_ts, upd_usr
        //ROW 1 is deleted
        Row(2, "Bob", Today, "user2", null, null)
      )
    )

    println("Show target table after updates")
    val actualDf = spark.read.format("delta").load(targetPath)
    actualDf.show()
    actualDf.printSchema()

    assert(actualDf.count() == 1, "1 row deleted")

    assertSmallDatasetEquality(actualDf, expectedDf, ignoreNullable = true)
  }

  def createTargetDf(): DataFrame = {
    println(s"localDate=$Today")
    val data = Seq(
      // id, name, crt_ts, crt_usr, upd_ts, upd_usr
      /*Row(1, "Alice", Timestamp.valueOf("2023-01-01 00:00:00"), "user1", null, null),
      Row(2, "Bob", Timestamp.valueOf("2023-01-01 00:00:00"), "user2", null, null)*/
      Row(1, "Alice", Today, "user1", null, null),
      Row(2, "Bob", Today, "user2", null, null)
    )
    createDataframeFromCollection(TargetSchema, data)
  }
}