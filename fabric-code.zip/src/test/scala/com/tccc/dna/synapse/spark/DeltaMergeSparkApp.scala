package com.tccc.dna.synapse.spark


import com.github.mrpowers.spark.fast.tests.DatasetComparer
import io.delta.tables.DeltaTable
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.commons.io.FileUtils
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions.current_timestamp
import org.apache.spark.sql.types._

import java.io.File
import java.nio.file.{Files, Paths}
import java.sql.Timestamp
import scala.collection.mutable

object DeltaMergeSparkApp extends App with DatasetComparer {
  val spark = getSession
  println("Spark version: " + spark.version)
  println("Delta version: " + io.delta.VERSION)

  val IgnoreColsDuringAssert = List("upd_ts", "upd_usr")
  val TargetSchema = StructType(Seq(
    StructField("id", IntegerType, nullable = false),
    StructField("name", StringType, nullable = false),
    StructField("crt_ts", TimestampType, nullable = true),
    StructField("crt_usr", StringType, nullable = true),
    StructField("upd_ts", TimestampType, nullable = true),
    StructField("upd_usr", StringType, nullable = true)
  ))
  val SourceSchema = StructType(Seq(
    StructField("id", IntegerType, nullable = false),
    StructField("name", StringType, nullable = false),
    StructField("crt_ts", TimestampType, nullable = true),
    StructField("crt_usr", StringType, nullable = true)
  ))

  val TempDirName = Paths.get("target/upsertHappyPath")
  val tempDir = TempDirName.toString
  FileUtils.deleteDirectory(new java.io.File(tempDir))
  println(s"Create temp dir:  $tempDir")
  Files.createDirectory(TempDirName)

  val targetDf = createTargetDf()
  println("Target table: ")
  targetDf.show()
  println("Schema before save: ")
  targetDf.printSchema()
  println("Create Target table at " + tempDir)
  targetDf.write.format("delta").save(tempDir)
  println("Schema after save: ")
  spark.read.format("delta").load(tempDir).printSchema()

  val sourceDf = createDataframeFromCollection(SourceSchema, Seq(
    Row(3, "Charlie", Timestamp.valueOf("2023-01-02 00:00:00"), "user2"), //insert
    Row(4, "Ashok", Timestamp.valueOf("2023-01-02 00:00:00"), "user1"), //insert
  ))
  println("Source table: ")
  sourceDf.show()
  sourceDf.printSchema()

  val updateMap: Map[String, String] = Map(
    "target.upd_ts" -> s"${current_timestamp()}",
    "target.upd_usr" -> "'testUser'"
  )
  upsert(tempDir, sourceDf,
    sourceExcludeCols = List(),
    mergeOnCols = List("id"), partitionPruneCols = List(), customUpdateExpr = updateMap)
  println("Complete upsert")

  val expectedDf = createDataframeFromCollection(TargetSchema, Seq(
    Row(1, "Alice", Timestamp.valueOf("2023-01-01 00:00:00"), "user1", Timestamp.valueOf("2023-01-01 00:00:00"), "user1"), //unchanged
    Row(2, "Bob", Timestamp.valueOf("2023-01-01 00:00:00"), "user2", Timestamp.valueOf("2023-01-01 00:00:00"), "user2"), //unchanged
    Row(3, "Charlie", Timestamp.valueOf("2023-01-02 00:00:00"), "user2", Timestamp.valueOf("2023-01-02 00:00:00"), "testUser"), //insert
    Row(4, "Ashok", Timestamp.valueOf("2023-01-02 00:00:00"), "user1", Timestamp.valueOf("2023-01-02 00:00:00"), "testUser"), //insert
  ))

  println("Show target table after updates")
  val actualDf = spark.read.format("delta").load(tempDir) //.orderBy("id")
  actualDf.show()
  actualDf.printSchema()

  assert(actualDf.count() == 4, "2 new inserts")
  assertSmallDatasetEquality(actualDf.drop("upd_ts"), expectedDf.drop("upd_ts"), ignoreNullable = true, orderedComparison = true)


  def createTargetDf(): DataFrame = {
    val data = Seq(
      Row(1, "Alice", Timestamp.valueOf("2023-01-01 00:00:00"), "user1", Timestamp.valueOf("2023-01-01 00:00:00"), "user1"),
      Row(2, "Bob", Timestamp.valueOf("2023-01-01 00:00:00"), "user2", Timestamp.valueOf("2023-01-01 00:00:00"), "user2"),
    )
    createDataframeFromCollection(TargetSchema, data)
  }

  def createSourceDf(): DataFrame = {
    val schema = StructType(Seq(
      StructField("id", IntegerType, nullable = false),
      StructField("name", StringType, nullable = false),
      StructField("crt_ts", TimestampType, nullable = true),
      StructField("crt_usr", StringType, nullable = true)
    ))

    val data = Seq(
      Row(1, "Alice-update", Timestamp.valueOf("2023-01-02 00:00:00"), "user1"), //update
      Row(3, "Charlie-insert", Timestamp.valueOf("2023-01-02 00:00:00"), "user2"), //insert
    )

    createDataframeFromCollection(schema, data)
  }

  private def createDataframeFromCollection(schema: StructType, data: Seq[Row]) = {
    getSession.createDataFrame(getSession.sparkContext.parallelize(data), schema)
  }

  private def getSession = {
    SparkSession.builder()
      .appName("DeltaMergeSparkApp")
      .config("spark.driver.bindAddress", "127.0.0.1")
      .master("local[2]")
      .getOrCreate()
  }

  def upsert(targetPath: String, sourceDf: DataFrame, sourceExcludeCols: List[String] = List(),
             mergeOnCols: List[String], partitionPruneCols: List[String] = List(),
             customInsertExpr: Map[String, String] = Map(), customUpdateExpr: Map[String, String] = Map()): Unit = {
    println(s"targetPath: $targetPath, sourceExcludeCols: $sourceExcludeCols, mergeOnCols: $mergeOnCols")
    val targetTable = DeltaTable.forPath(SynapseSpark.getActiveSession, targetPath)
    val targetDf = targetTable.toDF
    println(s"Target table cols: (${targetDf.columns.length})" + targetDf.columns.mkString(", "))
    println(s"Source Dataframe cols: (${sourceDf.columns.length})" + sourceDf.columns.mkString(", "))

    val mergeCols = sourceDf.columns.filter(col => !sourceExcludeCols.contains(col))

    val updateExpr = mergeCols.map(colName => (s"target.$colName", s"source.$colName")).toMap
    val finalUpdateExpr = updateExpr ++ customUpdateExpr

    val insertExpr: mutable.Map[String, String] = mutable.Map[String, String]() ++= finalUpdateExpr
    val finalInsertExpr = insertExpr ++ customInsertExpr

    println(s"updateExpr: $finalUpdateExpr")
    println(s"insertExpr: $finalInsertExpr")

    val mergeCondition = mergeOnCols.map(col => s"target.$col = source.$col").mkString(" AND ")
    println(s"mergeCondition: $mergeCondition")

    targetTable.as("target")
      .merge(sourceDf.as("source"), mergeCondition)
      .whenMatched
      .updateExpr(finalUpdateExpr)
      .whenNotMatched
      .insertExpr(finalInsertExpr)
      .execute()
  }
}
