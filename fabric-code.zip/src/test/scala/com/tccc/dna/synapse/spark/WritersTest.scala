package com.tccc.dna.synapse.spark

import com.tccc.dna.synapse.spark.test.SparkTestBaseSpec
import org.apache.commons.io.FileUtils
import org.apache.spark.sql.functions.{current_timestamp, date_format}
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row}
import org.scalatest.BeforeAndAfterAll

import java.nio.file.{Files, Path}
import java.sql.Timestamp
import java.util.Date
import scala.Console.println
import scala.collection.mutable

class WritersTest extends SparkTestBaseSpec with BeforeAndAfterAll {
  val Today: Timestamp = createTimestamp(new Date())
  private val IgnoreColsDuringAssert = List("upd_ts", "upd_usr")

  private val TargetSchema = StructType(
    Seq(
      StructField("id", IntegerType, nullable = false),
      StructField("name", StringType, nullable = false),
      StructField("crt_ts", TimestampType, nullable = true),
      StructField("crt_usr", StringType, nullable = true),
      StructField("upd_ts", TimestampType, nullable = true),
      StructField("upd_usr", StringType, nullable = true)
    )
  )
  private val SourceSchema = StructType(
    Seq(
      StructField("id", IntegerType, nullable = false),
      StructField("name", StringType, nullable = false),
      StructField("crt_ts", TimestampType, nullable = true),
      StructField("crt_usr", StringType, nullable = true)
    )
  )

  ignore("Upsert - test delta table creation with SQL") {
    val sql =
      """
        |CREATE EXTERNAL TABLE IF NOT EXISTS student (id INT, name STRING, age INT)
        |    COMMENT 'this is a comment'
        |    TBLPROPERTIES ('foo'='bar')
        |""".stripMargin
  }

  test("Upsert - source with only updates") {
    val targetPath = getTempFilePath("updatesOnly")
    val targetDf = createTargetDf()
    println("Target table: ")
    targetDf.show()
    println("Create Target table at " + targetPath)
    targetDf.write.format("delta").save(targetPath)

    val sourceDf = createDataframeFromCollection(
      SourceSchema,
      Seq(
        // id, name, crt_ts, crt_usr
        Row(1, "Alice-update", Today, "user1") // update
      )
    )
    println("Source table: ")
    sourceDf.show()

    val updateMap: Map[String, String] = Map(
      "target.upd_ts" -> s"${date_format(current_timestamp(), "\"yyyy-MM-dd\"")}",
      "target.upd_usr" -> s"'${SynapseSpark.getCurrentUserName}'"
    )

    println("Call upsert ...")
    // targetPath, sourceDf, mergeOnCols, partitionPruneCols, insertExcludeCols, updateExcludeCols, customInsertExpr, customUpdateExpr
    Writers.upsert(
      targetPath,
      sourceDf,
      mergeOnCols = List("id"),
      updateExcludeCols = List("crt_ur", "crt_ts"),
      customUpdateExpr = updateMap
    )
    println("Complete upsert")

    val expectedDf = createDataframeFromCollection(
      TargetSchema,
      Seq(
        // id, name, crt_ts, crt_user, upd_ts, upd_usr
        Row(1, "Alice-update", Today, "user1", Today, "Not Available"), // update
        Row(2, "Bob", Today, "user2", null, null) // unchanged
      )
    )

    println("Show target table after updates")
    val actualDf = spark.read.format("delta").load(targetPath)
    actualDf.show()

    assert(actualDf.count() == 2, "1 update, no insert")
    // assertSmallDatasetEquality(actualDf.drop(IgnoreColsDuringAssert: _*), expectedDf.drop(IgnoreColsDuringAssert: _*), ignoreNullable = true)
    assertSmallDatasetEquality(actualDf, expectedDf, ignoreNullable = true)
  }

  test("Upsert - source with only new inserts") {
    val targetPath = getTempFilePath("insertsOnly")
    val targetDf = createTargetDf()
    println("Target table: ")
    targetDf.show()
    println("Create Target table at " + targetPath)
    targetDf.write.format("delta").save(targetPath)

    val sourceDf = createDataframeFromCollection(
      SourceSchema,
      Seq(
        // id, name, crt_ts, crt_usr
        Row(3, "Charlie", Today, "user2"), // insert
        Row(4, "Ashok", Today, "user1") // insert
      )
    )
    println("Source table: ")
    sourceDf.show()

    println("Call upsert ...")
    val customInsertExpr: Map[String, String] = Map(
      "target.crt_ts" -> s"${date_format(current_timestamp(), "\"yyyy-MM-dd\"")}",
      "target.crt_usr" -> s"'${SynapseSpark.getCurrentUserName}'"
    )
    // targetPath, sourceDf, mergeOnCols, partitionPruneCols, insertExcludeCols, updateExcludeCols, customInsertExpr, customUpdateExpr
    Writers.upsert(
      targetPath,
      sourceDf,
      mergeOnCols = List("id"),
      insertExcludeCols = List("crt_ur", "crt_ts"),
      customInsertExpr = customInsertExpr
    )
    println("Complete upsert")

    val expectedDf = createDataframeFromCollection(
      TargetSchema,
      Seq(
        // id, name, crt_ts, crt_usr, upd_ts, upd_usr
        Row(1, "Alice", Today, "user1", null, null), // unchanged
        Row(2, "Bob", Today, "user2", null, null), // unchanged
        Row(3, "Charlie", Today, "Not Available", null, null), // insert
        Row(4, "Ashok", Today, "Not Available", null, null) // insert
      )
    )

    println("Show target table after updates")
    // TODO Figure out why orderBy is needed
    val actualDf = spark.read.format("delta").load(targetPath) // .orderBy("id")
    actualDf.show()
    actualDf.printSchema()

    assert(actualDf.count() == 4, "2 new inserts")
    assertSmallDatasetEquality(
      actualDf.drop("upd_ts"),
      expectedDf.drop("upd_ts"),
      ignoreNullable = true,
      orderedComparison = false
    )
  }

  test("Upsert - source with updates (1) and new rows (1)") {
    val targetPath = getTempFilePath("updatesAndInserts")
    val targetDf = createTargetDf()
    println("Target table: ")
    targetDf.show()
    println("Create Target table at " + targetPath)
    targetDf.write.format("delta").save(targetPath)

    val sourceDf = createDataframeFromCollection(
      SourceSchema,
      Seq(
        Row(1, "Alice-update", Today, "user1"), // update
        Row(3, "Charlie-insert", Today, "user2") // insert
      )
    )
    println("Source table: ")
    sourceDf.show()

    val customInsertMap: Map[String, String] = Map(
      "target.crt_ts" -> s"${date_format(current_timestamp(), "\"yyyy-MM-dd\"")}",
      "target.crt_usr" -> s"'${SynapseSpark.getCurrentUserName}'"
    )

    val customUpdateMap: Map[String, String] = Map(
      "target.upd_ts" -> s"${date_format(current_timestamp(), "\"yyyy-MM-dd\"")}",
      "target.upd_usr" -> s"'${SynapseSpark.getCurrentUserName}'"
    )

    println("Call upsert ...")
    val excludeCols = List("crt_ur", "crt_ts")
    // targetPath, sourceDf, mergeOnCols, partitionPruneCols, insertExcludeCols, updateExcludeCols, customInsertExpr, customUpdateExpr
    Writers.upsert(
      targetPath,
      sourceDf,
      mergeOnCols = List("id"),
      insertExcludeCols = excludeCols,
      updateExcludeCols = excludeCols,
      customInsertExpr = customInsertMap,
      customUpdateExpr = customUpdateMap
    )
    println("Complete upsert")

    val expectedDf = createDataframeFromCollection(
      TargetSchema,
      Seq(
        // id, name, crt_ts, crt_user, upd_ts, upd_usr
        Row(1, "Alice-update", Today, "user1", Today, "Not Available"), // update
        Row(2, "Bob", Today, "user2", null, null), // unchanged
        Row(3, "Charlie-insert", Today, "Not Available", null, null) // new insert
      )
    )

    println("Show target table after updates")
    val actualDf = spark.read.format("delta").load(targetPath)
    actualDf.show()
    actualDf.printSchema()

    assert(actualDf.count() == 3, "1 new insert")
    // assertSmallDatasetEquality(actualDf.drop(IgnoreColsDuringAssert: _*), expectedDf.drop(IgnoreColsDuringAssert: _*), ignoreNullable = true)
    assertSmallDatasetEquality(actualDf, expectedDf, ignoreNullable = true)
  }

  def createTargetDf(): DataFrame = {
    println(s"localDate=$Today")
    val data = Seq(
      // id, name, crt_ts, crt_usr, upd_ts, upd_usr
      /*Row(1, "Alice", Timestamp.valueOf("2023-01-01 00:00:00"), "user1", null, null),
      Row(2, "Bob", Timestamp.valueOf("2023-01-01 00:00:00"), "user2", null, null)*/
      Row(1, "Alice", Today, "user1", null, null),
      Row(2, "Bob", Today, "user2", null, null)
    )
    createDataframeFromCollection(TargetSchema, data)
  }
}