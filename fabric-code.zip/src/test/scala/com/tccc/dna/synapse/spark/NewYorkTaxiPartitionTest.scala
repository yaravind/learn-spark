package com.tccc.dna.synapse.spark

object NewYorkTaxiPartitionTest extends SynapseSparkBase {
  val spark = getSparkSession("NewYorkTaxiPartitionTest", Some("local[4]"))

  val PartitionSize_10MB = 10 * 1000 * 1024
  val PartitionSize_1MB= 1000000
  spark.conf.set("spark.sql.files.maxPartitionBytes", PartitionSize_1MB)

  val taxiDf = spark.read.parquet("/Users/o60774/Documents/WS/datasets/taxi.parquet")
  taxiDf.show(1)

  println("Partitions in-mem: " + Partitions.getNumPartitionsInMem(taxiDf))
//  println("Records per partition: ")
//  val recsPartDf = Partitions.getRecordsPerPartitionInMem(taxiDf)
//  recsPartDf.show(5)
  Thread.sleep(1000 * 60 * 60)
}