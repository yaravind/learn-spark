package com.tccc.dna.synapse.spark

import com.tccc.dna.synapse.spark.test.SparkTestBaseSpec
import org.apache.spark.sql.types._
import org.scalatest.BeforeAndAfterAll

class SynapseSparkTest extends SparkTestBaseSpec with BeforeAndAfterAll {
  test("deepLsToDataFrame nested paths") {
    val filesDf = SynapseSpark.deepLsToDataFrame(Array(getAbsolutePathOfResource("wordcount/nested-dir"), getAbsolutePathOfResource("wordcount/")))
    filesDf.show(truncate = false)
    assert(filesDf.count() == 3)
  }

  test("deepLsToDataFrame multiple paths") {
    val filesDf = SynapseSpark.deepLsToDataFrame(Array(getAbsolutePathOfResource("wordcount/"), getAbsolutePathOfResource("parquet/")))
    filesDf.show(truncate = false)
    assert(filesDf.count() == 5)
  }

  test("deepLsToDataFrame single path") {
    //file:////Users/o60774/ws/tccc-azure-data-utils/src/main/resources/wordcount/
    val path = getAbsolutePathOfResource("wordcount/")
    val filesDf = SynapseSpark.deepLsToDataFrame(Array(path))
    filesDf.show(truncate = false)
    assert(filesDf.count() == 3)
  }

  test("isRunAsManagedIdentity local vs synapse"){
    if(SynapseSpark.isLocalEnv){
      assert(!SynapseSpark.isRunAsManagedIdentity)
    } else {
      assert(SynapseSpark.isRunAsManagedIdentity)
    }
  }
}