package com.tccc.dna.synapse.spark.test

import org.scalatest.{BeforeAndAfterAll, Ignore}
@Ignore
class BeforeAndAfterSubClassTest extends BeforeAfterTest with BeforeAndAfterAll {
  override def beforeAll(): Unit = {
    super.beforeAll()
    println("beforeAll-Subclass")
  }

  override def afterAll(): Unit = {
    super.afterAll()
    println("afterAll-Subclass")
  }

  test("Subclass hello1") {
    println("Subclass test 1")
  }
}
