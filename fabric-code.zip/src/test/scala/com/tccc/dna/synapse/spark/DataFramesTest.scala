package com.tccc.dna.synapse.spark

import com.tccc.dna.synapse.StorageFormat
import com.tccc.dna.synapse.spark.test.SparkTestBaseSpec
import org.apache.commons.io.{Charsets, FileUtils}
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{DataFrame, Row, SaveMode}
import org.apache.spark.sql.types._
import org.scalatest.{BeforeAndAfterAll, Ignore}

import java.io.File
import java.nio.charset.Charset
import java.nio.file.Files

/** sales_type, dcmnt_dt, ovrll_rjctn_status, release, extrnl_invc_no, po_no, sales_dcmnt_id, dlvry_id, shpmnt_id,
 * bllng_dcmnt_id, outlet_no, outlet_name, cstmr_group, sales_group_id, sales_organztn_id, dlvry_plant_code, sales_off,
 * rqst_dlvry_date, sku_no, sku_name_desc, su, order_qty_pc, dlvry_qty_pc, cum_cf_qty_pc, ret, check_in_date,
 * check_out_date, ts, ovrll_status, shpmnt_ovrll, rjctn_reason, usage_no, ovrll_credit_status, bllng_date
 */
class DataFramesTest extends SparkTestBaseSpec with BeforeAndAfterAll {

  def splitValidAndInvalid(inputDf: DataFrame, errorCol: String = "_corrupt_record"): (DataFrame, DataFrame) = {
    // val errorColName = "" //SynapseSpark.getSparkConfProp("spark.sql.columnNameOfCorruptRecord")
    println(s"Splitting based on error column name: $errorCol")
    val invalidDf = inputDf.filter(s"$errorCol IS NOT NULL")
    val validDf = inputDf.filter(s"$errorCol IS NULL")
    (validDf, invalidDf)
  }

  test("getColNamesWithPrefix") {
    val schema = StructType(Seq(
      StructField("employee", StructType(Seq(
        StructField("id", IntegerType),
        StructField("name", StringType),
        StructField("address", StructType(Seq(
          StructField("city", StringType),
          StructField("state", StringType)
        )))
      ))),
      StructField("company", StringType)
    ))
    val data = Seq(
      Row(
        Row(1, "John Doe", Row("New York", "NY")),
        "ABC Inc."
      ),
      Row(
        Row(2, "Jane Doe", Row("San Francisco", "CA")),
        "XYZ Inc."
      )
    )

    val emptyRDD = spark.sparkContext.emptyRDD[Row]
    val emptyDF = spark.createDataFrame(spark.sparkContext.parallelize(data), schema)
    // val df = spark.createDataFrame(spark.sparkContext.emptyRDD, schema)
    /*TODO fix later
    val expected = Seq("df.employee.id", "df.employee.name", "df.employee.address.city", "df.employee.address.state", "df.company")
    val actual = DataFrames.getColumnNames(emptyDF)
    assert(actual.equals(expected))*/
  }

  test("handle schema errors") {
    val spark = SynapseSpark.getActiveSession
    assert(spark != null)
    logInfo(s"Spark version: ${spark.version}")
    logInfo(s"Spark hashcode: ${spark.hashCode()}")
    try {
      println(
        "spark.sql.columnNameOfCorruptRecord=" + SynapseSpark
          .getSparkConfProp("spark.sql.columnNameOfCorruptRecord")
      )
    } catch {
      case ex: java.util.NoSuchElementException =>
        println(ex.getMessage)
      /*println(
          "spark.sql.columnNameOfCorruptRecord=" + SynapseSpark
            .getSparkConfProp("columnNameOfCorruptRecord")
        )*/
    }

    val schemaJson = getResourceAsString("schema_order.json")
    val schema = DataFrames.fromJsonToSchema(schemaJson)
    val readOptions = Map(
      "sep" -> ",",
      "quote" -> "\"", // Quote strings with double quotes
      "escape" -> "\'", // Escape quotes inside strings with another double quote
      "quoteMode" -> "MINIMAL", // Only quote when necessary
      "header" -> "true", // Include column names in the output
      "multiline" -> "true", // Include column names in the output
      "columnNameOfCorruptRecord" -> "_corrupt_record",
      "mode" -> "PERMISSIVE", // FAILFAST, DROPMALFORMED
      "dateFormat" -> "MM/dd/yyyy" // M/d/yyyy
    )

    val orderDf = DataFrames.getDataFrameFromUri(
      "src/test/resources/cs_ph_order_sample.csv",
      StorageFormat.Csv,
      schema,
      addInputFilePath = false,
      readOptions
    )

    println("Total parsed records: " + orderDf.count())
    assert(orderDf.count() == 9) // 422558, 9
    orderDf.show(10)

    val (validDf, invalidDf) = splitValidAndInvalid(orderDf)
    println(s"Invalid record count: ${invalidDf.count()}")
    println(s"Valid record count: ${validDf.count()}")
  }

  test("add audit_file_path to DF") {
    val df = DataFrames.getDataFrameFromUris(StorageFormat.JSON, schema = null,
      Map.empty,
      addInputFilePath = true,
      Array("src/test/resources/people.json")
    )
    df.show(truncate = false)
    assert(df.columns.contains("audit_file_path"))
  }

  test("loadAndValidateJson - addInputFilePath = true should add audit_file_path column with file path") {
    val jsonSchemaStr = getResourceAsString("peopleSchema.json")
    val df = DataFrames.loadAndValidateJson(jsonSchemaStr, addInputFilePath = true, "src/test/resources/people.json")

    df.show(truncate = false)

    assert(df.columns.contains("input_file_path"))
    assert(df.select("input_file_path").take(1)(0).getString(0).contains("people.json"))
  }

  test("loadAndValidateJson - addInputFilePath = false should add input_file_path column with null value") {
    val jsonSchemaStr = getResourceAsString("peopleSchema.json")
    val df = DataFrames.loadAndValidateJson(jsonSchemaStr, addInputFilePath = false, "src/test/resources/people.json")

    df.show(truncate = false)

    assert(df.columns.contains("input_file_path"), "Should have the audit_file_path column")
    assert(df.select("input_file_path").take(1)(0).getString(0) == null, "Value should be null")
  }

  test("loadAndValidateJson - test schema validation") {
    val jsonSchemaStr = getResourceAsString("peopleSchema.json")
    val df = DataFrames.loadAndValidateJson(jsonSchemaStr, addInputFilePath = false, "src/test/resources/people.json")

    df.show(truncate = false)

    df.printSchema()
  }

  test("loadAndValidateJsonV2 - test schema validation") {
    val jsonSchemaStr = getResourceAsString("peopleSchema.json")
    val df = DataFrames.loadAndValidateJsonV2(jsonSchemaStr, addInputFilePath = false, "src/test/resources/people.json")

    df.show(truncate = false)

    val expectedContract = DataFrames.fromJsonToSchema(getResourceAsString("contracts/invalid-data-error.json"))
    val actual = df.schema
    assert(actual.equals(expectedContract))
    //FileUtils.writeStringToFile(new File("src/test/resources/contracts/invalid-data-error.json"), DataFrames.getSchemaAsJson(df), Charset.forName("UTF8"))
    //Writers.writeAsJson(df, "/Users/o60774/Downloads/data/temp_save/invalid-data-json/abc", true, SaveMode.Overwrite)
  }

  test("explosion - test explosion of array columns from dataframe."){
    val schema = new StructType()
      .add("name", StringType)
      .add("age", IntegerType)
      .add("hobby", ArrayType(StringType))
    val df = DataFrames.getDataFrameFromUri("src/test/resources/people_with_array.json", StorageFormat.JSON, schema, false, Map.empty)
    val toBeExplodedColsCfg = Array("hobby")
    val columnsToBeSelected = List.concat(
      DataFrames.getColumnNames(df),
      toBeExplodedColsCfg.map(x => x + "_explode")
    )
    val explodedDf = DataFrames.explosion(
      toBeExplodedColsCfg,
      columnsToBeSelected,
      df
    )
    df.show(false)
    explodedDf.show(false)
    assert(explodedDf.count() == 6, s"Expected count after explode is 6 but got ${explodedDf.count()}")
    val michaelCount = explodedDf.filter(col("name") === "Michael").count()
    assert(michaelCount == 2, s"Exploded count of Michael should be 2 but got ${michaelCount}")
    val andyCount = explodedDf.filter(col("name") === "Andy").count()
    assert(andyCount == 3, s"Exploded count of Michael should be 3 but got ${andyCount}")
    val justinCount = explodedDf.filter(col("name") === "Justin").count()
    assert(justinCount == 1, s"Exploded count of Michael should be 1 but got ${justinCount}")
  }

  test("getDataFrameFromUriWithFilters - without schema"){
    val df = DataFrames.getDataFrameFromUriWithFilters("src/test/resources/people_with_varied_schema.json", StorageFormat.JSON, null, Map.empty)
    df.show(false)
    val expectedSchema = new StructType()
      .add("name", StringType)
      .add("age", StringType)
    assert(df.count() == 3)
    expectedSchema.fields.zip(df.schema.fields).foreach {
      case (expectedField, actualField) =>
        assert(expectedField.dataType == actualField.dataType,
          s"Expected data type ${expectedField.dataType} for column ${expectedField.name}, " +
            s"but got ${actualField.dataType} instead.")
    }
  }
  test("getDataFrameFromUriWithFilters - with schema"){
    val actualSchema = new StructType()
      .add("name", StringType)
      .add("age", IntegerType)
    val df = DataFrames.getDataFrameFromUriWithFilters("src/test/resources/people_with_varied_schema.json", StorageFormat.JSON, actualSchema, Map.empty)
    df.show(false)
    val expectedSchema = new StructType()
      .add("name", StringType)
      .add("age", IntegerType)
    assert(df.count() == 3)
    expectedSchema.fields.zip(df.schema.fields).foreach {
      case (expectedField, actualField) =>
        assert(expectedField.dataType == actualField.dataType,
          s"Expected data type ${expectedField.dataType} for column ${expectedField.name}, " +
            s"but got ${actualField.dataType} instead.")
    }
  }
}