package com.tccc.dna.synapse.spark

import com.microsoft.spark.notebook.msutils.MSFileInfo
import com.tccc.dna.datazones.AuditRecord
import com.tccc.dna.synapse.AzStorage._
import com.tccc.dna.synapse.spark.DataFrames._
import com.tccc.dna.synapse.spark.Partitions.getRecordsPerPartitionInMem
import com.tccc.dna.synapse.spark.SynapseSpark._
import com.tccc.dna.synapse.Utils.getType
import org.apache.hadoop.fs.{FileSystem, LocatedFileStatus, Path, RemoteIterator}

/** *
 * TODO Refactor to extend [[com.tccc.dna.synapse.spark.test.SparkTestBaseSpec]]
 */
object ExampleSparkApp extends SynapseSparkBase {
  logInfo("Example Spark Application")
  val spark = getSparkSession("ExampleSparkApp", Some("local[2]"))

  logInfo(s"Active executors: $activeExecutors")
  logInfo(s"Active executor count: $activeExecutorCount")

  // For implicit conversions like converting RDDs to DataFrames

  import org.apache.spark.sql.functions._
  import spark.implicits._

  val input = Seq(
    (1, 1, 5),
    (1, 2, 5),
    (1, 3, 5),
    (2, 1, 15),
    (2, 2, 5),
    (2, 6, 5)
  ).toDF("Id", "Col 1", "Col 2")

  input
    .groupBy("Id")
    .agg(max(col("Col 1")), sum(col("Col 2")))
    .show()

  val df = spark.read.json("src/test/resources/people.json")
  // Displays the content of the DataFrame to stdout
  df.show()
  // +----+-------+
  // | age|   name|
  // +----+-------+
  // |null|Michael|
  // |  30|   Andy|
  // |  19| Justin|
  // +----+-------+

  // Print the schema in a tree format
  df.printSchema()

  // Select only the "name" column
  logInfo("""Select only the "name" column""")
  df.select("name").show()

  // Select everybody, but increment the age by 1
  df.select($"name", $"age" + 1).show()
  // +-------+---------+
  // |   name|(age + 1)|
  // +-------+---------+
  // |Michael|     null|
  // |   Andy|       31|
  // | Justin|       20|
  // +-------+---------+

  // Select people older than 21
  df.filter($"age" > 21).show()

  // Count people by age
  df.groupBy("age").count().show()
  // +----+-----+
  // | age|count|
  // +----+-----+
  // |  19|    1|
  // |null|    1|
  // |  30|    1|
  // +----+-----+

  //Test getType()
  println("Type of df: " + getType(df))
  println("Type of input: " + getType(input))
  println("Type of spark: " + getType(spark))

  //Test Schema utils
  println(getSchemaAsJson(df))

  println(s"Schema as DDL: ${df.schema.toDDL}")

  //Column rename
  val renamedInputDf = cleanColNames(input)
  renamedInputDf.printSchema()

  //File Path and Name
  val dfWithFilePath = addFileNameCol(df)
  dfWithFilePath.show(truncate = false)

  val path = "file:///Users/o60774/Library/CloudStorage/OneDrive-TheCoca-ColaCompany/Documents/ws/tccc-fabric-data-utils/src/main/resources"

  val files = deepLs(MSFileInfo(name = null, path = path, size = 0, isDir = true, isFile = false, modifyTime = System.currentTimeMillis))
  println("files: " + files.length)
  files.foreach(println(_))

  val recsPerPartition = getRecordsPerPartitionInMem(renamedInputDf)
  recsPerPartition.show()

  println("Nested parquet")
  val blogsDf = spark.read.parquet("/Users/o60774/Downloads/data/blogs.parquet")
  blogsDf.printSchema()
  println("Total blogs: " + blogsDf.count())

  val auditRecord = AuditRecord(appCd = "ExampleApp", subAppCd = "blogs", artifactType = "Test", artifactId = "test id", dataZone = "Raw",
    actionType = "NestedParquet", Map("blogCount" -> blogsDf.count()))
  val auditId = getAuditRepository.save(auditRecord)
  println(s"AuditRecord id: $auditId")
  assert(auditId > -1)
}