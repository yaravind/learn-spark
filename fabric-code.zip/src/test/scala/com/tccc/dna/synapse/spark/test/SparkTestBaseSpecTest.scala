package com.tccc.dna.synapse.spark.test

class SparkTestBaseSpecTest extends SparkTestBaseSpec {
  test("test 1") {
    println("test 1")
  }

  test("test 2") {
    println("test 2")
  }
}
