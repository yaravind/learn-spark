package com.tccc.dna.datazones

import org.scalatest.{BeforeAndAfter, BeforeAndAfterAll}
import org.scalatest.funsuite.AnyFunSuite

import java.sql.{Connection, ResultSet}
import java.time.Instant
import java.util.UUID
import scala.util.{Failure, Success}

class JdbcAuditRepositoryTest extends AnyFunSuite with BeforeAndAfter with BeforeAndAfterAll {
  private val dbManager = DbManager(dbName = "appmetadata")
  private var connection: Connection = _
  private val auditRepo = new JdbcAuditRepository(dbManager)

  override protected def beforeAll(): Unit = {
    println("Resolved driver: " + dbManager.getResolvedDriver)
    println("Resolved JDBC URL: " + dbManager.getResolvedJdbcUrl)
  }

  before {
    dbManager.getConnection match {
      case Success(conn) => connection = conn
      case Failure(exception) => println(exception)
    }
  }

  after {
    dbManager.closeConnection()
  }

  test("save") {
    val auditRecord = AuditRecord(
      auditId = 123L,
      appCode = "test",
      subAppCode = getClass.getSimpleName,
      artifactType = "ArtifactType",
      artifactId = "ArtifactId",
      dataZone = "DataZone",
      actionType = "ActionType",
      pipelineId = UUID.randomUUID(),
      activityId = UUID.randomUUID(),
      createTime = Instant.now(),
      user = "TestUser",
      context = Map(
        "key1" -> "value1",
        "totalFilesToBeProcessed" -> 2
      )
    )
    val auditId: Long = auditRepo.save(auditRecord)
    println("Saved record with generated audit_id: " + auditId)
    assert(auditId > -1)
  }

  test("test H2 Schemas") {
    dbManager.using(connection.createStatement()) { stmt =>
      val rs = stmt.executeQuery("SHOW SCHEMAS")
      while (rs.next()) {
        println("SCHEMA: " + rs.getString(1))
      }
    }
  }

  test("test tables in [sch_ops]") {
    println("SCHEMA: sch_ops")
    dbManager.using(connection.createStatement()) { stmt =>
      val rs = stmt.executeQuery("SHOW TABLES FROM [sch_ops]")
      while (rs.next()) {
        println("\tTABLE: " + rs.getString(1))
      }
    }
  }

  test("DESC [sch_ops].[audit]") {
    val descSql =
      """SELECT *
        |FROM INFORMATION_SCHEMA.COLUMNS
        |WHERE TABLE_NAME = 'audit'
        |""".stripMargin

    dbManager.using(connection.createStatement()) { stmt =>
      val rs = stmt.executeQuery(descSql)
      val auditTableCols: Stream[ColAndType] = auditRepo.resultSetItr(rs)(fromResultSet)

      assert(auditTableCols.nonEmpty)

      auditTableCols.foreach(e => println(s"${e.name} : ${e.dType}"))
    }
  }

  case class ColAndType(name: String, dType: String)

  def fromResultSet(rs: ResultSet): ColAndType = ColAndType(rs.getString("COLUMN_NAME"), rs.getString("DATA_TYPE"))
}