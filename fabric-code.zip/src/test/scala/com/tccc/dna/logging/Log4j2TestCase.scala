package com.tccc.dna.logging

import org.apache.logging.log4j.{LogManager, Logger}

object Log4j2TestCase {
  val rootLogger: Logger = LogManager.getRootLogger
  val comTcccLogger: Logger = LogManager.getLogger("com.tccc")
  val sparkLogger: Logger = LogManager.getLogger("org.apache.spark")
  val parquetLogger: Logger = LogManager.getLogger("org.apache.parquet.CorruptStatistics")

  def logEffectiveLevel(logger: Logger, loggerName: String): Unit = {
    val level = LogManager.getContext.getLogger(loggerName).getLevel
    println(s"Effective log level for $loggerName: $level")
  }

  def main(args: Array[String]): Unit = {

    //Place holder to check log level when needed - Example is shown below
    logEffectiveLevel(parquetLogger, "org.apache.parquet.CorruptStatistics")

    rootLogger.debug("Root Logger Debug Message")
    rootLogger.info("Root Logger Info Message")
    rootLogger.warn("Root Logger Warn Message")
    rootLogger.error("Root Logger Error Message")
    rootLogger.fatal("Root Logger Fatal Message")

    comTcccLogger.debug("com.tccc Debug Message")
    comTcccLogger.info("com.tccc Info Message")
    comTcccLogger.warn("com.tccc Warn Message")
    comTcccLogger.error("com.tccc Error Message")
    comTcccLogger.fatal("com.tccc Fatal Message")

    sparkLogger.debug("Spark Debug Message")
    sparkLogger.info("Spark Info Message")
    sparkLogger.warn("Spark Warn Message")
    sparkLogger.error("Spark Error Message")
    sparkLogger.fatal("Spark Fatal Message")

    parquetLogger.debug("Parquet Debug Message")
    parquetLogger.info("Parquet Info Message")
    parquetLogger.warn("Parquet Warn Message")
    parquetLogger.error("Parquet Error Message")
    parquetLogger.fatal("Parquet Fatal Message")
  }
}
