package com.tccc.dna.datazones.raw

import com.tccc.dna.datazones.init.TableConfig
import com.tccc.dna.datazones.utils.AuditTableRepository
import org.apache.commons.lang3.builder.ToStringBuilder
//import org.apache.commons.lang.builder.{ToStringBuilder}
import org.apache.commons.lang3.builder.ToStringStyle

/**
  * Encapsulates information related to Raw Zone.
 *
  * @param landingZoneProfile Instance of [[LandingZoneProfile]].
  * @param entityName Name of the entity.
  * @param shouldProcessPartialRecords Boolean flag to indicate if partial records should be processed.
  * @param controlFilePath Path to the control file.
 *  @param archivePath Path to the archive directory.
 *  @param inboundPath Path to the inbound directory.
 *  @param validFileSetPath Path to the valid file set directory.
 *  @param invalidFileSetPath Path to the invalid file set directory.
 *  @param invalidDataErrorPath Path to the invalid data error directory.
 *  @param invalidDataFileRejectsPath Path to the invalid data file rejects directory.
 *  @param validDataPath Path to the valid data directory.
 *  @param validDataAdditionalColumnsPath Path to the valid data additional columns directory.
 *  @param currentRunStartHourAndMinute Current run start hour and minute in string.
 *  @param currentRunStartDateTime Current run start date time in string.
 *  @param tableCfg Instance of [[TableConfig]].
 * @param auditTableRepository Instance of [[AuditTableRepository]]
 */
case class RawZoneProfile(landingZoneProfile: LandingZoneProfile,
                          entityName: String,
                          shouldProcessPartialRecords: Boolean,
                          controlFilePath: String,
                          archivePath: String,
                          inboundPath: String,
                          validFileSetPath: String,
                          invalidFileSetPath: String,
                          invalidDataErrorPath: String,
                          invalidDataFileRejectsPath: String,
                          validDataPath: String,
                          validDataAdditionalColumnsPath : String,
                          currentRunStartHourAndMinute: String,
                          currentRunStartDateTime: String,
                          tableCfg: TableConfig,
                          auditTableRepository: AuditTableRepository) {
  /**
    * TO String method for RawZoneProfile
    * @return String representation of RawZoneProfile
    */
  override def toString: String = new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
    .append("landingZoneProfile", landingZoneProfile)
    .append("entityName", entityName)
    .append("shouldProcessPartialRecords", shouldProcessPartialRecords)
    .append("controlFilePath", controlFilePath)
    .append("archivePath", archivePath)
    .append("inboundPath", inboundPath)
    .append("validFileSetPath", validFileSetPath)
    .append("invalidFileSetPath", invalidFileSetPath)
    .append("validDataPath", validDataPath)
    .append("invalidDataErrorPath", invalidDataErrorPath)
    .append("invalidDataFileRejectsPath", invalidDataFileRejectsPath)
    .append("validDataAdditionalColumnsPath", validDataAdditionalColumnsPath)
    .append("currentRunStartHourAndMinute", currentRunStartHourAndMinute)
    .append("currentRunStartDateTime", currentRunStartDateTime)
    .append("tableConfig", tableCfg)
    .append("auditTableRepository", auditTableRepository)
    .toString
}