package com.tccc.dna.datazones.validators

import com.tccc.dna.synapse.Logging
import org.apache.spark.sql.DataFrame

class NoOpSemanticValidator(cacheDf: Boolean = false) extends SemanticValidator with Logging {
  /**
   * Performs '''semantic validation (record by record)''' on the provided DataFrame. A '''new column is added''' to the DataFrame '''for each check'''
   * containing the result of the check performed. The column name is the same as the check name.
   *
   * All checks should be performed on the input DataFrame with the result captured in a new column. There shouldn't be short circuiting of the checks.
   *
   * @param inputDf The DataFrame to be checked.
   * @return The DataFrame with the new columns added for each check performed. For e.g. if 3 checks
   *         '''(isAssetIdUnique, isColumnContainsEmail, isUUIDUnique)''' are
   *         configured then the result schema would have 3 more additional columns with names as
   *         '''isAssetIdUnique, isColumnContainsEmail, isUUIDUnique'''.
   */
  override def check(inputDf: DataFrame): DataFrame = {
    // This class does not perform any operations, it simply returns the input DataFrame
    inputDf
  }
}