package com.tccc.dna.datazones.certified

import com.tccc.dna.datazones.init.TableConfig
import com.tccc.dna.datazones.utils.{DataZoneUtilImpl, DeltaFile, MetadataOperations, SlowlyChangingDimension}
import com.tccc.dna.synapse.spark.{DataFrames, Writers, SynapseSpark => SS}
import com.tccc.dna.synapse.{DataZone, Logging, StorageFormat}
import io.delta.tables.DeltaTable
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SaveMode}

/**
 * Template class to encapsulate general outline and flow of certified zone processing logic.
 *
 * @param certifiedZoneProfile an instance of [[certifiedZoneProfile]]
 *
 */

class CertifiedZoneTemplate(val certifiedZoneProfile: CertifiedZoneProfile
                           ) extends Logging {
  private val RelativeDataPath = "tbl_final/"


  protected val tableConfig: TableConfig = certifiedZoneProfile.tableCfg
  protected val RefinedPath: String = certifiedZoneProfile.refinedFullPath
  protected val FinalRefinedPath: String = RefinedPath + RelativeDataPath
  protected val RelativeConformedPath: String = "tbl_conformed/"
  protected val CertifiedPath: String = certifiedZoneProfile.certifiedFullPath
  protected val FinalCertifiedTablePath: String = CertifiedPath + RelativeDataPath
  protected val PartitionCols: Option[Array[String]] = Some(Array.empty[String])
  var logMessage = ""

  val partitionColumnForAudit = if(PartitionCols.get.length > 0) PartitionCols.get(0) else "audit_submission_date_hr_min"


  /**
   * Primary definition for this class. Used to run the submethods needed to process the certified zone
   *
   * @return Returns the final dataframe after all transformation and processing logic has been completed
   */
  def execute(): DataFrame = {
    logMessage = s"Running certified zone for entity [${certifiedZoneProfile.entityName}]. Base path [$FinalRefinedPath]"
    logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "start certified", logMessage)
    var finalDf = SS.getActiveSession.emptyDataFrame
    val tableUnionDf = loadData(FinalRefinedPath)
    certifiedZoneProfile.auditTableRepository.insertEntityJourneyAuditEntry(tableUnionDf, SS.getCurrentSparkAppName, DataZone.CertifiedZone.toString,
      "CertifiedZoneDataLoad", certifiedZoneProfile.entityName, partitionColumnForAudit, "Start", "DailyRefresh", FinalRefinedPath)
    logMessage = s"Data count after reading from refined zone: " + tableUnionDf.count()
    logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "load refined data", logMessage)

    var conformedDf = postProcessEntity(tableUnionDf)
    logMessage = s"conformed df after post process entity: "
    logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "post process certified", logMessage)

    conformedDf.show(5, false)
    logMessage = s"5. Save: Start"
    logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "write certified data", logMessage)

    val writeMode: String = certifiedZoneProfile.tableCfg.getCertifiedModeOfWrite
    logMessage = s"Write mode: $writeMode"
    logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "write certified data", logMessage)

    logMessage = s"Saving final table to: $FinalCertifiedTablePath"
    logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "write certified data", logMessage)

    writeToCertifiedZone(conformedDf, writeMode, FinalCertifiedTablePath)
    logMessage = s"5. Save: End"
    logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "write certified data", logMessage)
    certifiedZoneProfile.auditTableRepository.insertEntityJourneyAuditEntry(conformedDf, SS.getCurrentSparkAppName, DataZone.CertifiedZone.toString,
      "CertifiedZoneDataLoad", certifiedZoneProfile.entityName, partitionColumnForAudit, "Processed", "DailyRefresh", FinalCertifiedTablePath)

    logMessage = s"*** Read after $writeMode from $FinalCertifiedTablePath"
    logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "end certified", logMessage)

    val outputDf = DeltaFile.readFile(FinalCertifiedTablePath)
    logMessage = s"output count: ${outputDf.count()}"
    logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "end certified", logMessage)

    outputDf.show(5, false)

    logMessage = s"***** Certified Zone for ${certifiedZoneProfile.entityName}: End"
    logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "end certified", logMessage)

    conformedDf
  }

  /**
   * The default implementation of post-processing involves adding following metadata.
   * Following Columns are added as part of the post processing:
   * 1. audit_submission_date
   * 2. crt_hr
   * 3. audit_pipeline_run_id
   * 4. audit_activity_run_id
   * 5. file_name
   * 6. file_path
   * @note Subclasses overriding this method should make sure to call this method using super.postProcessEntity to preserve this behavior.
   *
   * @param df Dataframe of the entity with data from the refined zone
   * @return Returns a dataframe with metadata columns added
   */
  def postProcessEntity(df: DataFrame): DataFrame = {
    logMessage = s"Adding audit_submission_date, crt_hr, audit_pipeline_run_id, audit_activity_run_id, file_name, file_path"
    logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "post process certified", logMessage)

    var enrichedDf = MetadataOperations.addMetadataColumns(df, SS.getUserUUID)
    enrichedDf = DataFrames.addPipelineRunId(enrichedDf)
    enrichedDf = DataFrames.addActivityRunId(enrichedDf)
    if (certifiedZoneProfile.tableCfg.getCertifiedModeOfWrite == "scd2") {
      enrichedDf = addSCDColumns(enrichedDf)
    }
    enrichedDf.show(10, false)


    val certifiedColumnNames = certifiedZoneProfile.tableCfg.getColumns.select("columns_certifiedColumnName").collect
      .map(row => row.getString(row.fieldIndex("columns_certifiedColumnName")) -> row.getString(row.fieldIndex("columns_certifiedColumnName"))).toMap
    val orderedColumnList = certifiedZoneProfile.tableCfg.getColumns.select("columns_certifiedColumnName").collect.map(_.getString(0))
    val columnSeq = enrichedDf.columns.map(x => certifiedColumnNames(x)).toSeq
    enrichedDf = enrichedDf.toDF(columnSeq: _*).select(orderedColumnList.head, orderedColumnList.tail: _*)

    enrichedDf.show(10, false)

    enrichedDf
  }

  /**
   * Definition for reading data from a given directory
   *
   * @param path Directory to read the data from
   * @return Returns a dataframe based on the path given as a parameter
   */

  def loadData(path: String): DataFrame = {
    logMessage = s"Read data from $path: START"
    logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "load refined data", logMessage)

    val certifiedDf = DataZoneUtilImpl.getDataFrameFromUriWithFilters(
      path,
      StorageFormat.Delta,
      null,
      Map.empty,
      certifiedZoneProfile.filterCondition,
      addInputFilePath = false
    )
    logMessage = s"Read data from $path: END"
    logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "load refined data", logMessage)

    return certifiedDf
  }

  /**
   * Definition for writing dataframe to the certified zone
   *
   * @param conformedDf The dataframe to be written to the final directory
   * @param writeMode   Which mode to use when writing the table
   * @param finalPath   Directory path for the dataframe to be written to
   */

  protected def writeToCertifiedZone(conformedDf: DataFrame,
                                   writeMode: String,
                                   finalPath: String): Unit = {
    val userName = SS.getUserUUID
    if (DeltaTable.isDeltaTable(finalPath)) {
      if (writeMode == "upsert") {
        val keyColumns = certifiedZoneProfile.tableCfg.getCertifiedKeyCols
        Writers.upsert(
          finalPath,
          conformedDf,
          keyColumns,
          partitionPruneCols = PartitionCols.get.toList,
          insertExcludeCols = List(
            "audit_upd_ts",
            "audit_upd_usr",
            "audit_crt_ts",
            "audit_crt_usr"
          ),
          updateExcludeCols = List(
            "audit_crt_ts",
            "audit_crt_usr",
            "audit_upd_ts",
            "audit_upd_usr"
          ),
          customInsertExpr = Map(
            "audit_crt_ts" -> "current_timestamp()",
            "audit_crt_usr" -> s"'$userName'"
          ),
          customUpdateExpr = Map(
            "audit_upd_ts" -> "current_timestamp()",
            "audit_upd_usr" -> s"'$userName'"
          )
        )
      } else if (writeMode == "deleteAndInsert") {
        val mergeOnCols = certifiedZoneProfile.tableCfg.getCertifiedOnColumn
        DeltaFile.deleteAndInsert(
          finalPath,
          conformedDf,
          partitionPruneCols = PartitionCols.get.toList,
          mergeOnCols = mergeOnCols,
          insertExcludeCols = List(
            "audit_upd_ts",
            "audit_upd_usr",
            "audit_crt_ts",
            "audit_crt_usr"
          ),
          customInsertExpr = Map(
            "audit_crt_ts" -> "current_timestamp()",
            "audit_crt_usr" -> s"'$userName'"
          )
        )
      } else if (writeMode == "append") {
        Writers.writeAsDelta(
          conformedDf,
          force = true,
          saveToPath = finalPath,
          saveMode = SaveMode.Append,
          partitionColNames = PartitionCols
        )
      }
      else if (writeMode == "scd2") {

        val scd = new SlowlyChangingDimension()
        scd.slowlyChangingDimensionTwo(finalPath, conformedDf, certifiedZoneProfile.tableCfg.getScd2KeyColumns,
          certifiedZoneProfile.tableCfg.getScd2ValueColumns, partitionPruneCols = PartitionCols.get.toList,
          insertExcludeCols = List(
                    "audit_upd_ts",
                    "audit_upd_usr",
                    "audit_crt_ts",
                    "audit_crt_usr"
                  ),
          updateExcludeCols = List(
                    "audit_crt_ts",
                    "audit_crt_usr",
                    "audit_upd_ts",
                    "audit_upd_usr"
                  ),
          customInsertExpr = Map(
                    "audit_crt_ts" -> "current_timestamp()",
                    "audit_crt_usr" -> s"'$userName'"
                  ),
          customUpdateExpr = Map(
                    "audit_upd_ts" -> "current_timestamp()",
                    "audit_upd_usr" -> s"'$userName'"
                  )
        )

      }
      else {
        logInfo("5.1 Mode of write is overwrite.")
        Writers.writeAsDelta(
          conformedDf,
          force = true,
          saveToPath = finalPath,
          saveMode = SaveMode.Overwrite,
          partitionColNames = PartitionCols
        )
      }
    } else {
      logMessage = s"5.1 Delta table not found. Creating new delta table."
      logEntityJourneyEvent(certifiedZoneProfile.entityName, DataZone.CertifiedZone, zoneSubStep = "write certified data", logMessage)

      Writers.writeAsDelta(
        conformedDf,
        force = true,
        saveToPath = finalPath,
        saveMode = SaveMode.Append,
        partitionColNames = PartitionCols
      )
    }
  }

  /**
   * Definition for replacing strings in a dataframe
   *
   * @param inputDf                                   The dataframe to be altered
   * @param columnRegexReplaceStringWithColumnNameMap Map of the strings to be replaced
   * @return Returns a dataframe with replaced columns
   */

  def regexReplaceStringInDf(inputDf: DataFrame, columnRegexReplaceStringWithColumnNameMap: Map[String, String]): DataFrame = {
    var resultDf = inputDf

    for (column <- columnRegexReplaceStringWithColumnNameMap.keys) {

      val replaceStringArray = columnRegexReplaceStringWithColumnNameMap(column).split(",")
      resultDf = resultDf.withColumn(column, col(column).cast(StringType))
      for (replaceString <- replaceStringArray) {
        println(s"column: $column, replaceString: $replaceString")

        resultDf = resultDf.withColumn(
          column,
          regexp_replace(col(column), replaceString, "")
        )
      }
    }
    resultDf
  }

  /**
   * Add effective start date and end date columns to the dataframe for scd 2 type ingestion.
   *
   * @param df The dataframe to be altered.
   * @return Returns a dataframe with added columns.
   */
  protected def addSCDColumns(df: DataFrame): DataFrame = {

    val scd = new SlowlyChangingDimension()

    if(certifiedZoneProfile.tableCfg.getScd2UseCustomExpressionForEffectiveStartDate){
      val customExpression = certifiedZoneProfile.tableCfg.getScd2CustomExpressionForEffectiveStartDate
      return scd.addSCD2ColumnsWithCustomExpression(df, customExpression)
    }else{
      return scd.addSCD2Columns(df,certifiedZoneProfile.tableCfg.getScd2CreatedAtColumnName, certifiedZoneProfile.tableCfg.getScd2UpdatedAtColumnName)
    }
  }
}
