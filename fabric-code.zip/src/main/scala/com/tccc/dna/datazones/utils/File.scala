package com.tccc.dna.datazones.utils

import com.tccc.dna.synapse.spark.SynapseSpark
import com.tccc.dna.synapse.{Logging, StorageFormat}
import org.apache.spark.sql.DataFrame

/** trait having all default file related methods
  */
abstract class File extends Logging {
  /**
    * Read a file from the given path and return a DataFrame.
    *
    * @param path Path of the file to be read.
    * @param additionalOption Additional options to be passed to the reader.
    * @param fileFormat File format of the file to be read.
    * @return DataFrame read from the file.
    */
  def readFile(path: String, additionalOption: Map[String, String] = Map(), fileFormat: StorageFormat): DataFrame = {
    SynapseSpark.getActiveSession.read
      .format(fileFormat.toString)
      .options(additionalOption)
      .load(path)
  }

  /**
    * Write a DataFrame to the given path.
    *
    * @param dataFrame DataFrame to be written.
    * @param path Path where the DataFrame is to be written.
    * @param mode Mode of writing the DataFrame.
    * @param additionalOption Additional options to be passed to the writer.
    * @param fileFormat File format of the file to be written.
    */
  def writeFile(
      dataFrame: DataFrame,
      path: String,
      mode: String = "overwrite",
      additionalOption: Map[String, String] = Map(),
      fileFormat: StorageFormat
  ): Unit = {
    logInfo(
      s"Backup options: path: $path, mode: $mode, additionalOption: $additionalOption"
    )
    dataFrame.printSchema()
    dataFrame.write
      .format(fileFormat.toString)
      .mode(mode)
      .options(additionalOption)
      .save(path)
  }
}