package com.tccc.dna.datazones

import com.tccc.dna.synapse.spark.SynapseSpark

import java.time.Instant
import java.util.UUID

/**
 * DTO for Table: [sch_ops].[audit].
 *
 * @param auditId
 * @param appCode
 * @param subAppCode
 * @param artifactType
 * @param artifactId
 * @param dataZone
 * @param actionType
 * @param pipelineId
 * @param activityId
 * @param createTime
 * @param user
 * @param context Arbitrary Name/Value pairs that will be stored as [[https://learn.microsoft.com/en-us/azure/azure-sql/database/json-features?view=azuresql
 *                JSON]] in the audit database.
 */
case class AuditRecord(auditId: Long, appCode: String, subAppCode: String, artifactType: String, artifactId: String, dataZone: String,
                       actionType: String, pipelineId: UUID, activityId: UUID, createTime: Instant = Instant.now(), user: String, context: Map[String, Any]) {
}

object AuditRecord {
  def apply(appCd: String, subAppCd: String, artifactType: String, artifactId: String, dataZone: String,
            actionType: String, context: Map[String, Any]): AuditRecord = {
    new AuditRecord(
      auditId = -1, //This will be auto-generated as an IDENTITY column.
      appCode = appCd,
      subAppCode = subAppCd,
      artifactType = artifactType,
      artifactId = artifactId,
      dataZone = dataZone,
      actionType = actionType,
      pipelineId = UUID.fromString(SynapseSpark.getCurrentPipelineRunId),
      activityId = UUID.fromString(SynapseSpark.getCurrentPipelineActivityRunId),
      createTime = Instant.now(),
      user = SynapseSpark.getCurrentUserName,
      context = context)
  }
}