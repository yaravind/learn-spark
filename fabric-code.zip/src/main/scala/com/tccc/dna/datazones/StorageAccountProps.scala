package com.tccc.dna.datazones

/**
 * Encapsulates properties related to storage account. A full ADLS Gen 2 path is created as follows:
 * {{{f"abfss://$containerOrFileSys@$storageAcct.dfs.core.windows.net/$path"}}}
 *
 * @param storageAcct        Name of the storage account where landing folder is located.
 * @param containerOrFileSys Name if the container that holds landing files and folders.
 * @param path               A forward slash delimited (/) representation of the directory structure. Relative path from the container. Use
 *                           [[https://spark.apache.org/docs/latest/sql-data-sources-generic-options.html glob pattern]] to represent file sets.
 *
 */
case class StorageAccountProps(storageAcct: String, //"sause2tccctstdev001",
                               containerOrFileSys: String, //"dam-adobe"
                               path: String //aem/asset-created/2023/11/*/asset-created-*.json
                              )