package com.tccc.dna.datazones.utils

import com.tccc.dna.synapse.spark.SynapseSpark
import com.tccc.dna.synapse.{Logging, StorageFormat}
import io.delta.tables._
import org.apache.spark.sql.DataFrame

/** Object has all Delta format specific implementation
 */
object DeltaFile extends File with Logging {

  //read delta file. Added file format as a default parameter. Need to pass options as a map.

  /**
   * Read a delta file from the given path.
   *
   * @param path  Path of the delta file.
   * @param additionalOption Additional options to be passed to the reader.
   * @param fileFormat File format of the file.
   * @return DataFrame
   */
  override def readFile(
                         path: String,
                         additionalOption: Map[String, String] = Map(),
                         fileFormat: StorageFormat = StorageFormat.Delta
                       ): DataFrame = {
    super.readFile(path, additionalOption, fileFormat)
  }

  //Write delta file. you have option to specify the mode you want to write the file.

  /**
   * Write a DataFrame to the given path.
   *
   * @param dataFrame DataFrame to be written.
   * @param path Path where the DataFrame is to be written.
   * @param mode Mode of writing the file.
   * @param additionalOption Additional options to be passed to the writer.
   * @param fileFormat File format of the file.
   */
  override def writeFile(
                          dataFrame: DataFrame,
                          path: String,
                          mode: String = "overwrite",
                          additionalOption: Map[String, String] = Map(),
                          fileFormat: StorageFormat = StorageFormat.Delta
                        ): Unit = {
    super.writeFile(dataFrame, path, mode, additionalOption, fileFormat)
  }

  //Delete the record in the existing delta file when it is matched in the new delta file

  //insert all the new records to the existing dataframe

  /**
   * Insert all the new records to the existing delta file.
   *
   * @param path Path of the delta file.
   * @param sourceDf DataFrame to be inserted.
   * @param mergeCondition Condition to be used for merging.
   * @param finalInsertExpr Final insert expression.
   */
  def insertRecord(
                            path: String,
                            sourceDf: DataFrame,
                            mergeCondition: String,
                            finalInsertExpr: Map[String, String]
                          ): Unit = {
    var targetTable = DeltaTable.forPath(SynapseSpark.getActiveSession, path)
    targetTable
      .as("target")
      .merge(sourceDf.as("source"), mergeCondition)
      .whenNotMatched()
      .insertExpr(finalInsertExpr)
      .execute()
  }

  //call for deleteRecord And insert record


  /**
   * insert all the new records to the existing delta file.
   *
   * @param targetPath Path of the delta file.
   * @param sourceDf DataFrame to be inserted.
   * @param mergeOnCols Columns to be used for merging.
   */
  def insert(targetPath: String,
             sourceDf: DataFrame,
             partitionPruneCols: List[String] = List(),
             mergeOnCols: List[String],
             insertExcludeCols: List[String] = List(),
             customInsertExpr: Map[String, String] = Map()):Unit ={
    println(s"targetPath: $targetPath, mergeOnCols: [${mergeOnCols.mkString(", ")}], partitionPruneCols: [${partitionPruneCols.mkString(", ")}]")
    println(s"insertExcludeCols: [${insertExcludeCols.mkString(", ")}]")
    println(s"customInsertExpr:  [${customInsertExpr.mkString(", ")}]")


    println(s"Source count before distinct: ${sourceDf.count()}")

    val mergeCols = sourceDf.columns
      .map(colName => (s"target.$colName", s"source.$colName"))
      .toMap
    val tempInsertExpr = mergeCols.filterKeys(col => {
      val lookup = col.replace("target.", "")
      !insertExcludeCols.contains(lookup)
    })
    val finalInsertExpr = tempInsertExpr ++ customInsertExpr

    println("Filtered cols from insertExpr: " + mergeCols.keySet.diff(finalInsertExpr.keySet))
    println(s"insertExpr: $finalInsertExpr")

    val mergeCondition = mergeOnCols.map(col => s"target.$col = source.$col").mkString(" AND ")
    println(s"mergeCondition: $mergeCondition")
    println("\nInserting New Records")
    insertRecord(targetPath, sourceDf, mergeCondition, finalInsertExpr)
    println("Insert Action is successful")

  }


  /**
   * Delete the record in the existing delta file when it is matched in the new delta file and insert all the new records to the existing delta file.
   *
   * @param targetPath Path of the delta file.
   * @param sourceDf DataFrame to be inserted.
   * @param partitionPruneCols Columns to be used for partition pruning.
   * @param mergeOnCols Columns to be used for merging.
   * @param insertExcludeCols Columns to be excluded from insert.
   * @param customInsertExpr Custom insert expression.
   */
  def deleteAndInsert(
                       targetPath: String,
                       sourceDf: DataFrame,
                       partitionPruneCols: List[String] = List(),
                       mergeOnCols: List[String],
                       insertExcludeCols: List[String] = List(),
                       customInsertExpr: Map[String, String] = Map()
                     ): Unit = {

    println(s"targetPath: $targetPath, mergeOnCols: [${mergeOnCols.mkString(", ")}], partitionPruneCols: [${partitionPruneCols.mkString(", ")}]")
    println(s"insertExcludeCols: [${insertExcludeCols.mkString(", ")}]")
    println(s"customInsertExpr:  [${customInsertExpr.mkString(", ")}]")


    println(s"Source count before distinct: ${sourceDf.count()}")

    //deleteRecord(targetPath, sourceDf, mergeOnCols)
    val mergeCols = sourceDf.columns
      .map(colName => (s"target.$colName", s"source.$colName"))
      .toMap
    val tempInsertExpr = mergeCols.filterKeys(col => {
      val lookup = col.replace("target.", "")
      !insertExcludeCols.contains(lookup)
    })
    val finalInsertExpr = tempInsertExpr ++ customInsertExpr

    println("Filtered cols from insertExpr: " + mergeCols.keySet.diff(finalInsertExpr.keySet))
    println(s"insertExpr: $finalInsertExpr")

    val target = DeltaTable.forPath(targetPath)
    val selectDf =
      sourceDf
        //.withColumn("asset_id", col("asset_id").cast(StringType))
        //.select("asset_id")
        .dropDuplicates(mergeOnCols)
    //.distinct()

    println(s"Source count after distinct: ${selectDf.count()}")

    println(s"Target count before deleting: ${target.toDF.count()}")
    val mergeCondition = mergeOnCols.map(col => s"target.$col = source.$col").mkString(" AND ")
    println(s"mergeCondition: $mergeCondition")
    // Start a new Merge (Upsert) query
    target.alias("target")
      .merge(selectDf.alias("source"), "target.asset_id = source.asset_id") //"target.asset_id = source.asset_id"  mergeCondition
      .whenMatched().delete() // Delete matched rows
      //.whenNotMatched().insertAll()
      .execute() // Insert the rows which aren't present in target
    println(s"count After delete matched and insert unmatched: ${DeltaTable.forPath(targetPath).toDF.count()}")


    println("\nInserting New Records")
    insertRecord(targetPath, sourceDf, mergeCondition, finalInsertExpr)
    println("Insert Action is successful")
  }

  /**
   * Update the record in the existing delta file when it is matched in the new delta file.
   *
   * @param targetPath Path of the delta file.
   * @param sourceDf DataFrame to be inserted.
   * @param mergeOnCols Columns to be used for merging.
   * @param partitionPruneCols Columns to be used for partition pruning.
   * @param updateExcludeCols Columns to be excluded from update.
   * @param customUpdateExpr Custom update expression.
   */
  def update(targetPath: String,
             sourceDf: DataFrame,
             mergeOnCols: List[String],
             partitionPruneCols: List[String] = List(),
             updateExcludeCols: List[String] = List(),
             customUpdateExpr: Map[String, String] = Map()): Unit = {
    println(
      s"targetPath: $targetPath, mergeOnCols: [${mergeOnCols.mkString(", ")}], partitionPruneCols: [${
        partitionPruneCols
          .mkString(", ")
      }]"
    )
    println(s"updateExcludeCols: [${updateExcludeCols.mkString(", ")}]")
    println(s"customUpdateExpr:  [${customUpdateExpr.mkString(", ")}]")

    val targetTable =
      DeltaTable.forPath(SynapseSpark.getActiveSession, targetPath)
    val targetDf = targetTable.toDF
    println(
      s"Target table cols (${targetDf.columns.length})    : ${targetDf.columns.mkString(", ")}"
    )
    println(
      s"Source Dataframe cols (${sourceDf.columns.length}): ${sourceDf.columns.mkString(", ")}"
    )

    /*val mergeCols = sourceDf.columns

    val updateExpr = mergeCols.map(colName => (s"target.$colName", s"source.$colName")).toMap*/
    val mergeCols = sourceDf.columns
      .map(colName => (s"target.$colName", s"source.$colName"))
      .toMap
    val tempUpdateExpr = mergeCols.filterKeys(col => {
      val lookup = col.replace("target.", "")
      !updateExcludeCols.contains(lookup)
    })

    val finalUpdateExpr = tempUpdateExpr ++ customUpdateExpr
    println(
      "Filtered cols from updateExpr: " + mergeCols.keySet
        .diff(finalUpdateExpr.keySet)
    )

    //val insertExpr: mutable.Map[String, String] = mutable.Map[String, String]() ++= finalUpdateExpr

    println(s"updateExpr: $finalUpdateExpr")

    val mergeCondition =
      mergeOnCols.map(col => s"target.$col = source.$col").mkString(" AND ")
    println(s"mergeCondition: [$mergeCondition]")

    targetTable
      .as("target")
      .merge(sourceDf.as("source"), mergeCondition)
      .whenMatched
      .updateExpr(finalUpdateExpr)
      .execute()
  }


  /**
   * Slowly Changing Dimension Type 2
   * @param targetPath target path of the delta table
   * @param sourceDf source dataframe to inserted or updated
   * @param joinCols Surrogate key columns
   * @param scdColumnList scd values changing columns list
   * @param partitionPruneCols partition prune columns
   * @param insertExcludeCols insert exclude columns while inserting the data
   * @param updateExcludeCols update exclude columns while updating the data
   * @param customInsertExpr custom insert expression for the new records
   * @param customUpdateExpr custom update expression for the existing records
   */
  def slowlyChangingDimensionTwo(targetPath: String,
                                 sourceDf: DataFrame,
                                 joinCols: List[String],
                                 scdColumnList: List[String],
                                 effectiveStartDateColumnName: String,
                                 effectiveEndDateColumnName: String,
                                 isCurrentFlagColumnName: String,
                                 partitionPruneCols: List[String] = List(),
                                 insertExcludeCols: List[String] = List(),
                                 updateExcludeCols: List[String] = List(),
                                 customInsertExpr: Map[String, String] = Map(),
                                 customUpdateExpr: Map[String, String] = Map()): Unit = {
    println(
      s"targetPath: $targetPath, mergeOnCols: [${joinCols.mkString(", ")}], partitionPruneCols: [${
        partitionPruneCols
          .mkString(", ")
      }]"
    )
    println(s"insertExcludeCols: [${insertExcludeCols.mkString(", ")}]")
    println(s"updateExcludeCols: [${updateExcludeCols.mkString(", ")}]")
    println(s"customInsertExpr:  [${customInsertExpr.mkString(", ")}]")
    println(s"customUpdateExpr:  [${customUpdateExpr.mkString(", ")}]")

    val targetTable =
      DeltaTable.forPath(SynapseSpark.getActiveSession, targetPath)
    val targetDf = targetTable.toDF

    println(
      s"Target table cols (${targetDf.columns.length})    : ${targetDf.columns.mkString(", ")}"
    )
    println(
      s"Source Dataframe cols (${sourceDf.columns.length}): ${sourceDf.columns.mkString(", ")}"
    )
    val mergeCols = sourceDf.columns
      .map(colName => (s"target.$colName", s"sources.$colName"))
      .toMap
    mergeCols.foreach(println)

    //    Insert Expression
    val tempInsertExpr = mergeCols.filterKeys(col => {
      val lookup = col.replace("target.", "")
      !insertExcludeCols.contains(lookup)
    })
    val finalInsertExpr = tempInsertExpr ++ customInsertExpr
    println(
      "Filtered cols from insertExpr: " + mergeCols.keySet
        .diff(finalInsertExpr.keySet)
    )
    println(finalInsertExpr)

    //Update Expression
    val finalUpdateExpr = Map(s"${effectiveEndDateColumnName}" -> s"sources.${effectiveStartDateColumnName}", s"${isCurrentFlagColumnName}" -> "'n'") ++
      customUpdateExpr

    val whereCondition = s"target.${effectiveEndDateColumnName} == '9999-12-31' AND target.${isCurrentFlagColumnName} == 'y' AND " + scdColumnList.map(col =>
      s"sources.${col} <> target.${col}")
      .mkString(" AND ")
    println(whereCondition)

    val newRowsToInsert = sourceDf
      .as("sources")
      .join(targetDf.as("target"), joinCols)
      .select("sources.*")
      .where(whereCondition)

    newRowsToInsert.show(10, false)

    val stagedUpdates = newRowsToInsert
      .selectExpr("NULL as mergeKey", "*")
      .union(
        sourceDf.selectExpr(s"concat(${joinCols.mkString(",")}) as mergeKey", "*")
      )
    stagedUpdates.show(10, false)
    //
    targetTable
      .as("target")
      .merge(
        stagedUpdates.as("sources"),
        s"""concat(${joinCols.map(col => s"target.${col}").mkString(",")}) = mergeKey""")
      .whenMatched(whereCondition)
      .updateExpr(finalUpdateExpr)
      .whenNotMatched()
      .insertExpr(finalInsertExpr)
      .execute()
  }


}