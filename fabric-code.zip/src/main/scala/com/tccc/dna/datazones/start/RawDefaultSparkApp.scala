package com.tccc.dna.datazones.start

import com.tccc.dna.datazones.init.{ApplicationConfig, TableConfig}
import com.tccc.dna.datazones.raw.{RawZoneImpl, RawZoneProfileRepository, RawZoneProfileRepositoryImpl}
import com.tccc.dna.datazones.utils.AuditTableRepository
import com.tccc.dna.synapse.DataZone
import com.tccc.dna.synapse.spark.{SynapseSpark => SS}
import org.apache.spark.sql.DataFrame


/**
 * RawDefaultSparkApp is a class that extends AllZoneSparkBaseApp and is used to process data in the raw zone.
 * @see https://wiki.coke.com/confluence/pages/viewpage.action?pageId=208251821
 */
abstract class RawDefaultSparkApp extends AllZoneSparkBaseApp {
  /**
   * This method is used to process data in the raw zone.
   *
   * @param entityName      The name of the entity being processed
   * @param controlFilePath The path to the control file
   * @param appName         The name of the application being run
   * @param auditTable      The audit table repository to audit entries
   * @return DataFrame
   */
  override def tableRunner(entityName: String, controlFilePath: String, appName: String, auditTable: AuditTableRepository): DataFrame = {
    // create table config
    val tableCfg = new TableConfig()
    tableCfg.loadConfig(controlFilePath, appName, entityName)

    //Create rawZoneProfileRepository
    val rawZoneProfileRepository = getRawZoneProfileRepository(appName, environmentConfig.currentRunStartHourAndMinute,
      environmentConfig.currentRunStartDateTime, applicationConfig, tableCfg, auditTable)
    
    //Get the landing path
    val generalCsvSourcePath = applicationConfig.getBaseLandingPath
    val landingPath = generalCsvSourcePath + s"${tableCfg.getDropZoneEntityName}/"
    logMessage = s"entity: $entityName,  controlPath: $controlFilePath, landingPath: $landingPath, appName: $appName"
    logEntityJourneyEvent(entityName, DataZone.RawZone, zoneSubStep = "driver", logMessage)

    //1. Raw

    val rawZoneProfile = rawZoneProfileRepository.getRawZoneProfile(entityName, tableCfg)
    val loadSemanticData = rawZoneProfileRepository.getLoader(entityName, tableCfg)
    val structuralValidator = rawZoneProfileRepository.getRawStructuralValidator(entityName)
    val semanticValidator = rawZoneProfileRepository.getRawSemanticValidator(entityName)
    var rawDf = SS.getActiveSession.emptyDataFrame


    val rawZone = new RawZoneImpl(
      rawZoneProfile,
      structuralValidator,
      semanticValidator,
      loadSemanticData
    )
    rawDf = rawZone.execute()
    rawDf.show(truncate = false)
    if (rawDf.isEmpty) {
      logMessage = s"No records were saved to Raw zone for $entityName. Short-circuiting the job."
      logEntityJourneyEvent(entityName, DataZone.RawZone, zoneSubStep = "driver", logMessage)
      return rawDf
    }
    //    auditTable.insertToAuditTable(rawDf, "raw", entityName, "audit_submission_date_hr_min", "processed", "full")
    rawDf.show(truncate = false)
    rawDf
  }

  /**
   * This method is used to get the RawZoneProfileRepository.
   *
   * @param appName                      The name of the application being run
   * @param currentRunStartHourAndMinute The current run start date with hour and minute
   * @param currentRunStartDateTime      The current run start date time
   * @param applicationConfig            The application configuration
   * @param tableCfg                     The table configuration
   * @return RawZoneProfileRepository
   */
  protected def getRawZoneProfileRepository(appName: String, currentRunStartHourAndMinute: String, currentRunStartDateTime: String,
                                            applicationConfig: ApplicationConfig, tableCfg: TableConfig, auditTableRepository: AuditTableRepository): RawZoneProfileRepository = {

    new RawZoneProfileRepositoryImpl(appName, currentRunStartHourAndMinute,
      currentRunStartDateTime, applicationConfig, tableCfg, auditTableRepository)

  }

  /**
   * This method is used to get the data zone.
   *
   * @return DataZone
   */
  override protected def getDataZone: DataZone = {
    DataZone.RawZone
  }
}
