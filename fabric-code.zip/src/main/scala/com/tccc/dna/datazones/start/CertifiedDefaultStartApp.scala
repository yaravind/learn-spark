package com.tccc.dna.datazones.start

import com.tccc.dna.datazones.certified.{CertifiedZoneProfile, CertifiedZoneProfileRepository, CertifiedZoneProfileRepositoryImpl, CertifiedZoneTemplate}
import com.tccc.dna.datazones.init.{ApplicationConfig, TableConfig}
import com.tccc.dna.datazones.utils.AuditTableRepository
import com.tccc.dna.synapse.DataZone
import com.tccc.dna.synapse.spark.{SynapseSpark => SS}
import org.apache.spark.sql.DataFrame

/**
 * CertifiedDefaultStartApp is a class that extends AllZoneSparkBaseApp and is used to process data in the certified zone.
 * @see https://wiki.coke.com/confluence/pages/viewpage.action?pageId=203593332
 */
abstract class CertifiedDefaultStartApp extends AllZoneSparkBaseApp {

  /**
   * This method is used to process data in the certified zone.
   *
   * @param entityName      The name of the entity being processed
   * @param controlFilePath The path to the control file
   * @param appName         The name of the application being run
   * @param auditTable      The audit table repository to audit entries
   * @return DataFrame
   */
  override def tableRunner(entityName: String, controlFilePath: String, appName: String, auditTable: AuditTableRepository): DataFrame = {
    //Certified filter condition
    var filterCondition: Map[String, Array[String]] = getcertifiedAuditFilterCondition(entityName, auditTable)

    var certifiedDf = SS.getActiveSession.emptyDataFrame

    if (filterCondition.nonEmpty) {

      //initialize table config
      val tableCfg = getTableConfig(controlFilePath, appName, entityName)
      //get certifiedZoneProfile
      val certifiedZoneProfile = getCertifiedZoneProfile(entityName, tableCfg, filterCondition, auditTable)

      if (tableCfg.getCertifiedModeOfWrite == "overwrite") {
        //logInfo("filter condition before getting last element:")
        logMessage = s"filter condition before getting last element:"
        logEntityJourneyEvent(entityName, currentDataZone, zoneSubStep = "runner", logMessage)
        filterCondition.foreach(println)
        filterCondition = Map(filterCondition.last)
        //logInfo("filter condition after getting last element:")
        logMessage = s"filter condition after getting last element:"
        logEntityJourneyEvent(entityName, currentDataZone, zoneSubStep = "runner", logMessage)
        filterCondition.foreach(println)
      }
      logMessage = s"Filter condition: ${filterCondition.mkString}"
      logEntityJourneyEvent(entityName, DataZone.CertifiedZone, zoneSubStep = "runner", logMessage)

      val certifiedZone = getCertifiedZoneTemplate(certifiedZoneProfile)
      certifiedDf = certifiedZone.execute()
    }
    else {
      logMessage = "There is no data to process in refined zone."
      logEntityJourneyEvent(entityName, DataZone.CertifiedZone, zoneSubStep = "runner", logMessage)
      return certifiedDf
    }
    certifiedDf.show(truncate = false)


    certifiedDf.show(truncate = false)
    certifiedDf
  }


  protected def getcertifiedAuditFilterCondition(entityName: String, auditTable: AuditTableRepository) = {
    auditTable.getNextProcessingPartitionsAsFilter(DataZone.CertifiedZone.toString, entityName)
  }

  /**
   * This method is used to get the certified zone profile repository.
   *
   * @param appName           The name of the application being run
   * @param applicationConfig The application configuration
   * @return CertifiedZoneProfileRepository
   */
  protected def getCertifiedZoneProfileRepository(appName: String, applicationConfig: ApplicationConfig, auditTableRepository: AuditTableRepository): CertifiedZoneProfileRepository = {
    new CertifiedZoneProfileRepositoryImpl(appName, applicationConfig, auditTableRepository)
  }

  protected def getCertifiedZoneProfile(entityName: String, tableCfg: TableConfig, filterCondition: Map[String, Array[String]], auditTableRepository: AuditTableRepository): CertifiedZoneProfile = {
    getCertifiedZoneProfileRepository(appName, applicationConfig, auditTableRepository).getCertifiedZoneProfile(entityName, tableCfg, filterCondition)
  }

  protected def getCertifiedZoneTemplate(certifiedZoneProfile: CertifiedZoneProfile) = {
    new CertifiedZoneTemplate(certifiedZoneProfile)
  }

  /**
   * This method is used to get the data zone.
   *
   * @return DataZone
   */
  override protected def getDataZone: DataZone = {
    DataZone.CertifiedZone
  }

}
