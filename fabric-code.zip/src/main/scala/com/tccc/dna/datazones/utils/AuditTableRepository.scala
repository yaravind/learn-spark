package com.tccc.dna.datazones.utils

import com.tccc.dna.synapse.spark.{DataFrames, Writers, SynapseSpark => SS}
import com.tccc.dna.synapse.{DataZone, Logging, StorageFormat}
import io.delta.tables.DeltaTable
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{LongType, StringType, StructType, TimestampType}
import org.apache.spark.sql.{DataFrame, Row, SaveMode}

import java.time.Instant

/**
 * AuditTableRepository is a class that is used to interact with the audit table.
 * Table does following:
 * 1. Keeps status of each file/entity processed for Raw, Refined and Certified Zone.
 * 2. Enables processing of each zones independently.
 * 3. Enables restart of application from failure point.
 *
 * Table Structure:
	[app_name] nvarchar(4000),
	[data_zone] nvarchar(4000),
	[event_type] nvarchar(4000),
	[process_sub_step] nvarchar(4000),
	[entity_name] nvarchar(4000),
	[file_name] nvarchar(4000),
	[file_path] nvarchar(4000),
	[partition_column] nvarchar(4000),
	[partition_value] nvarchar(4000),
	[processed_partition] datetime2(7),
	[status] nvarchar(4000),
	[row_count] bigint,
	[crt_ts] datetime2(7),
	[load_type] nvarchar(4000),
	[pipeline_run_id] nvarchar(4000),
	[pipeline_activity_run_iD] nvarchar(4000),
	[spark_app_id] nvarchar(4000),
	[spark_app_name] nvarchar(4000),
	[livy_id] nvarchar(4000)
 *
 * @param path The path to the audit table
 */
class AuditTableRepository(path: String) extends Logging{

  private val pipelineRunId = SS.getCurrentPipelineRunId
  private val pipelineActivityRunId = SS.getCurrentPipelineActivityRunId
  private val sparkAppID = SS.getCurrentSparkAppId
  private val sparkAppName = SS.getCurrentSparkAppName
  private val livyId = SS.getLivySessionId
  private val schema = (new StructType)
    .add("app_name", StringType)
    .add("data_zone", StringType)
    .add("event_type", StringType)
    .add("process_sub_step", StringType)
    .add("entity_name", StringType)
    .add("file_name", StringType)
    .add("file_path", StringType)
    .add("partition_column", StringType)
    .add("partition_value", StringType)
    .add("processed_partition", TimestampType)
    .add("status", StringType)
    .add("row_count", LongType)
    .add("crt_ts", TimestampType)
    .add("load_type", StringType)
    .add("pipeline_run_id", StringType)
    .add("pipeline_activity_run_iD", StringType)
    .add("spark_app_id", StringType)
    .add("spark_app_name", StringType)
    .add("livy_id", StringType)

  if(!DeltaTable.isDeltaTable(SS.getActiveSession, path)) {
    logDataZoneEvent(DataZone.Other, "audit table creation", s"Delta table at ${path} does not exist. Creating the audit table.")
    createAuditTable(path)
  }


  /**
   * This method is used to create the audit table if it does not exist.
   * @param path The path to the audit table
   */
  def createAuditTable(path: String) : Unit ={

    val df = SS.getActiveSession.createDataFrame(SS.getActiveSession.sparkContext.emptyRDD[Row], schema)
    df.write.format("delta").save(path)
    Writers.writeAsDelta(
      df,
      force = true,
      saveToPath = path,
      saveMode = SaveMode.Append
    )
  }

  /**
   * This method is used to insert data zone entries entries into the audit table.
   * @param appName The name of the application
   * @param dataZone The data zone
   * @param entityName The name of the entity
   * @param status The status of the entry
   */
  def insertDataZoneAuditEntry(appName: String, dataZone: String, entityName: String, status: String, loadType: String): Unit = {
    val row = Seq(Row(appName, dataZone, "Datazone", null,  entityName, null, null, null, null, null, status, null, null, loadType, pipelineRunId,
      pipelineActivityRunId, sparkAppID, sparkAppName, livyId))
    val df = SS.getActiveSession.createDataFrame(SS.getActiveSession.sparkContext.parallelize(row), schema).withColumn("crt_ts", lit(Instant.now).cast(TimestampType))
    Writers.writeAsDelta(
      df,
      force = true,
      saveToPath = path,
      saveMode = SaveMode.Append
    )
  }

  def insertEntityJourneyAuditEntry(df: DataFrame, appName: String, dataZone: String, processSubStep: String,entityName: String,
                              partitionColumn: String,
                                       status: String, loadType: String, baseFilePath: String)
  : Unit ={
    var auditTableDf = df.select("audit_file_name", partitionColumn).groupBy(partitionColumn, "audit_file_name")
      .agg(
        count(col(partitionColumn)).as("row_count"),
        first(col(partitionColumn)).as("partition_value"),
        first(col("audit_file_name")).as("file_name")
      )
      .withColumn("app_name", lit(appName))
      .withColumn("data_zone", lit(dataZone))
      .withColumn("event_type", lit("EntityJourney"))
      .withColumn("process_sub_step", lit(processSubStep))
      .withColumn("entity_name", lit(entityName))
      .withColumn("partition_column", lit(partitionColumn))
      .withColumn("processed_partition", lit(Instant.now()).cast(TimestampType))
      .withColumn("status", lit(status))
      .withColumn("crt_ts", lit(Instant.now()).cast(TimestampType))
      .withColumn("load_type", lit(loadType))
      .withColumn("pipeline_run_id", lit(pipelineRunId))
      .withColumn("pipeline_activity_run_iD", lit(pipelineActivityRunId))
      .withColumn("spark_app_id", lit(sparkAppID))
      .withColumn("spark_app_name", lit(sparkAppName))
      .withColumn("livy_id", lit(livyId))
//      .withColumnRenamed("audit_file_name", "file_name")

    (dataZone, status) match {
      case ("RawZone", "Started" | "Failed") =>
        auditTableDf = auditTableDf.withColumn("file_path", concat(lit(baseFilePath), lit("/"), col("file_name")))
      case _ =>
        auditTableDf = auditTableDf.withColumn("file_path", concat(lit(baseFilePath), lit("/"), lit(partitionColumn), lit("="), col("partition_value")))
    }



      auditTableDf = auditTableDf.select("app_name", "data_zone", "event_type", "process_sub_step", "entity_name", "file_name", "file_path",
        "partition_column", "partition_value", "processed_partition", "status", "row_count", "crt_ts", "load_type", "pipeline_run_id",
        "pipeline_activity_run_iD",
        "spark_app_id", "spark_app_name", "livy_id")
    Writers.writeAsDelta(
      auditTableDf,
      force = true,
      saveToPath = path,
      saveMode = SaveMode.Append
    )


  }

  def insertEntityJourneyFilesAuditEntry(df: DataFrame, appName: String, dataZone: String, processSubStep: String, entityName: String,
                                    status: String, loadType: String)
  : Unit = {
    var auditTableDf = df.withColumn("file_name", concat(col("audit_submission_date").cast(StringType), lit("/"), col("name")))
      .withColumn("app_name", lit(appName))
      .withColumn("data_zone", lit(dataZone))
      .withColumn("event_type", lit("EntityJourney"))
      .withColumn("process_sub_step", lit(processSubStep))
      .withColumn("entity_name", lit(entityName))
      .withColumn("partition_column", lit(null))
      .withColumn("partition_value", lit(null))
      .withColumn("processed_partition", lit(null))
      .withColumn("status", lit(status))
      .withColumn("row_count", lit(null))
      .withColumn("crt_ts", lit(Instant.now()).cast(TimestampType))
      .withColumn("load_type", lit(loadType))
      .withColumn("pipeline_run_id", lit(pipelineRunId))
      .withColumn("pipeline_activity_run_iD", lit(pipelineActivityRunId))
      .withColumn("spark_app_id", lit(sparkAppID))
      .withColumn("spark_app_name", lit(sparkAppName))
      .withColumn("livy_id", lit(livyId))

    (processSubStep, status) match {
      case ("StructuralValidation", "Started") =>
        auditTableDf = auditTableDf.withColumnRenamed("path", "file_path")
      case ("StructuralValidation", "Failed") =>
        auditTableDf = auditTableDf.withColumnRenamed("invalidFileSetPath", "file_path")
      case ("StructuralValidation", "Processed") =>
        auditTableDf = auditTableDf.withColumnRenamed("validFileSetPath", "file_path")
    }
    auditTableDf = auditTableDf.select("app_name", "data_zone", "event_type", "process_sub_step", "entity_name", "file_name", "file_path",
        "partition_column", "partition_value", "processed_partition", "status", "row_count", "crt_ts", "load_type", "pipeline_run_id",
      "pipeline_activity_run_iD",
        "spark_app_id", "spark_app_name", "livy_id")
    Writers.writeAsDelta(
      auditTableDf,
      force = true,
      saveToPath = path,
      saveMode = SaveMode.Append
    )

  }

  /**
   * This method is used to insert entries into the audit table.
   * @param df The dataframe is used to get the file and partition information
   * @param zone The data zone
   * @param entityName The name of the entity
   * @param partitionColumn The partition column
   * @param status The status of the entry
   * @param loadType The type of load
   */
  def insertToAuditTable(df: DataFrame, zone: String, entityName: String, partitionColumn: String, status: String, loadType: String) :Unit ={
    val auditTableDf = df.groupBy("audit_file_name")
      .agg(first(col(partitionColumn)).as("partition_value"))
      .withColumn("partition_column", lit(partitionColumn))
      .withColumn("data_zone", lit(zone))
      .withColumn("entity_name", lit(entityName))
      .withColumn("processed_partition", lit(Instant.now()).cast(TimestampType))
      .withColumn("status", lit(status))
      .withColumn("crt_ts", lit(Instant.now()).cast(TimestampType))
      .withColumn("load_type", lit(loadType))
      .select("data_zone", "entity_name", "audit_file_name", "partition_column", "partition_value", "processed_partition", "status", "crt_ts", "load_type")

    Writers.writeAsDelta(
      auditTableDf,
      force = true,
      saveToPath = path,
      saveMode = SaveMode.Append
    )
  }



  /**
   * This method is used to get the next processing partitions as a filtercondition for reading in the next zone.
   * @param currentZone The current zone
   * @param entityName The name of the entity
   * @return Map[String, Array[String]]
   */
  def getNextProcessingPartitionsAsFilter(currentZone: String, entityName: String) : Map[String, Array[String]] = {
    val previousZone = currentZone match {
      case "RefinedZone" => "RawZone"
      case "CertifiedZone" => "RefinedZone"
      case "CertifiedExtendedZone" => "CertifiedZone"
      case _ => ""
    }
    var filterCondition: Map[String, Array[String]] =
      Map.empty[String, Array[String]]
    val auditTableDf =  DataFrames.getDataFrameFromUri(path, StorageFormat.Delta, false, Map.empty[String, String])
    val refinedEntryInAudit = auditTableDf.filter(col("data_zone") === currentZone && col("entity_name") === entityName
      && col("event_type") === "EntityJourney" && col("status") === "Processed").count()
    if (refinedEntryInAudit > 0) {
      val lastProcessedPartitionInRefined = auditTableDf.filter(col("data_zone") === currentZone && col("entity_name") === entityName && col("status") === "Processed"
        && col("event_type") === "EntityJourney")
        .sort(col("processed_partition").desc).select(first("processed_partition")).collect().map(_.getTimestamp(0))
      var partitionDf = SS.getActiveSession.emptyDataFrame
      if(previousZone == "RawZone"){
        partitionDf = auditTableDf.filter(col("data_zone") === previousZone && col("entity_name") === entityName && col("status") === "Processed"
          && col("process_sub_step") === "SemanticValidation" && col("processed_partition") > lastProcessedPartitionInRefined(0))
          .select("partition_column",
            "partition_value")
      }else{
        partitionDf = auditTableDf.filter(col("data_zone") === previousZone && col("entity_name") === entityName && col("status") === "Processed"
           && col("processed_partition") > lastProcessedPartitionInRefined(0))
          .select("partition_column",
            "partition_value")
      }


      logInfo("partitions to be processed in the current run")
      partitionDf.show(10, false)
      val partitionColumns = partitionDf.select("partition_column").distinct().collect().map(_.getString(0))
      val mutableFilterCondition: scala.collection.mutable.Map[String, Array[String]] = scala.collection.mutable.Map.empty[String, Array[String]]
      for (column <- partitionColumns) {
        mutableFilterCondition(column) = partitionDf.filter(col("partition_column") === column).select("partition_value")
          .distinct()
          .sort("partition_value")
          .collect()
          .map(_.getString(0))
      }
      filterCondition = mutableFilterCondition.toMap
    } else {
      var partitionDf = SS.getActiveSession.emptyDataFrame
      if(previousZone == "RawZone"){
        partitionDf = auditTableDf.filter(col("data_zone") === previousZone && col("entity_name") === entityName && col("status") === "Processed"
        && col("process_sub_step") === "SemanticValidation")
          .select("partition_column", "partition_value")
      }
      else{
        partitionDf = auditTableDf.filter(col("data_zone") === previousZone && col("entity_name") === entityName && col("status") === "Processed"
          && col("event_type") === "EntityJourney")
          .select("partition_column", "partition_value")
      }
      logInfo("partitions to be processed in the current run")
      partitionDf.show(10, false)
      val partitionColumns = partitionDf.select("partition_column").distinct().collect().map(_.getString(0))
      val mutableFilterCondition: scala.collection.mutable.Map[String, Array[String]] = scala.collection.mutable.Map.empty[String, Array[String]]
      for (column <- partitionColumns) {
        mutableFilterCondition(column) = partitionDf.filter(col("partition_column") === column).select("partition_value")
          .distinct()
          .sort("partition_value")
          .collect()
          .map(_.getString(0))
      }
      filterCondition = mutableFilterCondition.toMap
    }
  return filterCondition
  }


}
