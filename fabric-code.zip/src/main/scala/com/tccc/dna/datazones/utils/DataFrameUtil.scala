package com.tccc.dna.datazones.utils

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{ArrayType, StructType}

/**
 * Utility class to flatten a DataFrame with nested structures.
 */
object DataFrameUtil {
  /**
   * Flatten a DataFrame with nested structures and arrays.
   *
   * @param df DataFrame with nested structures ad arrays.
   * @return Flattened DataFrame.
   */
  def flattenDataFrame(df: DataFrame): DataFrame = {

    val fields = df.schema.fields
    val fieldNames = fields.map(x => x.name)
    for (i <- fields.indices) {
      val field = fields(i)
      val fieldType = field.dataType
      val fieldName = field.name
      fieldType match {
        case _: ArrayType =>
          val fieldNamesExcludingArray = fieldNames.filter(_ != fieldName)
          val fieldNamesAndExplode = fieldNamesExcludingArray ++ Array(
            s"explode_outer($fieldName) as $fieldName"
          )
          val explodedDf = df.selectExpr(fieldNamesAndExplode: _*)
          return flattenDataFrame(explodedDf)
        case structType: StructType =>
          println(s"${fieldName}: Struct Type")
          val childFieldNames =
            structType.fieldNames.map(childname => fieldName + "." + s"`$childname`")
          val newFieldNames =
            fieldNames.filter(_ != fieldName) ++ childFieldNames
          import org.apache.spark.sql.functions.col

          val renamedCols =
            newFieldNames.map { x =>
              col(x).as(x.replace(".", "_").replace(":", "_").replace("`", ""))
            }

          val explodedDf = df.select(renamedCols: _*)
          return flattenDataFrame(explodedDf)
        case _ =>
          println(s"${fieldName}: other types:$fieldType")

      }
    }
    df
  }

  /**
   * Flatten a DataFrame with nested structures and arrays and retain the original columns.
   *
   * @param df DataFrame with nested structures ad arrays.
   * @return Flattened DataFrame.
   */
  def flattenDataFrameWithOriginals(df: DataFrame): DataFrame = {

    val fields = df.schema.fields
    val fieldNames = fields.map(x => x.name)
    for (i <- fields.indices) {
      val field = fields(i)
      val fieldType = field.dataType
      val fieldName = field.name
      fieldType match {
        //        case _: ArrayType =>
        //          val fieldNamesExcludingArray = fieldNames.filter(_ != fieldName)
        //          val fieldNamesAndExplode = fieldNamesExcludingArray ++ Array(
        //            s"explode_outer($fieldName) as $fieldName"
        //          )
        //          val explodedDf = df.selectExpr(fieldNamesAndExplode: _*)
        //          //val explodedDf = df.selectExpr(fieldNamesAndExplode: _*).withColumn(fieldName, col(fieldName))
        //          return flattenDataFrameWithOriginals(explodedDf)
        case structType: StructType =>
          println(s"${fieldName}: Struct Type")
          val childFieldNames =
            structType.fieldNames.map(childname => fieldName + "." + s"`$childname`")
          val newFieldNames =
            fieldNames.filter(_ != fieldName) ++ childFieldNames
          import org.apache.spark.sql.functions.col

          val renamedCols =
            newFieldNames.map { x =>
              col(x).as(x.replace(".", "_").replace(":", "_").replace("`", ""))
            }

          val explodedDf = df.select(renamedCols: _*)
          //val explodedDf = df.select(renamedCols: _*).withColumn(fieldName, col(fieldName))
          return flattenDataFrameWithOriginals(explodedDf)
        case _ =>
          println(s"${fieldName}: other types:$fieldType")

      }
    }
    df
  }
  /**
   * Flatten a DataFrame with nested structures and  retain the original columns.
   *
   * @param df DataFrame with nested structures.
   * @return Flattened DataFrame.
   */
  def flattenStructureToDataFrame(df: DataFrame): DataFrame = {

    val fields = df.schema.fields
    val fieldNames = fields.map(x => x.name)
    for (i <- fields.indices) {
      val field = fields(i)
      val fieldType = field.dataType
      val fieldName = field.name
      fieldType match {
        case structType: StructType =>
          println(s"${fieldName}: Struct Type")
          val childFieldNames =
            structType.fieldNames.map(childname => fieldName + "." + s"`$childname`")
          val newFieldNames =
            fieldNames.filter(_ != fieldName) ++ childFieldNames
          import org.apache.spark.sql.functions.col

          val renamedCols =
            newFieldNames.map { x =>
              col(x).as(x.replace(".", "_").replace(":", "_").replace("`", ""))
            }

          val explodedDf = df.select(renamedCols: _*)
          return flattenStructureToDataFrame(explodedDf)
        case _ =>
          println(s"${fieldName}: other types:$fieldType")
      }
    }
    df
  }
}

