package com.tccc.dna.datazones.validators

import com.tccc.dna.datazones.DataZoneTypeAliases.{SemanticallyInvalidDataFrame, SemanticallyValidDataFrame, SyntaticallyValidDataFrame}
import com.tccc.dna.synapse.Logging
import org.apache.spark.sql.DataFrame

/**
 * A base class representing the contract for all '''semantic (data level, record by record)''' validators. A new column should be added
 * to the input [[DataFrame]] '''for each structural check'''. The column name should be the same as the check name.
 */
abstract class SemanticValidator extends Logging {
  /**
   * Performs '''semantic validation (record by record)''' on the provided DataFrame. A '''new column is added''' to the DataFrame '''for each check'''
   * containing the result of the check performed. The column name is the same as the check name.
   *
   * All checks should be performed on the input DataFrame with the result captured in a new column. There shouldn't be short circuiting of the checks.
   *
   * @param inputDf The DataFrame to be checked.
   * @return The DataFrame with the new columns added for each check performed. For e.g. if 3 checks
   *         '''(isAssetIdUnique, isColumnContainsEmail, isUUIDUnique)''' are
   *         configured then the result schema would have 3 more additional columns with names as
   *         '''isAssetIdUnique, isColumnContainsEmail, isUUIDUnique'''.
   */
  def check(inputDf: DataFrame): DataFrame

  /**
   * Splits the provided DataFrame into two DataFrames - one containing the rows that passed the data validation and the other that failed the validation.
   *
   * @param inputDf       The [[SyntaticallyValidDataFrame]] to be split. This DataFrame should have been previously processed by the [[check]] method.
   * @param checkColNames The names of the columns that were added by the [[check]] method.
   * @return A tuple of two DataFrames - [[SemanticallyValidDataFrame]]: the first one containing the rows that passed the structural validation and the
   *         [[SemanticallyInvalidDataFrame]]: second one that failed the validation.
   */
  def splitValidAndInvalidSemantic(inputDf: SyntaticallyValidDataFrame, checkColNames: Seq[String]): (SemanticallyValidDataFrame, SemanticallyInvalidDataFrame) = {
    logInfo("Filter valid and invalid rows based on true/false values in columns: " + checkColNames)

    val validRowsDf = selectValidRows(inputDf, checkColNames)
    val invalidRowsDf = selectInvalidRows(inputDf, checkColNames)
    (validRowsDf, invalidRowsDf)
  }

  /**
   * Selects and returns the rows from the provided DataFrame where the value is 'false' in any of the specified columns.
   *
   * @param df         The DataFrame from which rows are to be selected.
   * @param checkNames A sequence of column names to check for 'false' values.
   * @example selectInvalidRows(df, Seq("isFileSizeGreaterThanZero", "isFileNameValid"))
   * @note This function uses the union operation to combine results and removes duplicates.
   *       It does not preserve the order of rows from the original DataFrame.
   * @return A DataFrame that contains the rows where any of the specified columns have the value 'false'.
   *         No duplicate rows will be present in the result.
   */
  def selectInvalidRows(df: DataFrame, checkNames: Seq[String]): DataFrame = {
    checkNames.map(c => df.filter(df(c) === false))
      .reduce(_ union _).distinct()
  }

  /**
   * Selects and returns the rows from the provided DataFrame where the value is 'true'
   * in all of the specified columns.
   *
   * @param df         The DataFrame from which rows are to be selected.
   * @param checkNames A sequence of column names to check for 'true' values.
   * @example selectValidRows(df, Seq("isFileSizeGreaterThanZero", "isFileNameValid"))
   * @note This function uses the intersect operation to combine results and removes duplicates.
   *       It does not preserve the order of rows from the original DataFrame.
   * @return A DataFrame that contains the rows where all of the specified columns have the value 'true'.
   *         No duplicate rows will be present in the result.
   */
  def selectValidRows(df: DataFrame, checkNames: Seq[String]): DataFrame = {
    checkNames.map(c => df.filter(df(c) === true))
      .reduce(_ intersect _)
  }
}