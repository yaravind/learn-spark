package com.tccc.dna.datazones.validators

import com.amazon.deequ.checks.{Check, CheckLevel, CheckWithLastConstraintFilterable}

/** A collection of predefined structural validators that can be used across different entities.
  */
object PredefinedStructuralValidators {
  val isFileSizeGreaterThanZero = Check(
    CheckLevel.Error, "isFileSizeGreaterThanZero").hasMin("size", _ > 0, hint = Some("File size is zero.")
  )

  val isFileNameSuffixValidDateTime: CheckWithLastConstraintFilterable = Check(CheckLevel.Error, "isFileNameSuffixValidDateTime")
    .satisfies("""CASE WHEN to_timestamp(REGEXP_EXTRACT(name, '.*-(\\d+)\\.json', 1), 'yyyyMMddHHmmss') IS NOT NULL THEN true ELSE false END""",
      constraintName = "isFileNameSuffixValidDateTime", hint = Some("File name suffix do not parse to a valid date."))

}