package com.tccc.dna.datazones.raw

import com.tccc.dna.datazones.DataZoneTypeAliases.{LandingDataFrame, SyntaticallyInvalidDataFrame, SyntaticallyValidDataFrame}
import com.tccc.dna.datazones.validators.{DataLoader, SemanticValidator, StructuralValidator}
import com.tccc.dna.synapse.StorageFormat

/**
 * RawZoneImpl is the implementation of RawZoneTemplate.
 *
 * @param rawZoneProfile    Instance of [[RawZoneProfile]].
 * @param structuralValidator Instance of [[StructuralValidator]].
 * @param semanticValidator Instance of [[SemanticValidator]].
 * @param loadSemanticData  Instance of [[DataLoader]].
 */
class RawZoneImpl (rawZoneProfile: RawZoneProfile,
                   structuralValidator: StructuralValidator,
                   semanticValidator: SemanticValidator,
                   loadSemanticData: DataLoader
                  ) extends RawZoneTemplate(
  rawZoneProfile,
  structuralValidator,
  semanticValidator,
  loadSemanticData
){
  /**
   * This method is used to perform structural validation on the input DataFrame.
   *
   * @param inputDf       Instance of [[LandingDataFrame]].
   * @param storageFormat Instance of [[StorageFormat]].
   * @return A tuple of [[SyntaticallyValidDataFrame]] and [[SyntaticallyInvalidDataFrame]].
   */
  override def doStructuralValidation(
                                       inputDf: LandingDataFrame,
                                       storageFormat: StorageFormat
                                     ): (SyntaticallyValidDataFrame, SyntaticallyInvalidDataFrame) = ???
}
