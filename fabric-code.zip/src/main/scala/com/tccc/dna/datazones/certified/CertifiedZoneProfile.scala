package com.tccc.dna.datazones.certified

import com.tccc.dna.datazones.init.TableConfig
import com.tccc.dna.datazones.utils.AuditTableRepository
//import org.apache.commons.lang.builder.ToStringStyle
import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}


/**
 * Encapsulates all the configuration needed for Certified Zone to read data and process data from Refined Zone.
 *
 * @param entityName                   Name of the entity this CertifiedZoneProfile is for.
 * @param controlFilePath              Directory, within metadata folder, where the configuration file is read from
 * @param certifiedFullPath            Directory, within certified zone, where files will be written to
 * @param refinedFullPath              Directory, within refined zone, where files are read from
 * @param currentRunStartHourAndMinute This is the partition where the data is picked up by the next step in the process. This is a random string of 8
 *                                     characters and generated as {{{RandomStringUtils.random(8, "0123456789abcdef")}}}.
 */
case class CertifiedZoneProfile(entityName: String,
                                controlFilePath: String,
                                refinedFullPath: String,
                                certifiedFullPath: String,
                                filterCondition: Map[String, Array[String]],
                                tableCfg: TableConfig,
                                auditTableRepository: AuditTableRepository
                               ) {

  override def toString: String = new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
    .append("entityName", entityName)
    .append("controlFilePath", controlFilePath)
    .append("refinedFullPath", refinedFullPath)
    .append("certifiedFullPath", certifiedFullPath)
    .append("filterCondition", filterCondition)
    .append("tableCfg", tableCfg)
    .append("auditTableRepository", auditTableRepository)
    .toString
}
