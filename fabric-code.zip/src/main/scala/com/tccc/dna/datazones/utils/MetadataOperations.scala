package com.tccc.dna.datazones.utils

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

import java.time.Instant

/** This object will have all metadata related operations. e.g. Add columns for tracking statuses
 */
object MetadataOperations {
  def addMetadataColumns(varDF: DataFrame, createdUser: String): DataFrame = {
    val createTime: Instant = Instant.now()

    // Adding information to metadata columns
    varDF
      .withColumn("audit_crt_ts", lit(createTime))
      .withColumn("audit_crt_usr", lit(createdUser))
      .withColumn("audit_upd_ts", lit(null))
      .withColumn("audit_upd_usr", lit(null))
      .withColumn("audit_crt_ts", col("audit_crt_ts").cast(TimestampType))
      .withColumn("audit_upd_ts", col("audit_upd_ts").cast(TimestampType))
      .withColumn("audit_upd_usr", col("audit_upd_usr").cast(StringType))
  }
}
