package com.tccc.dna.datazones

import com.tccc.dna.synapse.Logging
import com.tccc.dna.synapse.spark.SynapseSpark

import java.lang
import java.sql.{Connection, DriverManager}
import scala.util.Try

/**
 * server name: sql-tccc-map-dev-1.database.windows.net,1433
 * host name:  = "sql-tccc-map-dev-1"
 * DB Name: appmetadata
 * User name: audit_user
 * Schema.Table = [sch_ops].[audit]
 *
 * Reference: https://learn.microsoft.com/en-us/azure/azure-sql/database/connect-query-java?view=azuresql
 * https://learn.microsoft.com/en-us/azure/synapse-analytics/spark/microsoft-spark-utilities?pivots=programming-language-python#credentials-utilities
 *
 * url=jdbc:sqlserver://$AZ_DATABASE_NAME.database.windows.net:1433;database=demo;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;
 * user=demo@$AZ_DATABASE_NAME
 * password=$AZ_SQL_SERVER_PASSWORD
 *
 */
class DbManager(hostName: String, port: Int, loginTimeout: Int, dbName: String, userName: String, password: String, isLocal: Boolean = true) extends
  Logging {
  private val H2DriverClass = "org.h2.Driver"
  private val H2DriverUrl = s"jdbc:h2:mem:$dbName;MODE=MSSQLServer;INIT=RUNSCRIPT FROM 'src/main/resources/h2-init-script-audit.sql'"
  private val AzSQLDriverClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
  private val user = s"$userName@$hostName"
  private val AzSQLUrl = s"jdbc:sqlserver://$hostName.database.windows.net:$port;database=$dbName;loginTimeout=$loginTimeout;"
  private val driverClass = if (isLocal) Class.forName(H2DriverClass) else Class.forName(AzSQLDriverClass)
  private val url = if (isLocal) H2DriverUrl else AzSQLUrl
  private var connection: Connection = _
  logInfo(s"Running in local mode?: $isLocal. Loaded driver: $driverClass")

  def getConnection: Try[Connection] = {
    logInfo(s"Get connection to: $url")
    Try {
      if (connection == null || connection.isClosed || !connection.isValid(1)) {
        connection = DriverManager.getConnection(url, user, password)
      }
      connection
    }
  }

  def getResolvedDriver: String = driverClass.getCanonicalName

  def getResolvedJdbcUrl: String = url

  def closeConnection(): Unit = {
    if (connection != null && !connection.isClosed) connection.close()
    logInfo(s"Close connection to: $url")
  }

  def using[A <: AutoCloseable, B](resource: A)(block: A => B): B = {
    try {
      block(resource)
    } finally {
      if (resource != null) resource.close()
    }
  }
}

/**
 * A [[https://www.digitalocean.com/community/tutorials/factory-design-pattern-in-java Factory object]] concealing the instantiation
 * logic for Local vs Cluster. Uses [[SynapseSpark.isLocalEnv]] as a flag to determine the connection string and credentials.
 */
object DbManager {
  /**
   * TODO use mssparkutils.credentials.* to retrieve hostName, dbName, userName and password.
   *
   * @param hostName
   * @param dbName
   * @param userName
   * @param password
   * @param port
   * @param loginTimeout
   * @return An instance of [[DbManager]] connected to Azure SQL Database of respective environment.
   */
  def apply(hostName: String, dbName: String, userName: String, password: String, port: Int, loginTimeout: Int): DbManager = {
    apply(dbName, userName, password, SynapseSpark.isLocalEnv, hostName, port, loginTimeout)
  }

  /**
   * Factory method to create DbManager instance for unit tests.
   *
   * @param dbName Name of the database.
   * @return An instance of [[DbManager]] connected to in-memory H2 Database.
   */
  def apply(dbName: String): DbManager = {
    apply(dbName, userName = "", password = "", SynapseSpark.isLocalEnv, hostName = "mem", 1433, 30)
  }

  /**
   * Factory method to fully control DbManager instance.
   *
   * @param dbName
   * @param userName
   * @param password
   * @param isLocal
   * @param hostName
   * @param port
   * @param loginTimeout
   * @return
   */
  def apply(dbName: String, userName: String, password: String, isLocal: Boolean, hostName: String, port: Int, loginTimeout: Int): DbManager = {
    val url = if (isLocal) {
      s"jdbc:h2:mem:$dbName;DB_CLOSE_DELAY=-1" // H2 database JDBC URL
    } else {
      s"jdbc:sqlserver://$hostName:$port;databaseName=$dbName;loginTimeout=$loginTimeout;" // Azure SQL DB JDBC URL
    }

    new DbManager(url, port, loginTimeout, dbName, userName, password, isLocal)
  }
}