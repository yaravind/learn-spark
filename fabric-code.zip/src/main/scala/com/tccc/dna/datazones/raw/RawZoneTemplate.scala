package com.tccc.dna.datazones.raw

import com.tccc.dna.datazones.DataZoneTypeAliases._
import com.tccc.dna.datazones.utils.DataFrameUtil.flattenStructureToDataFrame
import com.tccc.dna.datazones.utils.{DataZoneUtilImpl, MetadataOperations}
import com.tccc.dna.datazones.validators._
import com.tccc.dna.synapse.spark.{DataFrames, SynapseSpark, Writers}
import com.tccc.dna.synapse.{DataZone, Logging, StorageFormat}
import org.apache.commons.io.FileUtils
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{Column, DataFrame, SaveMode}

import java.io.File
import java.nio.file.{Files, Paths}
import java.sql.Date
import scala.util.{Failure, Success, Try}

/** @param rawZoneProfile     Encapsulates the '''configuration''' required to create the Raw Zone.
 * @param structuralValidator Encapsulates the checks to be performed to verify '''structural correctness''' of the data.
 * @param semanticValidator   Encapsulates the checks to be performed to verify '''semantic (Data Quality) correctness''' of the data.
 */
abstract class RawZoneTemplate(
                                val rawZoneProfile: RawZoneProfile,
                                val structuralValidator: StructuralValidator,
                                val semanticValidator: SemanticValidator,
                                val loadSemanticData: DataLoader
                              ) extends Logging {
  private val RelativeDataPath = "data/"
  private val RelativeMetadataPath = "metadata/"
  private val CsvWriteOptions =
    Map("header" -> "true", "delimiter" -> ",", "quote" -> "\"")
  private val DoNotTruncate = false
  private var logMessage =""

  /**
   * The main method for this class. Used to run the submethods needed to process the certified zone
   *
   * @return Returns the semantically valid data frame
   */
  def execute(): SemanticallyValidDataFrame = {

    val landingURI = rawZoneProfile.landingZoneProfile.getLandingURI
    logMessage = s"***** Executing Raw Zone for landing path [$landingURI] - Start."
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Landing to inbound", logMessage)
    logMessage = s"RawZoneProfile: $rawZoneProfile"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Landing to inbound", logMessage)

    //TODO Generate AUDIT record to indicate that processing has started for RawZone
    var filesDf = getFileListToBeProcessed(landingURI)
    val fileCount = filesDf.count
    filesDf.show(20, false)
    logMessage = s"Total files being processed: $fileCount."
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Landing to inbound", logMessage)
    if (fileCount <= 0) {
      logMessage = s"No files found in the path: $landingURI. Short-circuiting the process."
      logEntityJourneyError(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Landing to inbound", logMessage)
      //TODO Generate AUDIT record to indicate that processing has aborted
      return SynapseSpark.getActiveSession.emptyDataFrame
    }
    logMessage = s"Processing file list: "
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Landing to inbound", logMessage)
    filesDf
      .select("path")
      .collect()
      .foreach(file => logInfo(s"${file.getString(0)}"))
    filesDf = filesDf.filter(col("isDir") === "false")
    val filesDfWthSubmitDate = deriveSubmissionDatetime(filesDf) match {
      case Success(derivedDf) => derivedDf
      case Failure(exception) =>
        logMessage = s"Failed to derive submission date from the path. Short-circuiting the process. Error: ${exception.getMessage}"
        logEntityJourneyError(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Landing to inbound", logMessage, exception)
        return SynapseSpark.getActiveSession.emptyDataFrame
    }
    show(filesDfWthSubmitDate, 10)


    logMessage = s"1. Stage files from landing to [${rawZoneProfile.inboundPath}]"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Landing to inbound", logMessage)
    val landingPaths = collectColumnValues(filesDfWthSubmitDate, "path").sorted
    val resolvedFilesDf = filesDfWthSubmitDate.withColumn(
      "inboundPath",
      concat(
        lit(rawZoneProfile.inboundPath).cast(StringType),
        col("audit_submission_date"),
        lit("/"),
        col("name")
      )
    )
    show(resolvedFilesDf, 10)
    val resolvedFilesPaths = collectColumnValues(resolvedFilesDf, "inboundPath").sorted
    moveFiles(landingPaths, resolvedFilesPaths, true)

    logMessage = s"2. Structural validations - Start"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Structural validation", logMessage)

    val (
      structureValidDf: SyntaticallyValidDataFrame,
      structureInvalidDf: SyntaticallyInvalidDataFrame
      ) =
      rawZoneProfile.landingZoneProfile.entityFormat match {
        //In case of JSON format, we need to load as text and do the validation against the schema before creating a DataFrame
        case StorageFormat.JSON =>
          logMessage = s"2.1/2. Load and Perform structural validations. Note: In case of JSON format, we need to load as text and do the validation against the schema before creating a DataFrame"
          logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Structural validation", logMessage)
          doStructuralValidation(resolvedFilesDf)
        //We can directly read as DataFrame for other formats.
        case _ =>
          logMessage = s"2.1 Load inbound DataFrame."
          logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Structural validation", logMessage)
          //TODO Check if we can leverage doStructuralValidation(filesDf) instead of overloaded method
          doStructuralValidation(resolvedFilesDf)
      }
    logMessage = s"2.2. Post process structurally Invalid data."
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Structural validation", logMessage)
    if (!structureInvalidDf.isEmpty) {
      show(structureInvalidDf)
      val postStructureInvalidDf = postProcessStructureInvalidFiles(
        structureInvalidDf
      )
    }
    if (structureValidDf.isEmpty) {
      logMessage = s"***No files to process further. All input files failed meta-data/structural validation.***"
      logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Structural validation", logMessage)

      return SynapseSpark.getActiveSession.emptyDataFrame
    }
    logMessage = s"2.3. Post process structurally valid data."
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Structural validation", logMessage)
    show(structureValidDf)
    //structureValidDf.show(DoNotTruncate)
    val postStructureValidDf = postProcessStructureValidFiles(structureValidDf)
    show(postStructureValidDf)
    //postStructureValidDf.show(DoNotTruncate)
    logMessage = s"2. Structural validations - End"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Structural validation", logMessage)
    logMessage = s"3. Semantic validations - Start"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)

    val (
      semanticValidDf: SemanticallyValidDataFrame,
      semanticInvalidDf: SemanticallyInvalidDataFrame
      ) =
      if (!postStructureValidDf.isEmpty) {
        val (
          semanticValidDf: SemanticallyValidDataFrame,
          semanticInvalidDf: SemanticallyInvalidDataFrame
          ) =
          doSemanticValidation(postStructureValidDf)
        logMessage = s"3.4 Semantically valid rows."
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)
        show(semanticValidDf)

        logMessage = s"3.5 Semantically invalid rows."
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)

        show(semanticInvalidDf)

        (semanticValidDf, semanticInvalidDf)
      } else {
        logMessage = s"3.1 ***No files to process further. All input files failed meta-data/structural validation.***"
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)

        //TODO define where to save the file and with what name
        //      saveAsCsv(structureInvalidDf, rawZoneProfile.invalidFileSetPath)
        (
          SynapseSpark.getActiveSession.emptyDataFrame,
          SynapseSpark.getActiveSession.emptyDataFrame
        )
      }
    val postSemanticValidDf: SemanticallyValidDataFrame =
      postProcessSemanticData(semanticValidDf, semanticInvalidDf)
    logMessage = s"3. Semantic validations - End"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)

    logMessage = s"Extracting extra columns"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)
    //    getListOfColumnsWhichAreNotPresentInSchema(postStructureValidDf, rawZoneProfile.tableCfg.getRawKeyCols)
    logMessage = s"3. Semantic validations - End"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)

    logMessage = s"4. Move files from inbound to archive: START"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Folder cleanup", logMessage)

    val inboundPath = collectColumnValues(resolvedFilesDf, "inboundPath")
    val archivePath =
      inboundPath.map(paths => paths.replace("inbound", "archive"))
    moveFiles(inboundPath, archivePath, true)
    logMessage = s"4. Move files from inbound to archive: END"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Folder cleanup", logMessage)

    logMessage = s"5. Delete empty folders: START"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Folder cleanup", logMessage)
    logMessage = s"5.1 Delete landing folders: START"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Folder cleanup", logMessage)
    deleteEmptyDirectories(landingURI)
    logMessage = s"5.1 Delete landing folders: END"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Folder cleanup", logMessage)
    logMessage = s"5.2 Delete inbound folders: START"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Folder cleanup", logMessage)
    deleteEmptyDirectories(rawZoneProfile.inboundPath)
    logMessage = s"5.2 Delete inbound folders: END"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Folder cleanup", logMessage)
    logMessage = s"5.3 Delete validFileSet data folder: START"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Folder cleanup", logMessage)
    var validFileSetPath =
      collectColumnValues(postStructureValidDf, "validFileSetPath")
    validFileSetPath =
      validFileSetPath.map(x => x.substring(0, x.lastIndexOf(("/")))).distinct
    deleteDirectory(validFileSetPath)
    logMessage = s"5.3 Delete validFileSet data folders: END"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Folder cleanup", logMessage)

    logMessage = "5. Delete empty folders: END"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Folder cleanup", logMessage)

    if (postSemanticValidDf.isEmpty) {
      logMessage = s"Zero valid record to be processed in RefinedZone for this run."
      logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "driver", logMessage)
    }
    //TODO Generate AUDIT record to indicate that processing is complete for Raw Zone
    logMessage = s"***** Executing Raw Zone for $landingURI - End."
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "driver", logMessage)
    postSemanticValidDf
  }

  /**
   * It shows the dataframe, by default 2 rows.
   */
  def show(inputDf: DataFrame, numRows: Int = 2) =
    inputDf.show(numRows, DoNotTruncate)

  /**
   * Drops the semantic check columns from the data frame
   *
   * @return dataframe after the check columns have been removed
   */
  def dropCheckColumns(inputDf: DataFrame): DataFrame = {
    val checkNames: scala.Seq[String] = semanticValidator match {
      case validator: DeequBackedSemanticValidator =>
        validator.getCheckNames()
      case _ =>
        Seq.empty
    }
    logMessage = s"Remove semantic check columns from SemanticallyValidDataFrame. Columns: $checkNames"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)
    val onlyDataDf = inputDf
      .drop(checkNames: _*)
      .drop("input_file_path")
    onlyDataDf
  }

  /**
   * Method to run submethods after processing, drops check columns and writes data frames to target locations.
   *
   * @param semanticInvalidDf Dataframe containing the semantically invalid rows
   * @param semanticValidDf   Dataframe containing the semantically valid rows
   * @return Semantically valid dataframe
   */

  def postProcessSemanticData(
                               semanticValidDf: SemanticallyValidDataFrame,
                               semanticInvalidDf: SemanticallyInvalidDataFrame
                             ): SemanticallyValidDataFrame = {
    logMessage = s"3.6 Post processing semantic data"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)
    logMessage = s"3.7 rawZoneProfile.shouldProcessPartialRecords: ${rawZoneProfile.shouldProcessPartialRecords}"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)

    logMessage = s"3.7.1 semanticValidDf.isEmpty: ${semanticValidDf.isEmpty}"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)
    logMessage = s"3.7.2 semanticInvalidDf.isEmpty: ${semanticInvalidDf.isEmpty}"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)

    //Remove metadata columns for valid records
    val onlyDataDf = dropCheckColumns(semanticValidDf)
    logMessage = s"3.7.3 After removing metadata cols"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)
    onlyDataDf.printSchema()

    var resultDf = SynapseSpark.getActiveSession.emptyDataFrame

    def write(
               onlyDataDf: DataFrame,
               writeToPath: String,
               writeOptions: Map[String, String]
             ): Unit = {
      rawZoneProfile.landingZoneProfile.entityFormat match {
        case StorageFormat.JSON => Writers.writeAsJson(onlyDataDf, writeToPath,
          partitionColNames = Some(Array("audit_submission_date_hr_min")), saveMode = SaveMode.Append,
          overwriteFolder = true)
        case StorageFormat.Tsv => Writers.writeAsCsv(onlyDataDf, writeToPath,
          partitionColNames = Some(Array("audit_submission_date_hr_min")), saveMode = SaveMode.Append,
          overwriteFolder = true, writeOptions = writeOptions)
        case StorageFormat.Csv => Writers.writeAsCsv(onlyDataDf, writeToPath,
          partitionColNames = Some(Array("audit_submission_date_hr_min")), saveMode = SaveMode.Append,
          overwriteFolder = true, writeOptions = writeOptions)
        case StorageFormat.Parquet => Writers.writeAsParquet(onlyDataDf, writeToPath, force = true, partitionColNames = Some(Array
        ("audit_submission_date_hr_min")),
          saveMode = SaveMode.Append
        )
        case _ => logWarning("Unsupported entity format: " + rawZoneProfile.landingZoneProfile.entityFormat)
      }
    }
    //Happy path
    //TODO new method: handlePostProcessSemanticallyValidData
    if (
      rawZoneProfile.shouldProcessPartialRecords && !semanticValidDf.isEmpty
    ) {
      logMessage = s"3.7.4 Partial record processing is enabled and there are valid records. Saving valid records to: ${rawZoneProfile.validDataPath +
        RelativeDataPath}"
      logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Valid file set to valid data", logMessage)

      write(
        onlyDataDf,
        rawZoneProfile.validDataPath + RelativeDataPath,
        getFinalWriteOptions(rawZoneProfile.entityName)
      )
      createDirectories(rawZoneProfile.validDataPath + RelativeMetadataPath)
      rawZoneProfile.auditTableRepository.insertEntityJourneyAuditEntry(semanticValidDf, SynapseSpark.getCurrentSparkAppName, DataZone.RawZone.toString,
      "SemanticValidation", rawZoneProfile.entityName, "audit_submission_date_hr_min", "Processed",
        "DailyRefresh", rawZoneProfile.validDataPath + RelativeDataPath)
      resultDf = semanticValidDf
    }
    //Other paths
    if (
      rawZoneProfile.shouldProcessPartialRecords && !semanticInvalidDf.isEmpty
    ) {
      logMessage = s"3.7.5 Partial record processing is enabled and there are invalid records. Saving invalid records to: ${rawZoneProfile
        .invalidDataErrorPath + RelativeDataPath}"
      logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Valid file set to invalid data error", logMessage)

      //Remove metadata columns for valid records
      val onlyDataDf = dropCheckColumns(semanticValidDf)
      logMessage = s"3.7.5.1 After removing metadata cols" + DataFrames.getSchemaAsJson(onlyDataDf)
      logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Valid file set to valid data", logMessage)

      logMessage = "3.7.5.2 After removing metadata cols: " + DataFrames.getSchemaAsDictionary(onlyDataDf)
      logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Valid file set to valid data", logMessage)

      //save invalid records to rawZoneProfile.invalidDataErrorPath + RelativeDataPath
      write(
        semanticInvalidDf,
        rawZoneProfile.invalidDataErrorPath + RelativeDataPath,
        getFinalWriteOptions(rawZoneProfile.entityName)
      )
      createDirectories(
        rawZoneProfile.invalidDataErrorPath + RelativeMetadataPath
      )
      rawZoneProfile.auditTableRepository.insertEntityJourneyAuditEntry(semanticInvalidDf, SynapseSpark.getCurrentSparkAppName, DataZone.RawZone.toString,
        "SemanticValidation", rawZoneProfile.entityName, "audit_submission_date_hr_min", "Failed",
        "DailyRefresh", rawZoneProfile.invalidDataErrorPath + RelativeDataPath)
      resultDf = semanticValidDf
    }
    if (
      !rawZoneProfile.shouldProcessPartialRecords && !semanticValidDf.isEmpty && semanticInvalidDf.isEmpty
    ) {

      logMessage = s"3.7.5 Partial record processing is disabled and all records are valid (i.e. no invalid records). Saving valid records to: ${rawZoneProfile
        .validDataPath + RelativeDataPath}"
      logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Valid file set to valid data", logMessage)

      write(
        onlyDataDf,
        rawZoneProfile.validDataPath + RelativeDataPath,
        getFinalWriteOptions(rawZoneProfile.entityName)
      )
      createDirectories(rawZoneProfile.validDataPath + RelativeMetadataPath)
      rawZoneProfile.auditTableRepository.insertEntityJourneyAuditEntry(semanticValidDf, SynapseSpark.getCurrentSparkAppName, DataZone.RawZone.toString,
        "SemanticValidation", rawZoneProfile.entityName, "audit_submission_date_hr_min", "Passed",
        "DailyRefresh", rawZoneProfile.validDataPath + RelativeDataPath)
      resultDf = semanticValidDf
    }
    if (
      !rawZoneProfile.shouldProcessPartialRecords && !semanticInvalidDf.isEmpty
    ) {
      logMessage = s"3.7.2 Partial record processing is disabled and there are invalid records. Reject full file(s) and save invalid records."
      logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Valid file set to invalid file reject", logMessage)

      if (!semanticInvalidDf.isEmpty) {
        //Reject full file(s). Move reject files to rawZoneProfile.invalidDataFileRejectsPath
        val rejectFilePaths = semanticInvalidDf
          .withColumn(
            "relativePath",
            substring_index(col("input_file_path"), "/", -2)
          )
          .select("relativePath")
          .distinct()
          .collect()
          .map(row => rawZoneProfile.validFileSetPath + row.getString(0))
          .toList
        logMessage = s"rejectFilePaths=" + rejectFilePaths
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Valid file set to invalid file reject", logMessage)

        val resolvedRejectFilePath =
          rawZoneProfile.invalidDataFileRejectsPath + getSubmissionDate(
            semanticInvalidDf
          )
        logMessage = s"Moving reject files to: $resolvedRejectFilePath"
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Valid file set to invalid file reject", logMessage)
        moveFiles(rejectFilePaths, resolvedRejectFilePath)
        //save all records to  rawZoneProfile.invalidDataFileRejectsPath + RelativeDataPath
        val resolvedInvalidDataPath =
          rawZoneProfile.invalidDataErrorPath + RelativeDataPath
        logMessage = s"Saving invalid records to: $resolvedInvalidDataPath"
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Valid file set to invalid data error", logMessage)

        write(
          semanticInvalidDf,
          resolvedInvalidDataPath,
          getFinalWriteOptions(rawZoneProfile.entityName)
        )
        //TODO Fix it later
        rawZoneProfile.auditTableRepository.insertEntityJourneyAuditEntry(semanticInvalidDf, SynapseSpark.getCurrentSparkAppName, DataZone.RawZone.toString,
          "SemanticValidation", rawZoneProfile.entityName, "audit_submission_date_hr_min", "Failed",
          "DailyRefresh", rawZoneProfile.invalidDataErrorPath + RelativeDataPath)
      }
      resultDf = SynapseSpark.getActiveSession.emptyDataFrame
    }
    resultDf
  }

  /**
   * write the structurally valid files to the appropriate location
   *
   * @param structureValidDf The dataframe containing the list of the structurally valid files
   * @return The synatatically valid data frame
   */
  def postProcessStructureValidFiles(
                                      structureValidDf: SyntaticallyValidDataFrame
                                    ): SyntaticallyValidDataFrame = {

    logMessage = s"2.3.1 Save structurally valid metadata to: ${rawZoneProfile.validFileSetPath + RelativeMetadataPath}"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Inbound to valid file set", logMessage)

    Writers.writeAsCsv(
      structureValidDf,
      rawZoneProfile.validFileSetPath + RelativeMetadataPath,
      partitionColNames = Some(Array("audit_submission_date")),
      saveMode = SaveMode.Append,
      overwriteFolder = true,
      writeOptions = CsvWriteOptions
    )
    logMessage = s"2.3.2 Copy structurally valid files to: ${rawZoneProfile.validFileSetPath}"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Inbound to valid file set", logMessage)

    val resolvedDf = structureValidDf.withColumn(
      "validFileSetPath",
      concat(
        lit(rawZoneProfile.validFileSetPath + RelativeDataPath).cast(StringType),
        col("audit_submission_date"),
        lit("/"),
        col("name")
      )
    )
    rawZoneProfile.auditTableRepository.insertEntityJourneyFilesAuditEntry(resolvedDf, SynapseSpark.getCurrentSparkAppName, DataZone.RawZone.toString, "StructuralValidation",
      rawZoneProfile.entityName, "Processed", "DailyRefresh")
    val inboundPaths = collectColumnValues(structureValidDf, "inboundPath").sorted
    val resolvedValidFilesetPath = collectColumnValues(resolvedDf, "validFileSetPath").sorted

    copyFiles(inboundPaths, resolvedValidFilesetPath, true)
    resolvedDf
  }

  /**
   * write the structurally invalid files to the appropriate location
   *
   * @param structureValidDf The dataframe containing the list of the structurally invalid files
   * @return The synatatically invalid data frame
   */
  def postProcessStructureInvalidFiles(
                                        structureInvalidDf: SyntaticallyInvalidDataFrame
                                      ): SyntaticallyInvalidDataFrame = {
    //TODO define what to save, where to save and under which folder
    logMessage = s"2.2.1 Save structurally Invalid metadata to: ${rawZoneProfile.invalidFileSetPath + RelativeMetadataPath}"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Inbound to invalid file set", logMessage)

    Writers.writeAsCsv(
      structureInvalidDf,
      rawZoneProfile.invalidFileSetPath + RelativeMetadataPath,
      partitionColNames = Some(Array("audit_submission_date")),
      saveMode = SaveMode.Append,
      overwriteFolder = true,
      writeOptions = CsvWriteOptions
    )
    logMessage = s"2.2.2 Copy structurally Invalid files to: ${rawZoneProfile.invalidFileSetPath}"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Inbound to invalid file set", logMessage)
    val resolvedDf = structureInvalidDf.withColumn(
      "invalidFileSetPath",
      concat(
        lit(rawZoneProfile.invalidFileSetPath + RelativeDataPath).cast(StringType),
        col("audit_submission_date"),
        lit("/"),
        col("name")
      )
    )
    rawZoneProfile.auditTableRepository.insertEntityJourneyFilesAuditEntry(resolvedDf, SynapseSpark.getCurrentSparkAppName, DataZone.RawZone.toString, "StructuralValidation",
      rawZoneProfile.entityName, "Failed", "DailyRefresh")
    val inboundPaths = collectColumnValues(structureInvalidDf, "inboundPath").sorted
    val resolvedInvalidFilesetPath = collectColumnValues(resolvedDf, "invalidFileSetPath").sorted

    copyFiles(inboundPaths, resolvedInvalidFilesetPath, true)
    resolvedDf
  }

  /**
   * Get the submission date column
   *
   * @param structureValidDf The dataframe containing the list of the structurally valid files
   * @return The synatatically valid data frame
   */
  protected def getSubmissionDate(filesDfWthSubmitDate: DataFrame): Date = {
    filesDfWthSubmitDate.select("audit_submission_date").first().getAs[Date](0)
  }

  /**
   * Performs semantic validation on the syntactically valid files DataFrame.
   *
   * @param syntaticValidFilesDf The DataFrame of syntactically valid files.
   * @return A tuple of DataFrames containing valid and invalid rows after semantic validation.
   */
  def doSemanticValidation(
                            syntaticValidFilesDf: SyntaticallyValidDataFrame
                          ): (SemanticallyValidDataFrame, SemanticallyInvalidDataFrame) = {
    // Load semantic data
    val semanticDf = loadSemanticData.load(syntaticValidFilesDf)
    // Perform semantic validation
    var semanticResultDf = semanticValidator.check(semanticDf)
    logMessage = s"3.1 Adding submissionDate back to SemanticDataFrame. It is retrieved from SyntaticallyValidDataFrame passed as input."
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)
    // Additional processing steps
    semanticResultDf = semanticResultDf.withColumn(
      "audit_submission_date_hr_min",
      concat(element_at(split(col("audit_file_path"), "/"), -2), lit(s"_${rawZoneProfile.currentRunStartHourAndMinute}"))
    )
    semanticResultDf =
      MetadataOperations.addMetadataColumns(semanticResultDf, SynapseSpark.getUserUUID)
    semanticResultDf = DataFrames.addPipelineRunId(semanticResultDf)
    semanticResultDf = DataFrames.addActivityRunId(semanticResultDf)
    semanticResultDf = DataZoneUtilImpl.addFileNameCol(semanticResultDf)
    // Show the resulting DataFrame
    show(semanticResultDf)
    rawZoneProfile.auditTableRepository.insertEntityJourneyAuditEntry(semanticResultDf, SynapseSpark.getCurrentSparkAppName, DataZone.RawZone.toString,
      "SemanticValidation", rawZoneProfile.entityName, "audit_submission_date_hr_min", "Started",
      "DailyRefresh", rawZoneProfile.validFileSetPath + RelativeDataPath)
    // Get check names for validation
    val checkNames: scala.Seq[String] = semanticValidator match {
      case validator: DeequBackedSemanticValidator =>
        validator.getCheckNames()
      case _ =>
        Seq.empty
    }


    // Split DataFrame into valid and invalid based on semantic validation
    val (semanticValidDf, semanticInvalidDf) = if (!checkNames.isEmpty) {
      semanticValidator.splitValidAndInvalidSemantic(
        semanticResultDf,
        checkColNames = checkNames
      )
    } else {
      logMessage = s"3.2 SemanticValidator is not configured or a NoOpSemanticValidator is configured. Processing continuing with structurally valid data."
      logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)
      return (semanticResultDf, SynapseSpark.getActiveSession.emptyDataFrame)
    }

    // Log validation results
    val semanticRowCount = semanticResultDf.count()
    val validRowCount = semanticValidDf.count
    val invalidRowCount = semanticInvalidDf.count
    logMessage = s"3.3 After semantic validation. Valid rows (out of $semanticRowCount): $validRowCount, Invalid rows: $invalidRowCount"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Semantic validation", logMessage)

    (semanticValidDf, semanticInvalidDf)
  }

  /**
   * Performs structural validation on the input DataFrame.
   *
   * @param fileListDf The DataFrame of files to be processed.
   * @return A tuple of DataFrames containing valid and invalid rows after structural validation.
   */
  def doStructuralValidation(
                              fileListDf: FileListDataFrame
                            ): (SyntaticallyValidDataFrame, SyntaticallyInvalidDataFrame) = {
    val structuralResultDf = structuralValidator.check(fileListDf)
    rawZoneProfile.auditTableRepository.insertEntityJourneyFilesAuditEntry(structuralResultDf, SynapseSpark.getCurrentSparkAppName, DataZone.RawZone.toString, "StructuralValidation",
      rawZoneProfile.entityName, "Started", "Daily refresh")
    logMessage = s"After file-level metadata validation"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Structural validation", logMessage)

    show(structuralResultDf)

    val checkNames: scala.Seq[String] = structuralValidator match {
      case validator: DeequBackedStructuralValidator =>
        validator.getCheckNames()
      case _ =>
        Seq.empty
    }
    val (structureValidDf, structureInvalidDf) =
      structuralValidator.splitValidAndInvalidStructural(
        structuralResultDf,
        checkColNames = checkNames
      )
    (structureValidDf, structureInvalidDf)
  }


  /**
   * Performs structural validation on the input DataFrame.
   *
   * @param inputDf The DataFrame of files to be processed.
   * @return A tuple of DataFrames containing valid and invalid rows after structural validation.
   */
  def doStructuralValidation(
                              inputDf: LandingDataFrame,
                              fileFormat: StorageFormat
                            ): (SyntaticallyValidDataFrame, SyntaticallyInvalidDataFrame)


  /**
   * Derive submission date from the path
   *
   * @param inputDf
   * @return
   */
  protected def deriveSubmissionDatetime(inputDf: DataFrame): Try[DataFrame] = {
    def leftPad(columnName: String): Column = {
      //If month or day is single digit, then prefix it with 0
      when(length(col(columnName)) < 2, concat(lit("0"), col(columnName)))
        .otherwise(col(columnName))
    }

    Try(
      inputDf
        .withColumn("submission_day", element_at(split(col("path"), "/"), -2))
        .withColumn("submission_month", element_at(split(col("path"), "/"), -3))
        .withColumn("submission_year", element_at(split(col("path"), "/"), -4))
        .withColumn("audit_submission_date", to_date(concat(col("submission_year"), leftPad("submission_month"), leftPad("submission_day")), "yyyyMMdd"))
    )

  }


  /**
   * Get the final write options
   *
   * @param entityName
   * @return
   */

  def getFileListToBeProcessed(landingPath: String): DataFrame = {
    SynapseSpark.deepLsToDataFrame(Array(landingPath))
  }

  /**
   * get column values as a list
   *
   * @param df
   * @param columnName
   * @return list of column values
   */
  def collectColumnValues(df: DataFrame, columnName: String): List[String] = {
    df.select(columnName).rdd.map(r => r(0).toString).collect().toList
  }


  /**
   * Move files from one location to another
   *
   * @param fromList       list of files to be moved
   * @param toDir          destination directory
   * @param overwriteFiles flag to overwrite files
   */
  def copyFiles(
                 fromList: List[String],
                 toDir: String,
                 overwriteFiles: Boolean = true
               ): Unit = {
    if (SynapseSpark.isLocalEnv) {
      val targetDirPath = Paths.get(toDir)
      if (!Files.exists(targetDirPath)) {
        Files.createDirectories(targetDirPath)
      }
      val CreateDestDir = true

      for (from <- fromList) {
        //Remove file: prefix
        val fromFile =
          if (from.startsWith("file:"))
            new File(from.substring(from.indexOf(":") + 1))
          else new File(from)
        val toFile = new File(toDir)

        if (overwriteFiles) {
          val targetFilePath = toFile + from.substring(from.lastIndexOf("/"))
          logMessage = s"overwriteFiles set to true. Deleting from target dir: $targetFilePath"
          logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Copy file", logMessage)

          Files.deleteIfExists(Paths.get(targetFilePath))
        }
        FileUtils.copyFileToDirectory(fromFile, toFile, CreateDestDir)

        logMessage = s"Copied [$from] to [$targetDirPath]"
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Copy file", logMessage)
      }

      fromList.map(file => {
        val arr = file.split("/")
        val fileName = arr.last
      })
    } else {
      val DoNotCopyRecursively =
        false
      for (from <- fromList) {
        mssparkutils.fs.cp(from, toDir, DoNotCopyRecursively)
      }
    }
  }

  /**
   * Move files from one location to another
   *
   * @param fromList       list of files to be moved
   * @param toList         destination directory
   * @param overwriteFiles flag to overwrite files
   */
  def copyFiles(
                 fromList: List[String],
                 toList: List[String],
                 overwriteFiles: Boolean
               ): Unit = {
    if (SynapseSpark.isLocalEnv) {
      var count = 0
      for (from <- fromList) {
        val tempDir = toList(count)
        val toDir = tempDir.substring(0, tempDir.lastIndexOf(("/")))
        val targetDirPath = Paths.get(toDir)
        if (!Files.exists(targetDirPath)) {
          Files.createDirectories(targetDirPath)
        }
        val CreateDestDir = true

        //Remove file: prefix
        val fromFile =
          if (from.startsWith("file:"))
            new File(from.substring(from.indexOf(":") + 1))
          else new File(from)
        val toFile = new File(toDir)
        if (overwriteFiles) {
          val targetFilePath = toFile + from.substring(from.lastIndexOf("/"))
          logMessage = s"overwriteFiles set to true. Deleting from target dir: $targetFilePath"
          logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Copy file", logMessage)

          Files.deleteIfExists(Paths.get(targetFilePath))
        }
        FileUtils.copyFileToDirectory(fromFile, toFile, CreateDestDir)

        logMessage = s"Copied [$from] to [$targetDirPath]"
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Copy file", logMessage)
        count = count + 1
      }
      fromList.map(file => {
        val arr = file.split("/")
        val fileName = arr.last
      })
    } else {
      //TODO: test it on Synapse
      var count = 0
      val DoNotCopyRecursively =
        false
      for (from <- fromList) {
        val tempDir = toList(count)
        val toDir = tempDir.substring(0, tempDir.lastIndexOf(("/")))
        mssparkutils.fs.mkdirs(toDir + "/")
        mssparkutils.fs.cp(from, toDir, DoNotCopyRecursively)
        logMessage = s"Copied [$from] to [$toDir]"
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Copy file", logMessage)

        count = count + 1
      }
    }
  }

  /**
   * Move files from one location to another
   *
   * @param fromList       list of files to be moved
   * @param toList         destination directory
   * @param overwriteFiles flag to overwrite files
   */

  def moveFiles(
                 fromList: List[String],
                 toList: List[String],
                 overwriteFiles: Boolean
               ): Unit = {
    if (SynapseSpark.isLocalEnv) {
      var count = 0
      for (from <- fromList) {
        val tempFile = toList(count)
        val toDir = tempFile.substring(0, tempFile.lastIndexOf(("/")))
        val targetDirPath = Paths.get(toDir)
        if (!Files.exists(targetDirPath)) {
          Files.createDirectories(targetDirPath)
        }
        val CreateDestDir = true
        //Remove file: prefix
        val fromFile =
          if (from.startsWith("file:"))
            new File(from.substring(from.indexOf(":") + 1))
          else new File(from)
        val toFile = new File(toDir)
        if (overwriteFiles) {
          val targetFilePath = toDir

          logMessage = s"overwriteFiles set to true. Deleting from target dir: $targetFilePath"
          logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Move file", logMessage)
          Files.deleteIfExists(Paths.get(tempFile))
        }
        FileUtils.moveFileToDirectory(fromFile, toFile, CreateDestDir)
        //from is the file name. we are logging all the files name which we are moving as part of the move operation.
        logMessage = s"Moved [$from] to [$targetDirPath]"
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Move file", logMessage)

        count = count + 1
      }
      fromList.map(file => {
        val arr = file.split("/") //todo find a system agnostic file separator
        val fileName = arr.last
      })
    } else {
      var count = 0
      val CreateParentDir =
        true
      val OverwriteDestFolder =
        true
      for (from <- fromList) {
        val tempDir = toList(count)
        val toDir = tempDir.substring(0, tempDir.lastIndexOf(("/")))
        mssparkutils.fs.mkdirs(toDir + "/")
        mssparkutils.fs.mv(from, toDir, CreateParentDir, OverwriteDestFolder)
        count = count + 1
      }
    }
  }


  /**
   * Move files from one location to another
   *
   * @param fromList       list of files to be moved
   * @param toDir          destination directory
   * @param overwriteFiles flag to overwrite files
   */
  def moveFiles(
                 fromList: List[String],
                 toDir: String,
                 overwriteFiles: Boolean = true
               ): Unit = {
    if (SynapseSpark.isLocalEnv) {
      val targetDirPath = Paths.get(toDir)
      if (!Files.exists(targetDirPath)) {
        Files.createDirectories(targetDirPath)
      }
      val CreateDestDir = true
      for (from <- fromList) {
        //Remove file: prefix
        val fromFile =
          if (from.startsWith("file:"))
            new File(from.substring(from.indexOf(":") + 1))
          else new File(from)
        val toFile = new File(toDir)
        if (overwriteFiles) {
          val targetFilePath = toFile + from.substring(from.lastIndexOf("/"))

          logMessage = s"overwriteFiles set to true. Deleting from target dir: $targetFilePath"
          logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Move file", logMessage)

          Files.deleteIfExists(Paths.get(targetFilePath))
        }
        FileUtils.moveFileToDirectory(fromFile, toFile, CreateDestDir)
        logMessage = s"Moved [$from] to [$targetDirPath]"
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Move file", logMessage)
      }
      fromList.map(file => {
        val arr = file.split("/") //todo find a system agnostic file separator
        val fileName = arr.last
      })
    } else {
      //TODO: test it on Synapse
      val CreateParentDir =
        true //If true, will firstly create the parent dir if not exists before move op
      val OverwriteDestFolder =
        true //If true, will overwrite the destination folder if exists
      for (from <- fromList) {
        mssparkutils.fs.mv(from, toDir, CreateParentDir, OverwriteDestFolder)
      }
    }
  }

  //Create new directories based on the path

  /**
   * Create new directories based on the path
   *
   * @param path
   *
   */
  def createDirectories(path: String): Unit = {
    logInfo(s"Create directories for $path: START")
    if (SynapseSpark.isLocalEnv) {
      val directoryPath = Paths.get(path)
      if (!Files.exists(directoryPath)) {
        Files.createDirectories(directoryPath)
      } else {
        logMessage = s"$path! is already present. No need to create new directories."
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Create directories", logMessage)

      }
    } else {
      mssparkutils.fs.mkdirs(path)
      mssparkutils.fs.ls(path)
      logMessage = s"$path has been created."
      logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Create directories", logMessage)

    }
    logMessage = s"Create directories for $path: END"
    logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Create directories", logMessage)

  }


  /**
   * Get the final write options
   *
   * @param entityName
   * @return
   */
  def getFinalWriteOptions(entityName: String): Map[String, String] = {
    GenericValidator.getRawWriteOptions(rawZoneProfile.tableCfg)
  }


  /**
   * Delete the empty directories
   *
   * @param path     path of the directory to be deleted
   * @param iterator iterator to prevent deletion of final folder
   */
  def deleteEmptyDirectories(path: String, iterator: Int = 0): Unit = {

    /** *
     * Here the iterator is used to prevent the deletion deletion final folder mentioned in our path arguments:
     * eg: if path is /etc/example: iterator will help us prevent deleting the example folder after deleting all the empty sub folders
     */
    if (SynapseSpark.isLocalEnv) {
      val targetDirPath = new File(path)
      val files = targetDirPath.listFiles()
      files.foreach(println)
      if (files.length == 0) {
        iterator match {
          case 0 => return
          case _ => FileUtils.deleteDirectory(targetDirPath)
        }
        return
      } else {
        for (file <- files) {
          if (file.isDirectory) {
            deleteEmptyDirectories(file.getAbsolutePath, iterator + 1)
          }
        }
      }
      if (iterator != 0) {
        val afterDeleteDirPath = new File(path)
        val afterDeleteFiles = afterDeleteDirPath.listFiles()
        if (afterDeleteFiles.length == 0) {
          FileUtils.deleteDirectory(afterDeleteDirPath)
        }
      }
    } else {
      logMessage = s"Trying deleting $path folder"
      logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Delete empty directories", logMessage)

      val files = mssparkutils.fs.ls(path)
      if (files.length == 0) {
        iterator match {
          case 0 => return
          case _ => mssparkutils.fs.rm(path)
        }
        return
      } else {
        for (file <- files) {
          if (file.isDir) {
            deleteEmptyDirectories(file.path, iterator + 1)
            logMessage = s"after recursion call: ${file.path}"
            logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Delete empty directories", logMessage)
          }
        }
      }
      if (iterator != 0) {

        val afterDeleteFiles = mssparkutils.fs.ls(path)
        if (afterDeleteFiles.length == 0) {
          mssparkutils.fs.rm(path)
        }
      }
    }
  }


  /**
   * Delete the directories
   *
   * @param paths list of paths to be deleted
   */
  def deleteDirectory(paths: List[String]): Unit = {
    paths.foreach(println)
    if (SynapseSpark.isLocalEnv) {
      for (path <- paths) {
        logMessage = s"Deleting directory: $path"
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Delete directory", logMessage)

        val targetDirPath = new File(path)
        FileUtils.deleteDirectory(targetDirPath)
      }
    } else {
      for (path <- paths) {
        logMessage = s"Deleting directory: $path"
        logEntityJourneyEvent(rawZoneProfile.entityName, DataZone.RawZone, zoneSubStep = "Delete directory", logMessage)

        mssparkutils.fs.rm(path, true)
      }
    }
  }

  def getListOfColumnsWhichAreNotPresentInSchema(postStructureValidDf: DataFrame, keyList: List[String]): Unit = {
    val validFileSetPathArray = postStructureValidDf.select("validFileSetPath").collect().map(_.getString(0))
    val validFileSetPath = validFileSetPathArray(0).split("/").dropRight(2).mkString("/") + "/**"
    var validFileSetDfWithoutSchema = DataFrames.getDataFrameFromUri(validFileSetPath, StorageFormat.JSON, null, true, getFinalWriteOptions(entityName =
      rawZoneProfile.entityName))
    validFileSetDfWithoutSchema = flattenStructureToDataFrame(validFileSetDfWithoutSchema)
    var validFileSetDfWithSchema = DataFrames.getDataFrameFromUri(validFileSetPath, StorageFormat.JSON, DataZoneUtilImpl.getFinalRawTableSchema
    (rawZoneProfile.entityName), true,
      getFinalWriteOptions(entityName = rawZoneProfile.entityName))
    validFileSetDfWithSchema = flattenStructureToDataFrame(validFileSetDfWithSchema)
    val columnsNotPresentInSchema = validFileSetDfWithoutSchema.columns.distinct.diff(validFileSetDfWithSchema.columns)
    //val columnsNotPresentInSchemaWithID = columnsNotPresentInSchema :+ "Item_hashedKocid_S" :+ "audit_file_path" :+ "audit_file_name"
    val columnsNotPresentInSchemaWithID = Array.concat(columnsNotPresentInSchema, keyList.toArray) :+ "audit_file_path" :+ "audit_file_name"

    columnsNotPresentInSchemaWithID.foreach(println)

    validFileSetDfWithSchema.show(10, false)
    validFileSetDfWithoutSchema.show(10, false)

    var additionalColumnsDf = validFileSetDfWithoutSchema.select(columnsNotPresentInSchemaWithID.head, columnsNotPresentInSchemaWithID.tail: _*)
    additionalColumnsDf.show(10, false)
    additionalColumnsDf = additionalColumnsDf.withColumn(
      "audit_submission_date_hr_min",
      concat(element_at(split(col("audit_file_path"), "/"), -2), lit(s"_${rawZoneProfile.currentRunStartHourAndMinute}"))
    )

    if (columnsNotPresentInSchema.nonEmpty) {
      logInfo(s"Columns not present in schema: ${columnsNotPresentInSchema.mkString(",")}")
      println(rawZoneProfile.validDataAdditionalColumnsPath)
      Writers.writeAsJson(additionalColumnsDf, rawZoneProfile.validDataAdditionalColumnsPath,
        partitionColNames = Some(Array("audit_submission_date_hr_min")), saveMode = SaveMode.Append,
        overwriteFolder = true)

    }
    else {
      logInfo("The file only contains columns present in schema.")
    }


  }
}
