package com.tccc.dna.datazones.validators

import com.tccc.dna.synapse.StorageFormat
import org.apache.spark.internal.Logging
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.StructType

/**
 * An abstract class representing a data loader.
 *
 * @param jsonSchemaAsStr Optional JSON schema as a string.
 * @param entitySchema    Optional entity schema as a StructType.
 * @param entityFormat    The storage format of the entity (e.g., JSON, TSV, CSV).
 * @param readOptions     Read options for loading data.
 * @param cacheDf         Flag indicating whether to cache the DataFrame after loading.
 */
abstract class DataLoader(jsonSchemaAsStr: Option[String],
                          entitySchema: Option[StructType],
                          entityFormat: StorageFormat,
                          readOptions: Map[String, String],
                          cacheDf: Boolean = false) extends Logging {

  /**
   * Loads data into a DataFrame and performs necessary transformations.
   *
   * @param inputDf The input DataFrame to be loaded and processed.
   * @return The processed DataFrame after loading and transformations.
   */
  def load(inputDf: DataFrame): DataFrame
}
