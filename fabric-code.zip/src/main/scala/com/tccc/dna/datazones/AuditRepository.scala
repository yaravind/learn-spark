package com.tccc.dna.datazones

/** *
 * A [[https://rusyasoft.github.io/ddd/2018/05/10/ddd-repository/ Repository]] to work with audit records in '''[sch_ops].[audit]''' table.
 */
trait AuditRepository {
  def save(record: AuditRecord): Long

  def findByPipelineId(pipelineId: String): List[AuditRecord]

  def findByActivityId(activityId: String): List[AuditRecord]

  def findWithinDateRange(startDate: Long, endDate: Long): List[AuditRecord]
}