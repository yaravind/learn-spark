package com.tccc.dna.datazones.init

/**
 * ApplicationConstants is a class that contains constants used throughout the application. This is will be the only place where application level constants
 * are defined.
 */
class ApplicationConstants {

  //Other Constants
  lazy val notAvailable:String = "Not Available"

  //Local Base Path
  lazy val localBasePathLoc = "src/test/resources/experiment/metadata/control_files/"

  //Synapse Variables

  lazy val devSynapseName:String = "syn-tccc-udp-mai-us2-dev-01"
  lazy val uatSynapseName:String = "syn-tccc-udp-mai-us2-uat-03"
  lazy val prodSynapseName:String = "syn-tccc-udp-mai-us2-prd-02"

  lazy val devStorageAccount:String = "storagemai01us2dev"
  lazy val uatStorageAccount:String = "storagemai03us2uat"
  lazy val prodStorageAccount:String = "storagemai02us2prd"

  //Application  Level Variables
  val appName:String = notAvailable
  val additionalAppName: String = notAvailable
  lazy val controlFileLoc:String = "control_files/"
  lazy val appConfigFileName:String = "initApplication.json"

  //Environment Variables and functions
  lazy val localEnvironment:String = "localExperiment"
  lazy val testEnvironment:String = "testEnvironment"
  lazy val synapseDevExperiment:String = "synapseDevExperiment"
  lazy val synapseUatExperiment:String = "synapseUatExperiment"
  lazy val synapseProdExperiment:String = "synapseProdExperiment"

  //DataZones
  lazy val raw = "raw"
  lazy val refined = "refined"
  lazy val certified = "certified"
  lazy val metadata = "metadata"
  lazy val shared = "shared"
  lazy val landing = "landing"
  lazy val experiment = "experiment"

  //Synapse File System
  lazy val fileProtocol = "abfss://"
  lazy val storageAccountUrlPostFix:String = ".dfs.core.windows.net/"

  //DB Constants
  lazy val jdbc = "jdbc"
  lazy val dbtable = "dbtable"
  lazy val turncate = "turncate"
  lazy val append = "append"
  lazy val overwrite = "overwrite"
  lazy val overwriteFromDelta = "overwriteFromDelta"

}
