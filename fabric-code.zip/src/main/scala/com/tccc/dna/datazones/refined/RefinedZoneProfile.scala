package com.tccc.dna.datazones.refined

import com.tccc.dna.datazones.init.TableConfig
import com.tccc.dna.datazones.utils.AuditTableRepository
import org.apache.commons.lang3.builder.ToStringBuilder
//import org.apache.commons.lang.builder.{ToStringBuilder}
import org.apache.commons.lang3.builder.ToStringStyle


/**
 * Encapsulates all the configuration needed for Refined Zone to read data and process data from RawZone.
 *
 * @param entityName             Name of the entity this RawZoneProfile is for.
 * @param controlFilePath
 * @param rawFullPath             Directory, within raw zone,  where valid files (passed semantic/structural validation)  are moved to.
 * @param refinedFullPath         Directory, within refined zone
 * @param currentRunStartHourAndMinute This is the partition where the data is picked up by the next step in the process. This is a random string of 8
 *                                     characters and generated as {{{RandomStringUtils.random(8, "0123456789abcdef")}}}.
 */
case class RefinedZoneProfile (entityName: String,
                               controlFilePath: String,
                               rawFullPath: String,
                               refinedFullPath: String,
                               currentRunStartHourAndMinute: String,
                               currentRunStartDateTime: String,
                               filterCondition: Map[String, Array[String]],
                               tableCfg: TableConfig,
                               auditTableRepository: AuditTableRepository
                              ){

  override def toString: String = new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
    .append("entityName", entityName)
    .append("controlFilePath", controlFilePath)
    .append("rawFullPath", rawFullPath)
    .append("refinedFullPath", refinedFullPath)
    .append("currentRunStartHourAndMinute", currentRunStartHourAndMinute)
    .append("currentRunStartDateTime", currentRunStartDateTime)
    .append("filterCondition", filterCondition)
    .append("tableCfg", tableCfg)
    .append("auditTableRepository", auditTableRepository)
    .toString
}
