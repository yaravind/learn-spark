package com.tccc.dna.datazones

import com.tccc.dna.synapse.Logging

import java.sql.{ResultSet, Statement, Timestamp}
import scala.reflect.ClassTag
import scala.util.{Failure, Success, Try}

/**
 * A JDBC implementation of [[AuditRepository]].
 *
 * @param dbManager An instance of [[DbManager]] created using the companion object.
 */
class JdbcAuditRepository(dbManager: DbManager) extends AuditRepository with Logging {
  private val InsertStmt =
    """INSERT INTO [sch_ops].[audit] (app_cd, sub_app_cd, artifact_typ, artifact_id, data_zone, action_typ,
      |total_files_to_be_processed, total_rows, total_cols, create_timestamp, create_user_id)
      |VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""".stripMargin

  override def save(record: AuditRecord): Long = {
    var auditId: Try[Long] = Success(-1)

    dbManager.getConnection match {
      case Success(conn) => dbManager.using(conn) { conn =>
        val preparedStmt = conn.prepareStatement(InsertStmt, Statement.RETURN_GENERATED_KEYS)

        preparedStmt.setString(1, record.appCode)
        preparedStmt.setString(2, record.subAppCode)
        preparedStmt.setString(3, record.artifactType)
        preparedStmt.setString(4, record.artifactId)
        preparedStmt.setString(5, record.dataZone)
        preparedStmt.setString(6, record.actionType)
        //TODO Change the following if once JSON is stored as a separate String and Audit columns are sorted out.
        if (record.context.nonEmpty) {
          preparedStmt.setInt(7, getAsType[Int]("totalFilesToBeProcessed", record.context))
          preparedStmt.setInt(8, getAsType[Int]("rowCount", record.context))
          preparedStmt.setInt(9, getAsType[Int]("colCount", record.context))
        }
        preparedStmt.setTimestamp(10, Timestamp.from(record.createTime))
        preparedStmt.setString(11, record.user)

        auditId = Try[Long] {
          preparedStmt.executeUpdate()
          val generatedKeys = preparedStmt.getGeneratedKeys
          if (generatedKeys.next()) {
            generatedKeys.getLong(1) // gets the generated 'audit_id'
          } else {
            logError("Failed to retrieve audit_id after insert.")
            -1
          }
        }
      }
      case Failure(exception) =>
        dbManager.closeConnection()
        logError("Failed to connect to DB", exception)
    }
    auditId.get
  }

  private def getAsType[T: ClassTag](key: String, map: Map[String, Any]): T = {
    val value = map.get(key).orNull
    if (value == null) null.asInstanceOf[T]
    else value.asInstanceOf[T]
  }

  override def findByPipelineId(pipelineId: String): List[AuditRecord] = ???

  override def findByActivityId(activityId: String): List[AuditRecord] = ???

  override def findWithinDateRange(startDate: Long, endDate: Long): List[AuditRecord] = ???


  /**
   * Converts a java.sql.ResultSet into a Scala Stream. This allows for processing of a ResultSet in a more functional
   * and Scala idiomatic way instead of using Java's imperative style looping constructs. This is done by wrapping the
   * ResultSet in a Scala Iterator and then converting it to a Stream.
   *
   * @param res A [[ResultSet]] which is the result of executing a database query in JDBC.
   * @param f   A function that takes a [[ResultSet]] and returns a value of some type `T`.
   * @tparam T Return type for function `f`.
   * @return A [[Stream]] of type `T`.
   */
  def resultSetItr[T](res: ResultSet)(f: ResultSet => T): Stream[T] = {
    new Iterator[T] {
      override def hasNext: Boolean = res.next()

      override def next(): T = f(res)
    }.toStream
  }
}