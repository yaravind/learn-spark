package com.tccc.dna.datazones.validators

import org.apache.spark.sql.DataFrame

class ParquetSemanticValidator (cacheDf: Boolean = false) extends DeequBackedSemanticValidator {
  override def check(inputDf: DataFrame): DataFrame = {
    if (cacheDf) {
      logInfo(s"Caching is enabled (cacheDf = true). Calling df.cache()")
      inputDf.cache()
    }
    logInfo("dataframe before semantic validation inside csv validator")
    inputDf.show(5, false)
    val semanticResultDf = super.check(inputDf)


    logInfo(s"File row count: ${semanticResultDf.count()}")
    semanticResultDf
  }

}
