package com.tccc.dna.datazones.init

/**
 * Class encapsulate logic to determine the environment the job is running.
 * @see https://wiki.coke.com/confluence/pages/viewpage.action?pageId=218065842
 * Different types are environments are:
 * 1. Local Environment: This is on developers laptop.
 * 2. Test Environment: This is run when testcases are run to validate the sanctity of the code. It can be run locally or on GitHub Runners.
 * 3. Synapse Environment: This is when code is running on Synapse.
 * 4. Experiment Environment: This is when developer is running code on synapse under own user id.
 */

import com.tccc.dna.synapse.spark.{SynapseSpark => SS}
import com.tccc.dna.synapse.{Logging, Utils}

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter



class EnvironmentConfig(applicationConstants: ApplicationConstants) extends Logging{

  val currentDate: LocalDateTime = LocalDateTime.now()
  lazy val currentUserName: String = Utils.getUserNameFromEmail(SS.getCurrentUserName)
  lazy val currentRunStartHourAndMinute = s"${currentDate.getHour}_${currentDate.getMinute}"
  lazy val currentRunStartDateTime = s"${DateTimeFormatter.ofPattern("yyyy-MM-dd_HH_mm").format(currentDate)}"

  /**Identifies the Environment
   *
   * @param env identifies testEnvironment or Synapse
   *
   * @return environment
   * */
  def getEnvironment(env: String):String = {
    if(env == applicationConstants.notAvailable){
      applicationConstants.localEnvironment
    }else{
      if(SS.getCurrentSynapseWorkspaceName == applicationConstants.notAvailable) {
       env
      } else{
        if(!SS.isRunAsManagedIdentity){
          SS.getCurrentSynapseWorkspaceName
        }else{
          getExperimentEnvironment
        }
      }
    }
  }

  /** @return Experiment Node name for initApplication.json file */
  private def getExperimentEnvironment = {
    var experimentEnv: String = ""
    SS.getCurrentSynapseWorkspaceName match{
      case devSynapseName =>
        experimentEnv = applicationConstants.synapseDevExperiment
      case uatSynapseName =>
        experimentEnv = applicationConstants.synapseUatExperiment
      case prodSynapseName =>
        experimentEnv = applicationConstants.synapseProdExperiment
    }
    experimentEnv
  }

}
