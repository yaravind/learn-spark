package com.tccc.dna.datazones.init

import com.tccc.dna.datazones.utils.{DataFrameUtil, JsonFile}
import com.tccc.dna.synapse.StorageFormat
import com.tccc.dna.synapse.spark.SynapseSpark
import org.apache.spark.sql.DataFrame

class RDBMSConfig {

  protected var rdbmsConfigDf: DataFrame = SynapseSpark.getActiveSession.emptyDataFrame

  def loadConfig(path: String, appName: String, fileName: String): Unit = {
    rdbmsConfigDf = JsonFile.readFile(
      path + appName + "/RDBMSConfig.json",
      Map("header" -> "false", "multiline" -> "true"),
      StorageFormat.JSON
    ).cache
  }

  def getDbJdbcOptionsMap(dbKey:String): Map[String,String] = {
    Map("url" -> getDbUrl(dbKey),
    "user"-> getDbUserName(dbKey),
    "password"-> getDbUserPassword(dbKey))
  }

  def getDbUrl(dbKey:String):String ={
    s"jdbc:sqlserver://${getDbServerName(dbKey)}:${getDbServerPort(dbKey)};database=${
      getDbDatabaseName(dbKey)}"
  }


  def getDbServerName(dbKey:String): String = DataFrameUtil
    .flattenDataFrame(
      rdbmsConfigDf.select(s"${dbKey}.dbServerName")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getDbServerPort(dbKey:String): String = DataFrameUtil
    .flattenDataFrame(
      rdbmsConfigDf.select(s"${dbKey}.dbServerPort")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getDbDatabaseName(dbKey:String): String = DataFrameUtil
    .flattenDataFrame(
      rdbmsConfigDf.select(s"${dbKey}.dbDatabaseName")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getDbUserName(dbKey:String): String = DataFrameUtil
    .flattenDataFrame(
      rdbmsConfigDf.select(s"${dbKey}.dbUserName")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getDbUserPassword(dbKey:String): String = DataFrameUtil
    .flattenDataFrame(
      rdbmsConfigDf.select(s"${dbKey}.dbUserPassword")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getDbJdbcDriver(dbKey:String): String = DataFrameUtil
    .flattenDataFrame(
      rdbmsConfigDf.select(s"${dbKey}.jdbcDriver")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")
}
