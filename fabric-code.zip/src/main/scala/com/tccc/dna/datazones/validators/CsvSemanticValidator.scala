package com.tccc.dna.datazones.validators

import org.apache.spark.sql.DataFrame


//TODO V - Find out why this class is passing in entityFormat and Schema
// if they're not being used
/**
 * A DataLoader implementation for loading CSV data.
 *
 * @param entitySchema Optional entity schema as a StructType.
 * @param readOptions  Read options for loading CSV data.
 * @param cacheDf      Flag indicating whether to cache the DataFrame after loading.
 */
class CsvSemanticValidator(cacheDf: Boolean = false) extends DeequBackedSemanticValidator {
  override def check(inputDf: DataFrame): DataFrame = {
    if (cacheDf) {
      logInfo(s"Caching is enabled (cacheDf = true). Calling df.cache()")
      inputDf.cache()
    }
    logInfo("dataframe before semantic validation inside csv validator")
    inputDf.show(5, false)
    val semanticResultDf = super.check(inputDf)


    logInfo(s"File row count: ${semanticResultDf.count()}")
    semanticResultDf
  }
}
