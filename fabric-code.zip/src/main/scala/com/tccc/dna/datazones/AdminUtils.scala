package com.tccc.dna.datazones

import com.tccc.dna.synapse.{AzStorage, Logging}

import scala.collection.mutable

object AdminUtils extends Logging {
  val ExperimentFolder: String = "/experiment"
  val RootFolders: List[String] = List(ExperimentFolder, "/data", "/metadata")
  val DataZoneFolders: List[String] = List("stage", "refined", "certified")
  val SynapsePrimaryStorageAcct: String = "/"

  def createRootFolders(basePath: String = SynapsePrimaryStorageAcct): mutable.SortedMap[String, String] = {
    val paths = RootFolders.map(p => basePath.toLowerCase + p)
    val results = AzStorage.createFolders(paths)

    for ((folder, result) <- results) {
      val msg = s"Folder: $folder, Result: $result"
      logInfo(msg, logToNotebook = true)
    }
    results
  }

  def createDataZones(basePath: String = SynapsePrimaryStorageAcct): mutable.SortedMap[String, String] = {
    val paths = DataZoneFolders.map(p => basePath.toLowerCase + "/" + p)
    val results = AzStorage.createFolders(paths)

    for ((folder, result) <- results) {
      val msg = s"Folder: $folder, Result: $result"
      logInfo(msg, logToNotebook = true)
    }

    results
  }

  def createUserFolders(userName: String): mutable.SortedMap[String, String] = {
    val basePath = ExperimentFolder + "/" + userName.toLowerCase + "/"
    val userExpFolders = DataZoneFolders.map(f => basePath + f)

    val results = AzStorage.createFolders(userExpFolders)

    for ((folder, result) <- results) {
      val msg = s"Folder: $folder, Result: $result"
      logInfo(msg, logToNotebook = true)
    }

    results
  }
}