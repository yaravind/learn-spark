package com.tccc.dna.datazones.certified.rdbms

import com.tccc.dna.datazones.init.ApplicationConstants
import com.tccc.dna.datazones.utils.{DataZoneUtilImpl, DbUtils}
import com.tccc.dna.synapse.spark.{SynapseSpark => SS}
import com.tccc.dna.synapse.{DataZone, Logging, StorageFormat}
import org.apache.spark.sql.DataFrame

/**
 * Template class to encapsulate general outline and flow of [[RDBMSCertifiedZoneTemplate] logic.
 * @see WIP todo add wiki page with supported features
 *
 * @param rdbmsCertifiedZoneProfile an instance of [[RDBMSCertifiedZoneProfile]]
 *
 */
class RDBMSCertifiedZoneTemplate(val rdbmsCertifiedZoneProfile: RDBMSCertifiedZoneProfile) extends Logging{


  var finalDf: DataFrame = SS.getActiveSession.emptyDataFrame
  var logMessage = ""
  val applicationContants = new ApplicationConstants

  protected def writeToRdbmsCertifiedZone(): DataFrame = {
    val dbKey = rdbmsCertifiedZoneProfile.tableConfig.getDbKey
    val dbUrl = rdbmsCertifiedZoneProfile.rdbmsConfig.getDbUrl(dbKey)
    val dbOptions = rdbmsCertifiedZoneProfile.rdbmsConfig.getDbJdbcOptionsMap(dbKey)
    val dbCertifiedTableName = s"${rdbmsCertifiedZoneProfile.tableConfig.getDbCertifiedQualifiedTableName}"
    val rdbmsCertifiedData =
      DataZoneUtilImpl.getDataFrameFromUriWithFilters(
        rdbmsCertifiedZoneProfile.certifiedFullPath,
        StorageFormat.Delta,
        null,
        Map.empty,
        Map.empty)
    rdbmsCertifiedData.show(20)
    if(rdbmsCertifiedZoneProfile.tableConfig.getRdbmsCertifiedModeOfWrite == applicationContants.overwriteFromDelta){
      //turncate table
      DbUtils.turncateTable(rdbmsCertifiedZoneProfile.tableConfig,rdbmsCertifiedZoneProfile.rdbmsConfig)
      //append data to turncated table to preserve the table definition
      DbUtils.insertDataFrame(dbUrl,rdbmsCertifiedData,dbOptions,dbCertifiedTableName)
    }
    rdbmsCertifiedData
  }

  def execute(): DataFrame = {
    logMessage = s"Certified.RDBMS Zone processing execute method called for entity: ${rdbmsCertifiedZoneProfile.entityName}"
    logEntityJourneyEvent(rdbmsCertifiedZoneProfile.entityName,DataZone.RdbmsCertifiedZone,"",logMessage)

    if(rdbmsCertifiedZoneProfile.tableConfig.getIsRdbmsCertifiedLoadNeeded) {
      finalDf = writeToRdbmsCertifiedZone()
    }
    finalDf
  }


}
