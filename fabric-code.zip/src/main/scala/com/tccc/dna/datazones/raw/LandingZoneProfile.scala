package com.tccc.dna.datazones.raw

import com.tccc.dna.datazones.StorageAccountProps
import com.tccc.dna.synapse.StorageFormat
import org.apache.commons.lang3.builder.ToStringBuilder
//import org.apache.commons.lang.builder.{ToStringBuilder}
import org.apache.commons.lang3.builder.ToStringStyle

/**
 * Encapsulates information related to Landing Zone.
 *
 * @param entityLocation  Instance of either [[String]] or [[StorageAccountProps]].
 * @param entityFormat    An enum from [[StorageFormat]].
 * @param extensions      Arbitrary key/value pairs. Key should be [[String]] type. Value can be [[Any]]. This accounts for
 *                        future unknown scenarios.
 */
case class LandingZoneProfile(
                               entityLocation: Either[String, StorageAccountProps],
                               entityFormat: StorageFormat,
                               extensions: Map[String, Any]
                             ) {

  /**
   * Definition for getting the landing url based on the entity location
   *
   * @return The landing url path
   */
  def getLandingURI: String = {
    entityLocation match {
      case Right(StorageAccountProps(containerOrFileSys, storageAcct, path)) => s"abfss://$containerOrFileSys@$storageAcct.dfs.core.windows.net/$path"
      case Left(path) => path
    }
  }

  override def toString: String = new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
    .append("entityLocation", entityLocation)
    .append("entityFormat", entityFormat)
    .append("extensions", extensions)
    .toString
}