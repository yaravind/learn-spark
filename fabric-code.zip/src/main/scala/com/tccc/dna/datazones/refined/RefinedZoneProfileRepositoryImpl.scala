package com.tccc.dna.datazones.refined

import com.tccc.dna.datazones.init.{ApplicationConfig, TableConfig}
import com.tccc.dna.datazones.utils.AuditTableRepository
import com.tccc.dna.synapse.{DataZone, Logging}

/**
 * Repository to get Refined Zone Profile. Implementation of [[RefinedZoneProfileRepository]].
 *
 * @param appName Application name
 * @param currentRunStartHourAndMinute Part of partition
 * @param currentRunStartDateTime Part of partition
 * @param applicationConfig Application Configuration Object
 * @param auditTableRepository Audit Transaction Table
 *
 */
class RefinedZoneProfileRepositoryImpl(val appName: String,
                                       val currentRunStartHourAndMinute: String,
                                       val currentRunStartDateTime: String,
                                       applicationConfig: ApplicationConfig,
                                       val auditTableRepository: AuditTableRepository
                                      ) extends RefinedZoneProfileRepository with Logging {

  def getRefinedZoneProfile(entityName: String, tableConfig: TableConfig, filterCondition: Map[String, Array[String]]): RefinedZoneProfile = {

    logEntityJourneyEvent(entityName, DataZone.RefinedZone, "", s"Create Refined Profile for $entityName.")

    val baseRawPath = applicationConfig.getFullRawPath
    val baseRefinedPath = applicationConfig.getFullRefinedPath
    RefinedZoneProfile(
      entityName = entityName,
      controlFilePath = applicationConfig.getFullConfigPath,
      rawFullPath = baseRawPath,
      refinedFullPath = baseRefinedPath + tableConfig.getRefinedPath,
      currentRunStartHourAndMinute = currentRunStartHourAndMinute,
      currentRunStartDateTime = currentRunStartDateTime,
      filterCondition = filterCondition,
      tableCfg = tableConfig,
      auditTableRepository = auditTableRepository
    )
  }
}
