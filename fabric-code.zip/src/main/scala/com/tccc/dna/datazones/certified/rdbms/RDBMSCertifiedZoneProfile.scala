package com.tccc.dna.datazones.certified.rdbms

import com.tccc.dna.datazones.init.{RDBMSConfig, TableConfig}
//import org.apache.commons.lang.builder.ToStringBuilder
import org.apache.commons.lang3.builder.{ToStringBuilder, ToStringStyle}

/**
 * Encapsulates all the configuration needed for Certified.rdbms Zone to read data and process (copy, transformation etc.) data from certified Zone.
 * Profile class here provides interface with Certified Zone Data to be transformed for rdbms ingestion.
 *
 * @param entityName                   Name of the entity this RDBMSCertifiedZoneProfile is for.
 * @param controlFilePath              Directory, within metadata folder, where the configuration file is read from
 * @param certifiedFullPath            Directory, within certified zone, where files will be written to
 * @param filterCondition              Map of the filter conditions used on the dataframe if applicable
 * @example
 *          partition_column               |  partition_value
 *          audit_submission_date_hr_min   |  2024-04-30_16_53
 * @param tableConfig                  Entity configuration is stored in this object
 * @param rdbmsConfig                  Contains RDBMS information for the Entity
 */
case class RDBMSCertifiedZoneProfile(entityName: String,
                                     controlFilePath: String,
                                     certifiedFullPath: String,
                                     filterCondition: Map[String, Array[String]],
                                     tableConfig: TableConfig,
                                     rdbmsConfig: RDBMSConfig){

  override def toString: String = new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
    .append("entityName", entityName)
    .append("controlFilePath", controlFilePath)
    .append("certifiedFullPath", certifiedFullPath)
    .append("filterCondition", filterCondition)
    .append("tableConfig", tableConfig)
    .append("rdbmsConfig", rdbmsConfig)
    .toString

}
