package com.tccc.dna.datazones.start

import com.tccc.dna.datazones.init.{ApplicationConfig, ApplicationConstants, ApplicationConstantsImpl, EnvironmentConfig, RDBMSConfig, TableConfig}
import com.tccc.dna.datazones.utils.AuditTableRepository
import com.tccc.dna.synapse.spark.{SynapseSparkBase, SynapseSpark => SS}
import com.tccc.dna.synapse.{DataZone, Logging, Utils}
import org.apache.spark.sql.{DataFrame, SparkSession}


/**
 * AllZoneSparkBaseApp is a class that extends SynapseSparkBase and is used to start the application. It is a generic class that can be extended to process data in any zone.
 */
abstract class AllZoneSparkBaseApp extends SynapseSparkBase with Logging{
   println ("StartApp")
  var startTime = System.currentTimeMillis()
  var logMessage = ""

  var appName = getAppNameFromArgs

  var applicationConstants = getApplicationConstants
  var environmentConfig = getEnvironmentConfig(applicationConstants)

  //create/get Spark Session
  createSparkSession

  var applicationConfig = getApplicationConfig(applicationConstants)
  var currentDataZone = getDataZone

  startZoneProcessing()


  /**
   * This method is used to start the zone processing.
   */
  def startZoneProcessing(): Unit = {

    //Create Log Analytics Bridge log
    logPipelineBridgeEvent(applicationConstants.appName)

    val userName = Utils.getUserNameFromEmail(SS.getCurrentUserName)
    val environment = environmentConfig.getEnvironment(SS.getCurrentSynapseWorkspaceName)
    val configBasePath: String = applicationConfig.getControlFileBasePath(environment)

    logMessage = s"Reading config file for [env: $environment, appName: ${applicationConstants.appName}, and user: $userName] from path: $configBasePath"
    logDataZoneEvent(currentDataZone, "Start", logMessage)
    applicationConfig.loadConfig(configBasePath, applicationConstants.appName, environment, userName)

    //audit table
    val auditTable = new AuditTableRepository(applicationConfig.getRelativeAuditTablePath)

    //Start Entity Processing
    startEntityProcessing(getEntityListToProcess, auditTable)

    val processingtime = System.currentTimeMillis() - startTime
    val (minutes, seconds, millis) = Utils.convertMilliseconds(processingtime)

    logMessage = s"Process time: ($minutes mins, $seconds secs and $millis millis"
    logDataZoneEvent(currentDataZone, "Processed",logMessage)
  }

  /**
   * This method is used to start the entity processing.
   *
   * @param entityList        The list of entities to process
   * @param auditTableRepository The audit table repository to audit entries
   */
  protected def startEntityProcessing(entityList: List[String], auditTableRepository: AuditTableRepository): Unit = {
    logMessage = s"${entityList.length} entite(s) configured to process: $entityList"
    logEntityJourneyEvent("Entities", currentDataZone, zoneSubStep = "driver", logMessage)

    for (entityName <- entityList) {
      logEntityJourneyEvent(entityName, currentDataZone, zoneSubStep = "driver", "Started")
      auditTableRepository.insertDataZoneAuditEntry(applicationConstants.appName, currentDataZone.toString, entityName, "Start", "Daily refresh")
      tableRunner(entityName, applicationConfig.getFullConfigPath, applicationConstants.appName, auditTableRepository)
      auditTableRepository.insertDataZoneAuditEntry(applicationConstants.appName, currentDataZone.toString, entityName, "Processed", "Daily refresh")
      logEntityJourneyEvent(entityName, currentDataZone, zoneSubStep = "driver", "Done")
    }
  }

  /**
   * This method is used to get the list of entities to process.
   *
   * @return List[String]
   */
  protected def getEntityListToProcess: List[String] = {
    if (args.length >= 1) {
      print(args.length)
      logMessage = s"'${args(0)}' is specified for processing. Bypassing the config."
      logEntityJourneyEvent(args(0), currentDataZone, zoneSubStep = "driver", logMessage)
      Array(args(0)).toList
    } else {
      applicationConfig.getConfiguredEntities
    }
  }


  /**
   * This method is used to process data in the zone.
   *
   * @param entityName      The name of the entity being processed
   * @param controlFilePath The path to the control file
   * @param appName         The name of the application being run
   * @param auditTable      The audit table repository to audit entries
   * @return DataFrame
   */
  def tableRunner(entityName: String, controlFilePath: String, appName: String, auditTable: AuditTableRepository): DataFrame = ???

  /**
   * This method is used to get the application constants.
   *
   * @return ApplicationConstants
   */
  protected def getApplicationConstants: ApplicationConstants = {
    new ApplicationConstantsImpl(appName)
  }

  /**
   * This method is used to get the application configuration.
   *
   * @param applicationConstants The application constants object
   * @return ApplicationConfig
   */
  protected def getApplicationConfig(applicationConstants: ApplicationConstants): ApplicationConfig = {
    new ApplicationConfig(applicationConstants)
  }

  protected def getTableConfig(controlFilePath: String, appName: String, entityName: String): TableConfig = {
    val tableCfg = new TableConfig()
    tableCfg.loadConfig(controlFilePath, appName, entityName)
    tableCfg
  }

  protected def getDbConfig(controlFilePath: String, appName: String, entityName: String): RDBMSConfig = {
    val dbConfig = new RDBMSConfig()
    dbConfig.loadConfig(controlFilePath, appName, entityName)
    dbConfig
  }

  //Spark Session Level Variables/Functions
  /** Creates Local Spark Session with default settings */
  def createSparkSession: SparkSession = {
    lazy val clusterCfg = if (SS.isLocalEnv) Some("local[2]") else None
    lazy val sparkSession: SparkSession = getSparkSession(appName, clusterCfg)
    sparkSession.conf.set("spark.sql.parquet.int96RebaseModeInRead", "CORRECTED")
    sparkSession.conf.set("spark.sql.parquet.int96RebaseModeInWrite", "CORRECTED")
    sparkSession.conf.set("spark.sql.parquet.datetimeRebaseModeInRead", "CORRECTED")
    sparkSession.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
    sparkSession
  }
  /**
   * This method is used get the environment configuration.
   *
   * @return EnvironmentConfig
   */
  protected def getEnvironmentConfig(applicationConstants: ApplicationConstants): EnvironmentConfig = {
    new EnvironmentConfig(applicationConstants)
  }

  /**
   * This method is used to get the application name from the arguments.
   *
   * @return String
   */
  def getAppNameFromArgs: String

  /**
   * This method is used to get the data zone.
   *
   * @return DataZone
   */
  protected def getDataZone: DataZone
}
