package com.tccc.dna.datazones.utils

import com.tccc.dna.datazones.init.{ApplicationConstants, RDBMSConfig, TableConfig}
import com.tccc.dna.synapse.Logging
import org.apache.spark.sql.DataFrame

import java.sql.{Connection, DriverManager}

object DbUtils extends Logging {

  //todo develop local implementation
  def turncateTable(tableConfig: TableConfig,dbConfig: RDBMSConfig): Unit = {
    val dbKey = tableConfig.getDbKey
    var connection: Connection = null
    try {
      Class.forName(dbConfig.getDbJdbcDriver(dbKey))
      connection = DriverManager.getConnection(dbConfig.getDbUrl(dbKey), dbConfig.getDbUserName(dbKey), dbConfig.getDbUserPassword(dbKey))
       val statement = connection.createStatement()
      val truncateSql = s"TRUNCATE TABLE ${tableConfig.getDbCertifiedQualifiedTableName}"
      statement.execute(truncateSql)

      logInfo(s"Table ${tableConfig.getDbCertifiedQualifiedTableName} truncated successfully.")
    } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      if (connection != null) {
        connection.close()
      }
    }
  }

  //todo develop local implementation
  def insertDataFrame(dbUrl:String,df:DataFrame,dbOptions: Map[String,String],tableName: String):DataFrame = {
    val applicationContants = new ApplicationConstants
    df.write
      .format(applicationContants.jdbc)
      .options(dbOptions)
      .option(applicationContants.dbtable, tableName)
      .mode(applicationContants.append)
      .save()
    df
  }

}
