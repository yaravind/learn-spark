package com.tccc.dna.datazones.refined

import com.tccc.dna.datazones.utils.{DataZoneUtilImpl, DeltaFile, MetadataOperations}
import com.tccc.dna.datazones.validators.GenericValidator
import com.tccc.dna.synapse.spark.{DataFrames, Writers, SynapseSpark => SS}
import com.tccc.dna.synapse.{DataZone, Logging, StorageFormat}
import io.delta.tables.DeltaTable
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{DataFrame, SaveMode}

/**
 * RefinedZoneTemplate is the template for refined zone.
 *
 * @param refinedZoneProfile Instance of [[RefinedZoneProfile]].
 */
class RefinedZoneTemplate(val refinedZoneProfile: RefinedZoneProfile
                         ) extends Logging {
  private val RelativeDataPath = "data/"

  protected val BaseValidDataPath: String = refinedZoneProfile.rawFullPath + refinedZoneProfile.tableCfg.getValidDataFullPath

  protected val FinalRawPath: String = BaseValidDataPath + RelativeDataPath
  protected val RefinedPath: String = refinedZoneProfile.refinedFullPath
  protected val FinalRefinedTablePath: String = RefinedPath + "/tbl_final"
  val PartitionCols: Option[Array[String]] = Some(
    Array("audit_submission_date_hr_min")
  )
  protected val ConformedTblPath: String = RefinedPath + "tbl_conformed"
  var logMessage = ""

  /**
   * Execute the refined zone.
   *
   * @return DataFrame
   */
  def execute(): DataFrame = {
    logMessage = s"Running refined zone for entity [${refinedZoneProfile.entityName}]. Base Path [$FinalRawPath]"
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "start refined", logMessage)
    logMessage = s"Entity format: JSON"
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "start refined", logMessage)

    var finalDf = SS.getActiveSession.emptyDataFrame
    val tableUnionDf = loadData(FinalRawPath)
    logMessage = s"Data count after reading from raw zone: " + tableUnionDf.count()
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "load raw data", logMessage)
    refinedZoneProfile.auditTableRepository.insertEntityJourneyAuditEntry(tableUnionDf, SS.getCurrentSparkAppName, DataZone.RefinedZone.toString,
      "RefinedZoneDataLoad", refinedZoneProfile.entityName,  PartitionCols.get(0), "Start", "DailyRefresh", FinalRawPath)


    val conformedDf = postProcessEntity(tableUnionDf)
    logMessage = s"Conformed df after post process entity: "
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "post process refined", logMessage)
    conformedDf.show(5, false)
    logMessage = s"5. Save: Start"
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "write refined data", logMessage)

    val writeMode: String = refinedZoneProfile.tableCfg.getRefinedModeOfWrite
    logMessage = s"Write mode: $writeMode"
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "write refined data", logMessage)
    logMessage = s"Saving final table to: $FinalRefinedTablePath"
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "write refined data", logMessage)
    writeToRefinedZone(conformedDf, writeMode, FinalRefinedTablePath)
    logMessage = s"Dataframe count in refined zone for current run: " + conformedDf.count()
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "write refined data", logMessage)
    logMessage = s"5. Save: End"
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "write refined data", logMessage)
    refinedZoneProfile.auditTableRepository.insertEntityJourneyAuditEntry(conformedDf, SS.getCurrentSparkAppName, DataZone.RefinedZone.toString,
      "RefinedZoneDataLoad", refinedZoneProfile.entityName , PartitionCols.get(0), "Processed", "DailyRefresh", FinalRefinedTablePath)

    logMessage = s"*** Read after $writeMode from $FinalRefinedTablePath"
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "end refined", logMessage)
    val outputDf = DeltaFile.readFile(FinalRefinedTablePath)
    logMessage = s"output count: ${outputDf.count()}"
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "end refined", logMessage)
    outputDf.show(5, false)

    logMessage = s"***** Refined Zone for ${refinedZoneProfile.entityName}: End"
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "end refined", logMessage)
    conformedDf
  }

  /**
   * Load data for the refined zone from raw zone.
   *
   * @param FinalRawPath Path to the final raw data.
   * @return DataFrame
   */
  def loadData(FinalRawPath: String): DataFrame = {
    logMessage = s"Read data from $FinalRawPath: START"
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "load raw data", logMessage)
    var refinedDf = SS.getActiveSession.emptyDataFrame
    if (refinedZoneProfile.tableCfg.getRawFileFormat == "json") {
      refinedDf = DataZoneUtilImpl.getDataFrameFromUriWithFilters(
        FinalRawPath,
        StorageFormat.JSON,
        DataZoneUtilImpl.getFinalRefinedTableSchema(refinedZoneProfile.entityName),
        DataZoneUtilImpl.getFinalWriteOptions(refinedZoneProfile.entityName),
        refinedZoneProfile.filterCondition,
      )
      logMessage = s"dataframe count: ${refinedDf.count()}"
      logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "load raw data", logMessage)
      refinedDf.show(5, false)
      logMessage = s"Read data from $FinalRawPath: End"
      logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "load raw data", logMessage)

    }else if(refinedZoneProfile.tableCfg.getRawFileFormat == "parquet"){
      refinedDf = DataZoneUtilImpl.getDataFrameFromUriWithFilters(
        FinalRawPath,
        StorageFormat.Parquet,
        GenericValidator.getSchemaWithMetadata(refinedZoneProfile.tableCfg),
        GenericValidator.getRawWriteOptions(tableConfig = refinedZoneProfile.tableCfg),
        refinedZoneProfile.filterCondition
      )
    }
    else {
      refinedDf = DataZoneUtilImpl.getDataFrameFromUriWithFilters(
        BaseValidDataPath,
        StorageFormat.Csv,
        DataZoneUtilImpl.getFinalRawTableSchema(refinedZoneProfile.entityName),
        DataZoneUtilImpl.getFinalWriteOptions(refinedZoneProfile.entityName),
        refinedZoneProfile.filterCondition,
        addInputFilePath = false
      )
      logMessage = s"dataframe count: ${refinedDf.count()}"
      logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "load raw data", logMessage)
      refinedDf.show(5, false)
      logMessage = s"Read data from $FinalRawPath: End"
      logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "load raw data", logMessage)

    }
    return refinedDf
  }


  /**
   * The default implementation of post-processing involves adding following metadata.
   * @note Subclasses overriding this method should make sure to call this method using super.postProcessEntity to preserve this behavior.
   *
   * @param df Dataframe of the entity with data from the raw zone
   * @return Returns a dataframe with metadata columns added
   */
  def postProcessEntity(df: DataFrame): DataFrame = {
    logMessage = s"Adding audit_submission_date, crt_hr, audit_pipeline_run_id, audit_activity_run_id, file_name, file_path"
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "post process refined", logMessage)

    var enrichedDf =
      MetadataOperations.addMetadataColumns(df, SS.getUserUUID)
    enrichedDf = DataFrames.addPipelineRunId((enrichedDf))
    enrichedDf = DataFrames.addActivityRunId(enrichedDf)
    val refinedColumnNames = refinedZoneProfile.tableCfg.getColumns.filter(col("columns_refinedColumnName") =!= "").select("columns_refinedColumnName").collect
      .map(_.getString(0))
    enrichedDf = enrichedDf.toDF(refinedColumnNames: _*)
    enrichedDf
  }

  /**
   * Write the final DataFrame to the refined zone.
   *
   * @param conformedDf      DataFrame
   * @param writeMode        Write mode
   * @param finalRefinedPath Path to the final refined data.
   */
  protected def writeToRefinedZone(
                          conformedDf: DataFrame,
                          writeMode: String,
                          finalRefinedPath: String
                        ): Unit = {
    //TODO remove it later
    conformedDf.show(10, false)
    //TODO modified SS.getCurrentUserName to BatchUser. Change it later
    val userName = SS.getUserUUID
    if (DeltaTable.isDeltaTable(FinalRefinedTablePath)) {
      if (writeMode == "upsert") {
        val keyColumns = refinedZoneProfile.tableCfg.getRefinedKeyCols
        Writers.upsert(
          finalRefinedPath,
          conformedDf,
          keyColumns,
          partitionPruneCols = PartitionCols.get.toList,
          insertExcludeCols = List("audit_upd_ts", "audit_upd_usr", "audit_crt_ts", "audit_crt_usr"),
          updateExcludeCols = List("audit_crt_ts", "audit_crt_usr", "audit_upd_ts", "audit_upd_usr"),
          customInsertExpr =
            Map("audit_crt_ts" -> "current_timestamp()", "audit_crt_usr" -> s"'$userName'"),
          customUpdateExpr =
            Map("audit_upd_ts" -> "current_timestamp()", "audit_upd_usr" -> s"'$userName'")
        )
      } else if (writeMode == "deleteAndInsert") {
        val mergeOnCols = refinedZoneProfile.tableCfg.getRefinedOnColumn
        DeltaFile.deleteAndInsert(
          finalRefinedPath,
          conformedDf,
          partitionPruneCols = PartitionCols.get.toList,
          mergeOnCols = mergeOnCols,
          insertExcludeCols = List("audit_upd_ts", "audit_upd_usr", "audit_crt_ts", "audit_crt_usr"),
          customInsertExpr =
            Map("audit_crt_ts" -> "current_timestamp()", "audit_crt_usr" -> s"'$userName'")
        )
      } else if (writeMode == "append") {
        Writers.writeAsDelta(
          conformedDf,
          force = true,
          saveToPath = finalRefinedPath,
          saveMode = SaveMode.Append,
          partitionColNames = PartitionCols
        )
      } else {
        Writers.writeAsDelta(
          conformedDf,
          force = true,
          saveToPath = finalRefinedPath,
          saveMode = SaveMode.Overwrite,
          partitionColNames = PartitionCols
        )
      }
    } else {
      //      logInfo("5.1 Delta table not found. Creating new delta table.")
      logMessage = s"5.1 Delta table not found. Creating new delta table."
      logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "write refined data", logMessage)

      Writers.writeAsDelta(
        conformedDf,
        force = true,
        saveToPath = finalRefinedPath,
        saveMode = SaveMode.Append,
        partitionColNames = PartitionCols
      )
    }
  }
}
