package com.tccc.dna.datazones.certified

import com.tccc.dna.datazones.init.{ApplicationConfig, TableConfig}
import com.tccc.dna.datazones.utils.AuditTableRepository
import com.tccc.dna.synapse.{DataZone, Logging}

class CertifiedZoneProfileRepositoryImpl(val appName: String, applicationConfig: ApplicationConfig, auditTableRepository: AuditTableRepository) extends CertifiedZoneProfileRepository with Logging{


  /**
   * Getter method for the Certified Zone Profile
   *
   * @param entityName      Name of the entity this method will run for.
   * @param tableConfig     The configuration details of the entity being run
   * @param filterCondition Map of the filter conditions used on the dataframe if applicable
   * @example
   *          partition_column               |  partition_value
   *          audit_submission_date_hr_min   |  2024-04-30_16_53
   * @return Return the certified zone profile.
   *
   */
  def getCertifiedZoneProfile(entityName: String, tableConfig: TableConfig, filterCondition: Map[String, Array[String]]): CertifiedZoneProfile = {

    logEntityJourneyEvent(entityName, DataZone.CertifiedZone, "", s"Create Certified Profile for $entityName.")

    val baseCertifiedPath = applicationConfig.getFullCertifiedPath
    val baseRefinedPath = applicationConfig.getFullRefinedPath
    CertifiedZoneProfile(
      entityName = entityName,
      controlFilePath = applicationConfig.getFullConfigPath,
      refinedFullPath = baseRefinedPath + tableConfig.getRefinedPath,
      certifiedFullPath = baseCertifiedPath + tableConfig.getCertifiedPath,
      filterCondition = filterCondition,
      tableCfg = tableConfig,
      auditTableRepository = auditTableRepository
    )
  }
}
