package com.tccc.dna.datazones.validators

import com.amazon.deequ.checks.{Check, CheckLevel, CheckWithLastConstraintFilterable}
import com.tccc.dna.datazones.init.TableConfig
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types._

/**
 * Generic Validator for all the entities.
 */
class ValidatorChecks {

  val isFileNameValidCheck: CheckWithLastConstraintFilterable = Check(CheckLevel.Error, "isFileNameValid")
    .hasPattern(
      "name",
      """(asset-(created|moved|published|removed)|versioned)-\d{8}\d{6}\.json""".r,
      name = Some("isFileNameValid"),
      hint =
        Some("File name do not follow asset-*-yyyyMMddHHmmss.json pattern.")
    )

  private lazy val assetCreatedNullCols: Seq[String] = Seq(
    "asset_id",
    "asset_name",
    "asset_title",
    "event_created_by",
    "asset_creation_timestamp",
    "original_asset_path",
    "event_type",
    "asset_size",
    //    "mime_type",
    "event_creation_timestamp",
    "new_asset_path"
  )

  val isAssetCreatedCompletenessChecks: Check =
    assetCreatedNullCols.foldLeft(Check(CheckLevel.Error, "Completeness")) {
      (check, col) => check.isComplete(col)
    }

  val isAssetIdUniqueCheck: CheckWithLastConstraintFilterable = Check(CheckLevel.Error, "isAssetIdUnique")

    .hasUniqueness(Seq("asset_id", "audit_file_path"), Check.IsOne)

  val isAssetCreatedByEmailTypeCheck: CheckWithLastConstraintFilterable =
    Check(CheckLevel.Error, "isAssetCreatedByEmailTypeCheck")
      .containsEmail(
        "asset_created_by",
        hint = Some("asset_created_by is in invalid email format.")
      )

  val isAssetIdValidUUIDCheck: CheckWithLastConstraintFilterable =
    Check(CheckLevel.Error, "isAssetIdValidUUIDCheck")
      .isComplete("asset_id")
      .satisfies(
        "asset_id rlike '[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'",
        constraintName = "containsUUID(asset_id)",
        hint = Some("asset_id is invalid UUID.")
      )


  /**
   * Get the landing read options from the json configuration.
   *
   * @param tableConfig TableConfig object.
   * @return Map[String, String]
   */
  def getLandingReadOptions(tableConfig: TableConfig): Map[String, String] = {
    val landingOptionDf = tableConfig.getLandingReadOptions
    var landingReadOptions = Map[String, String]()
    for (column <- landingOptionDf.columns) {
      val columnName = column.split("_")(1)
      landingReadOptions = landingReadOptions + (columnName -> landingOptionDf.select(column).collect().map(_.getString(0)).mkString(""))
    }
    landingReadOptions
  }

  /**
   * Get the raw write options from the json configuration.
   *
   * @param tableConfig TableConfig object.
   * @return Map[String, String]
   */
  def getRawWriteOptions(tableConfig: TableConfig): Map[String, String] = {
    val rawWriteOptionDf = tableConfig.getRawWriteOptions
    var rawWriteOptions = Map[String, String]()
    for (column <- rawWriteOptionDf.columns) {
      val columnName = column.split("_")(1)
      rawWriteOptions = rawWriteOptions + (columnName -> rawWriteOptionDf.select(column).collect().map(_.getString(0)).mkString(""))
    }
    rawWriteOptions
  }


  /**
   * Get the schema from the json configuration.
   *
   * @param tableCfg TableConfig object.
   * @return StructType
   */
  def getSchemaFromJsonConfiguration(
                                      tableCfg: TableConfig
                                    ): StructType = {
    val tableMetaData = tableCfg.getColumns
    val columnNames = tableMetaData
      .filter(col("columns_rawColumnName") =!= "")
      .collect()
      .map(row => row.getString(row.fieldIndex("columns_rawColumnName")))
    val columnDataTypes = tableMetaData
      .filter(col("columns_rawColumnName") =!= "")
      .collect()
      .map(row => row.getString(row.fieldIndex("columns_ssdpColumnDataType")))
    var i = 0
    val structFieldList = new Array[StructField](columnNames.length)
    val dataTypeMap = Map(
      "String" -> StringType,
      "Integer" -> IntegerType,
      "Byte" -> ByteType,
      "Decimal" -> DecimalType(24, 12),
      "Long" -> LongType,
      "Short" -> ShortType,
      "TimeStamp" -> TimestampType,
      "Date" -> TimestampType
    )
    for ((columnName, ssdpDataType) <- columnNames.zip(columnDataTypes)) {
      structFieldList(i) =
        StructField(columnName, dataTypeMap(s"$ssdpDataType"), true)
      i += 1
    }

    val schemaList = StructType(structFieldList)
    schemaList
  }

  /**
   * Get the schema with metadata.
   *
   * @param tableConfig TableConfig object.
   * @return StructType
   */
  def getSchemaWithMetadata(tableConfig: TableConfig): StructType = {
    var schema = getSchemaFromJsonConfiguration(tableConfig)
    schema = schema
      .add("audit_file_path", StringType)
      .add("audit_file_name", StringType)
      .add("audit_crt_ts", TimestampType)
      .add("audit_crt_usr", StringType)
      .add("audit_upd_ts", TimestampType)
      .add("audit_upd_usr", StringType)
      .add("audit_pipeline_run_id", StringType)
      .add("audit_activity_run_id", StringType)
      .add("audit_submission_date_hr_min", StringType)
    schema

  }
}
