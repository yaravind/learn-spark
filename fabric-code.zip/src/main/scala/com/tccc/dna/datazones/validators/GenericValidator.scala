package com.tccc.dna.datazones.validators

/**
 * Generic Validator for all the data zones.
 */
object GenericValidator extends ValidatorChecks {

}
