package com.tccc.dna.datazones.certified

import com.tccc.dna.datazones.init.TableConfig

/**
 * Repository trait for the certified zone profile
 *
 */
abstract class CertifiedZoneProfileRepository {

  /**
   * Defintion for getting the Certified Zone Profile
   *
   * @param entityName      Name of the entity this method will run for.
   * @param tableConfig     The configuration details of the entity being run
   * @param filterCondition Map of the filter conditions used on the dataframe if applicable
   * @example Map(audit_submission_date_hr_min -> [Ljava.lang.String;@475d1ad7)
   *
   * @return Return the certified zone profile. Or it would if it did anything.
   *
   */
  def getCertifiedZoneProfile(entityName: String, tableConfig: TableConfig, filterCondition: Map[String, Array[String]]): CertifiedZoneProfile
}
