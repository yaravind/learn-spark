package com.tccc.dna.datazones.validators

import com.tccc.dna.synapse.StorageFormat
import com.tccc.dna.synapse.spark.DataFrames
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.StructType

/**
 * A DataLoader implementation for loading TSV data.
 *
 * @param entitySchema Optional entity schema as a StructType.
 * @param readOptions  Read options for loading TSV data.
 * @param cacheDf      Flag indicating whether to cache the DataFrame after loading.
 */
class TsvDataLoader(entitySchema: Option[StructType], readOptions: Map[String, String], cacheDf: Boolean = false)
  extends DataLoader(None, entitySchema, StorageFormat.Tsv, readOptions, cacheDf) {

  /**
   * Loads TSV data into a DataFrame and performs necessary transformations.
   *
   * @param inputDf The input DataFrame containing TSV data to be loaded and processed.
   * @return The processed DataFrame after loading and transformations.
   */
  override def load(inputDf: DataFrame): DataFrame = {
    val validFiles = inputDf.select("validFileSetPath").collect().map(_.getString(0))
    logInfo(s"Total files for semantic validation: ${validFiles.length}")
    logInfo(s"Files:")
    validFiles.foreach(file => logInfo(file))

    val readOptions = getLandingReadOptions

    val finalDf = entitySchema match {
      case None =>
        val df = DataFrames.getDataFrameFromUris(StorageFormat.Tsv, null, readOptions = readOptions, addInputFilePath = true, validFiles)
        df
      case _ =>
        val df = DataFrames.getDataFrameFromUris(StorageFormat.Tsv, entitySchema.get, readOptions = readOptions, addInputFilePath = true, validFiles)
        df
    }

    if (cacheDf) {
      logInfo(s"Caching enabled (cacheDf = true). Calling df.cache() on the resulting DataFrame.")
      finalDf.cache()
    }
    logInfo(s"File row count: ${finalDf.count()}")
    finalDf
  }

  //Read Options Can be Overloaded to add different options.
  def getLandingReadOptions : Map[String, String] ={
    Map("header" -> "false", "delimiter" -> "\t", "quote" -> "\"")
  }

}

