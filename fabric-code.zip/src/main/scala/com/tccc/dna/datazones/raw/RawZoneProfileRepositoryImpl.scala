package com.tccc.dna.datazones.raw

import com.tccc.dna.datazones.init.{ApplicationConfig, TableConfig}
import com.tccc.dna.datazones.utils.AuditTableRepository
import com.tccc.dna.datazones.validators._
import com.tccc.dna.synapse.{DataZone, Logging, StorageFormat}
import org.apache.spark.sql.types.StructType

class RawZoneProfileRepositoryImpl(
                                    val appName: String,
                                    val currentRunStartHourAndMinute: String,
                                    val currentRunStartDateTime: String,
                                    val applicationConfig: ApplicationConfig,
                                    val tableConfig: TableConfig,
                                    val auditTableRepository: AuditTableRepository
                                  ) extends RawZoneProfileRepository with Logging {

  private var logMessage = ""
  override def getRawZoneProfile(entityName: String, tableConfig2: TableConfig): RawZoneProfile = {
    logMessage = s"Create Raw Profile for $entityName."
    logEntityJourneyEvent(entityName, DataZone.RawZone, zoneSubStep = "Raw zone profile", logMessage)

    val baseRawPath = applicationConfig.getFullRawPath

    val landingPath = if(applicationConfig.environment == "testEnvironment") {
      applicationConfig.testBasePath + applicationConfig.getLandingZonePath + tableConfig.getLandingZonePath + tableConfig.getDropZoneEntityName
    }else{
      applicationConfig.getLandingZonePath + tableConfig.getLandingZonePath + tableConfig.getDropZoneEntityName
    }

    RawZoneProfile(
      LandingZoneProfile(
        Left(landingPath),
        getEntityFormat(entityName),
        Map.empty
      ),
      entityName,
      tableConfig.getDataValidationLevel.toBoolean,
      controlFilePath = applicationConfig.getFullConfigPath,
      baseRawPath + tableConfig.getArchiveFullPath,
      baseRawPath + tableConfig.getRawFullPath,
      baseRawPath + tableConfig.getValidFileSetFullPath,
      baseRawPath + tableConfig.getInvalidFileSetFullPath,
      baseRawPath + tableConfig.getInvalidDataErrorFullPath,
      baseRawPath + tableConfig.getInvalidDataFileRejectFullPath,
      baseRawPath + tableConfig.getValidDataFullPath,
      baseRawPath + tableConfig.getValidDataAdditionalColumnsFullPath,
      currentRunStartHourAndMinute,
      currentRunStartDateTime,
      tableConfig,
      auditTableRepository
    )
  }

  override def getRawStructuralValidator(entityName: String): StructuralValidator = {
    val rawStructuralValidator = new DeequBackedStructuralValidator()

    if (tableConfig.getStructuralValidatorIsFileSizeGreaterThanZero) {
      rawStructuralValidator.addCheck(
        PredefinedStructuralValidators.isFileSizeGreaterThanZero
      )
    }
    if (tableConfig.getStructuralValidatorIsFileNameValidCheck) {
      rawStructuralValidator.addCheck(
        GenericValidator.isFileNameValidCheck
      )
    }
    if (tableConfig.getStructuralValidatorIsFileNameSuffixValidDateTime) {
      rawStructuralValidator.addCheck(
        PredefinedStructuralValidators.isFileNameSuffixValidDateTime
      )
    }
    rawStructuralValidator
  }

  override def getRawSemanticValidator(entityName: String): SemanticValidator = {

    var rawSemanticValidator: DeequBackedSemanticValidator = new DeequBackedSemanticValidator()

    getEntityFormat(entityName) match {

      case StorageFormat.JSON =>
        rawSemanticValidator = new JsonSemanticValidator(
          cacheDf = true
        )
      case StorageFormat.Csv =>
        rawSemanticValidator = new CsvSemanticValidator(cacheDf = true)
      case StorageFormat.Parquet =>
        rawSemanticValidator = new ParquetSemanticValidator(cacheDf = true)
    }
    if (tableConfig.getSemanticValidatorIsAssetIdValidUUIDCheck) {
      rawSemanticValidator.addCheck(GenericValidator.isAssetIdUniqueCheck)
    }

    if (tableConfig.getSemanticValidatorIsAssetCreatedCompletenessCheck) {
      rawSemanticValidator.addCheck(GenericValidator.isAssetCreatedCompletenessChecks)
    }

    if (tableConfig.getSemanticValidatorIsAssetIdUniqueCheck) {
      rawSemanticValidator.addCheck(GenericValidator.isAssetIdValidUUIDCheck)
    }

    if (tableConfig.getSemanticValidatorIsAssetCreatedByEmailTypeCheck) {
      rawSemanticValidator.addCheck(GenericValidator.isAssetCreatedByEmailTypeCheck)
    }

    rawSemanticValidator

  }

  override def getEntitySchema(entityName: String, entityFormat: StorageFormat, tableConfig: TableConfig): Option[StructType] = {
    Some(GenericValidator.getSchemaFromJsonConfiguration(tableConfig))
  }

  override def getCsvLandingOptions(entityName: String): Map[String, String] = {
    GenericValidator.getLandingReadOptions(tableConfig)
  }

  override def getTsvLandingOptions(entityName: String): Map[String, String] = {
    GenericValidator.getLandingReadOptions(tableConfig)
  }

  def getJsonLandingOptions(entityName: String): Map[String, String] = {
    GenericValidator.getLandingReadOptions(tableConfig)
  }

  override def getParquetLandingOptions(entityName: String): Map[String, String] ={
    GenericValidator.getLandingReadOptions(tableConfig)
  }


  /**
   * Return the storage format of the entity. This is used to select appropriate reader from Spark while reading the data.
   *
   * @param entityName Name of the entity.
   * @return Given the name of the entity, returns the format as enum. One of the constants defined in [[StorageFormat]].
   */
  override def getEntityFormat(entityName: String): StorageFormat = {
    tableConfig.getRawFileFormat match {
      case "csv" => StorageFormat.Csv
      case "json" => StorageFormat.JSON
      case "tsv" => StorageFormat.Tsv
      case "parquet" => StorageFormat.Parquet
    }

  }

}
