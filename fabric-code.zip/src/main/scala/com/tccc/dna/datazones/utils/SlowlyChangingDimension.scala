package com.tccc.dna.datazones.utils

import com.tccc.dna.synapse.spark.SynapseSpark
import io.delta.tables.DeltaTable
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._


//TODO Write scala doc for SCD2 class
//TODO Can we combine addscd2 functions to a single function instead of 2 in SCD class ?
class SlowlyChangingDimension() {
  def addSCD2ColumnsWithCustomExpression(df: DataFrame, customExpressionForStartDate: String): DataFrame = {

    var finalDf = df
    finalDf = finalDf.withColumn("effective_start_date", expr(customExpressionForStartDate))
    finalDf = finalDf.withColumn("effective_end_date", to_date(lit("9999-12-31")))
      .withColumn("is_current", lit("y"))
    finalDf
  }

  def addSCD2Columns(df: DataFrame, createdAtColumnName: String, updatedAtColumnName: String): DataFrame = {
    var finalDf = df
    finalDf = finalDf.withColumn("effective_start_date", to_date(when(col(updatedAtColumnName).isNotNull, col(updatedAtColumnName)).otherwise(col(createdAtColumnName))))
    finalDf = finalDf.withColumn("effective_end_date", to_date(lit("9999-12-31")))
      .withColumn("is_current", lit("y"))
    finalDf
  }

  def slowlyChangingDimensionTwo(targetPath: String,
                                 sourceDf: DataFrame,
                                 joinCols: List[String],
                                 scdColumnList: List[String],
                                 partitionPruneCols: List[String] = List(),
                                 insertExcludeCols: List[String] = List(),
                                 updateExcludeCols: List[String] = List(),
                                 customInsertExpr: Map[String, String] = Map(),
                                 customUpdateExpr: Map[String, String] = Map()): Unit = {
    println(
      s"targetPath: $targetPath, mergeOnCols: [${joinCols.mkString(", ")}], partitionPruneCols: [${
        partitionPruneCols
          .mkString(", ")
      }]"
    )
    println(s"insertExcludeCols: [${insertExcludeCols.mkString(", ")}]")
    println(s"updateExcludeCols: [${updateExcludeCols.mkString(", ")}]")
    println(s"customInsertExpr:  [${customInsertExpr.mkString(", ")}]")
    println(s"customUpdateExpr:  [${customUpdateExpr.mkString(", ")}]")

    val targetTable =
      DeltaTable.forPath(SynapseSpark.getActiveSession, targetPath)
    val targetDf = targetTable.toDF

    println(
      s"Target table cols (${targetDf.columns.length})    : ${targetDf.columns.mkString(", ")}"
    )
    println(
      s"Source Dataframe cols (${sourceDf.columns.length}): ${sourceDf.columns.mkString(", ")}"
    )
    val mergeCols = sourceDf.columns
      .map(colName => (s"target.$colName", s"sources.$colName"))
      .toMap
    mergeCols.foreach(println)

    //    Insert Expression
    val tempInsertExpr = mergeCols.filterKeys(col => {
      val lookup = col.replace("target.", "")
      !insertExcludeCols.contains(lookup)
    })
    val finalInsertExpr = tempInsertExpr ++ customInsertExpr
    println(
      "Filtered cols from insertExpr: " + mergeCols.keySet
        .diff(finalInsertExpr.keySet)
    )
    println(finalInsertExpr)

    //Update Expression
    val finalUpdateExpr = Map(s"effective_end_date" -> s"sources.effective_start_date", "is_current" -> "'n'") ++
      customUpdateExpr

    val whereCondition = s"target.effective_end_date == '9999-12-31' AND target.is_current == 'y' AND " + scdColumnList.map(col =>
      s"sources.${col} <> target.${col}")
      .mkString(" AND ")
    println(whereCondition)

    val newRowsToInsert = sourceDf
      .as("sources")
      .join(targetDf.as("target"), joinCols)
      .select("sources.*")
      .where(whereCondition)

    newRowsToInsert.show(10, false)

    val stagedUpdates = newRowsToInsert
      .selectExpr("NULL as mergeKey", "*")
      .union(
        sourceDf.selectExpr(s"concat(${joinCols.mkString(",")}) as mergeKey", "*")
      )
    stagedUpdates.show(10, false)
    //
    targetTable
      .as("target")
      .merge(
        stagedUpdates.as("sources"),
        s"""concat(${joinCols.map(col => s"target.${col}").mkString(",")}) = mergeKey""")
      .whenMatched(whereCondition)
      .updateExpr(finalUpdateExpr)
      .whenNotMatched()
      .insertExpr(finalInsertExpr)
      .execute()
  }



}
