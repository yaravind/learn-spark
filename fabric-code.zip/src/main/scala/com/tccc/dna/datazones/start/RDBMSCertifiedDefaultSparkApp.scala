package com.tccc.dna.datazones.start

/**
 * Class extends AllZoneSparkBaseApp and is used to process data in the RDBMSCertified zone.
 * @see todo create and add wiki page
 */

import com.tccc.dna.datazones.certified.rdbms.{RDBMSCertifiedZoneProfile, RDBMSCertifiedZoneProfileRepository, RDBMSCertifiedZoneProfileRepositoryImpl, RDBMSCertifiedZoneTemplate}
import com.tccc.dna.datazones.init.ApplicationConfig
import com.tccc.dna.datazones.utils.AuditTableRepository
import com.tccc.dna.synapse.spark.{SynapseSpark => SS}
import org.apache.spark.sql.DataFrame


abstract class RDBMSCertifiedDefaultSparkApp extends AllZoneSparkBaseApp {
  /**
   * Method returns default RDBMS Certified Zone Profile Repository.
   * @note Subclasses overriding this method should make sure to call this method using super.getRdbmsCertifiedZoneProfileRepository to preserve this behavior.
   * @param appName Application Name
   * @param applicationConfig Application Configuration Object
   * @return RDBMSCertifiedZoneProfileRepository
   */
  protected def getRdbmsCertifiedZoneProfileRepository(appName: String, applicationConfig: ApplicationConfig): RDBMSCertifiedZoneProfileRepository = {
    new RDBMSCertifiedZoneProfileRepositoryImpl(appName, applicationConfig)
  }

  /**
   * Method returns default RDBMSCertifiedZoneProfile
   * @note Subclasses overriding this method should make sure to call this method using super.getRdbmsCertifiedZoneProfile to preserve this behavior.
   *
   * @param entityName Entity to be processed
   * @param filterCondition Data partition to be processed
   * @return
   */
  protected def getRdbmsCertifiedZoneProfile(entityName: String, filterCondition: Map[String, Array[String]]): RDBMSCertifiedZoneProfile = {
    getRdbmsCertifiedZoneProfileRepository(appName, applicationConfig).getRdbmsCertifiedZoneProfile(entityName, filterCondition)
  }

  /**
   * Method returns default RDBMSCertifiedZoneTemplate Implementation
   * @note Subclasses overriding this method should make sure to call this method using super.getRdbmsCertifiedZoneTemplate to preserve this behavior.
   * @param rdbmsCertifiedZoneProfile RDBMS Certified Profile
   * @return getRdbmsCertifiedZoneTemplate
   */
  protected def getRdbmsCertifiedZoneTemplate(rdbmsCertifiedZoneProfile: RDBMSCertifiedZoneProfile): RDBMSCertifiedZoneTemplate = {
    new RDBMSCertifiedZoneTemplate(rdbmsCertifiedZoneProfile)
  }

  override  def tableRunner(entityName: String, controlFilePath: String, appName: String, auditTable: AuditTableRepository): DataFrame = {

    //todo implement filter logic for DB Zone
    var filterCondition: Map[String, Array[String]] = Map.empty

    var rdbmsCertifiedDf = SS.getActiveSession.emptyDataFrame

    val rdbmsCertifiedZoneProfile = getRdbmsCertifiedZoneProfile(entityName, filterCondition)

    val rdbmsCertifiedZone = getRdbmsCertifiedZoneTemplate(rdbmsCertifiedZoneProfile)
    rdbmsCertifiedDf = rdbmsCertifiedZone.execute()

    rdbmsCertifiedDf
  }
}
