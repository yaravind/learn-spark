package com.tccc.dna.datazones.validators

import com.tccc.dna.synapse.StorageFormat
import com.tccc.dna.synapse.spark.DataFrames
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.StructType

/**
 * A DataLoader implementation for loading CSV data.
 *
 * @param entitySchema Optional entity schema as a StructType.
 * @param readOptions  Read options for loading CSV data.
 * @param cacheDf      Flag indicating whether to cache the DataFrame after loading.
 */
class CsvDataLoader(entitySchema: Option[StructType], readOptions: Map[String, String], cacheDf: Boolean = false)
  extends DataLoader(None, entitySchema, StorageFormat.Csv, readOptions, cacheDf) {

  /**
   * Loads CSV data into a DataFrame and performs necessary transformations.
   *
   * @param inputDf The input DataFrame containing CSV data to be loaded and processed.
   * @return The processed DataFrame after loading and transformations.
   */
  override def load(inputDf: DataFrame): DataFrame = {
    val validFiles = inputDf.select("validFileSetPath").collect().map(_.getString(0))
    logInfo(s"Total files for semantic validation: ${validFiles.length}")
    validFiles.foreach(file => logInfo(file))


    val finalDf = entitySchema match {
      case None =>
        val df = DataFrames.getDataFrameFromUris(StorageFormat.Csv, null, readOptions = readOptions, addInputFilePath = true, validFiles)
        df
      case _ =>
        val df = DataFrames.getDataFrameFromUris(StorageFormat.Csv, entitySchema.get, readOptions = readOptions, addInputFilePath = true, validFiles)
        df
    }

    if (cacheDf) {
      logInfo(s"Caching is enabled (cacheDf = true). Calling df.cache()")
      finalDf.cache()
    }
    logInfo(s"File row count: ${finalDf.count()}")
    finalDf
  }
}

