package com.tccc.dna.datazones

import org.apache.spark.sql.types._

object Schemas {
  val JsonValidatorSchema: StructType = StructType(
    List(
      StructField("input", StringType, nullable = false),
      StructField("is_valid", BooleanType, nullable = false),
      StructField("error_count", IntegerType, nullable = false),
      StructField("error_list", ArrayType(StringType, containsNull = true), nullable = true)
    )
  )
}