package com.tccc.dna.datazones.validators

import com.tccc.dna.synapse.StorageFormat
import com.tccc.dna.synapse.spark.DataFrames
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.StructType

class ParquetDataLoader(entitySchema: Option[StructType], readOptions: Map[String, String], cacheDf: Boolean = false) extends
DataLoader(None, entitySchema, StorageFormat.Parquet, readOptions, cacheDf){
  /**
   * Loads data into a DataFrame and performs necessary transformations.
   *
   * @param inputDf The input DataFrame to be loaded and processed.
   * @return The processed DataFrame after loading and transformations.
   */
  override def load(inputDf: DataFrame): DataFrame = {
    val validFiles = inputDf.select("validFileSetPath").collect().map(_.getString(0))
    logInfo(s"Total files for semantic validation: ${validFiles.length}")
    validFiles.foreach(file => logInfo(file))


    val finalDf = entitySchema match {
      case None =>
        val df = DataFrames.getDataFrameFromUris(StorageFormat.Parquet, null, readOptions = readOptions, addInputFilePath = true, validFiles)
        df
      case _ =>
        val df = DataFrames.getDataFrameFromUris(StorageFormat.Parquet, entitySchema.get, readOptions = readOptions, addInputFilePath = true, validFiles)
        df
    }

    if (cacheDf) {
      logInfo(s"Caching is enabled (cacheDf = true). Calling df.cache()")
      finalDf.cache()
    }
    logInfo(s"File row count: ${finalDf.count()}")
    finalDf
  }
}
