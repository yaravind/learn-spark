package com.tccc.dna.datazones.start

import com.tccc.dna.datazones.init.{ApplicationConfig, TableConfig}
import com.tccc.dna.datazones.refined.{RefinedZoneImpl, RefinedZoneProfileRepository, RefinedZoneProfileRepositoryImpl}
import com.tccc.dna.datazones.utils.AuditTableRepository
import com.tccc.dna.synapse.DataZone
import com.tccc.dna.synapse.spark.{SynapseSpark => SS}
import org.apache.spark.sql.DataFrame

/**
 * RefinedDefaultSparkApp is a class that extends AllZoneSparkBaseApp and is used to process data in the refined zone.
 * @see https://wiki.coke.com/confluence/pages/viewpage.action?pageId=208256158
 */
abstract class RefinedDefaultSparkApp extends AllZoneSparkBaseApp {
  /**
   * This method is used to process data in the refined zone.
   *
   * @param entityName      The name of the entity being processed
   * @param controlFilePath The path to the control file
   * @param appName         The name of the application being run
   * @param auditTable      The audit table repository to audit entries
   * @return DataFrame
   */
  override def tableRunner(entityName: String, controlFilePath: String, appName: String, auditTable: AuditTableRepository): DataFrame = {
    // create table config
    val tableCfg = new TableConfig()
    tableCfg.loadConfig(controlFilePath, appName, entityName)

    //Create refinedZoneProfileRepository
    val refinedZoneProfileRepository = getRefinedZoneProfileRepository(appName, environmentConfig.currentRunStartHourAndMinute,
      environmentConfig.currentRunStartDateTime, applicationConfig, auditTable)

    //1. Refined
    var filterCondition: Map[String, Array[String]] = auditTable.getNextProcessingPartitionsAsFilter(DataZone.RefinedZone.toString, entityName)

    val refinedZoneProfile = refinedZoneProfileRepository.getRefinedZoneProfile(entityName, tableCfg, filterCondition)
    var refinedDf = SS.getActiveSession.emptyDataFrame

    if (filterCondition.nonEmpty) {
      if (tableCfg.getRefinedModeOfWrite == "overwrite") {
        logMessage = s"filter condition before getting last element:"
        logEntityJourneyEvent(entityName, currentDataZone, zoneSubStep = "runner", logMessage)
        filterCondition.foreach(println)
        filterCondition = Map(filterCondition.last)
        logMessage = s"filter condition after getting last element:"
        logEntityJourneyEvent(entityName, currentDataZone, zoneSubStep = "runner", logMessage)
        filterCondition.foreach(println)
      }
      logMessage = s"Filter condition: ${filterCondition.mkString}"
      logEntityJourneyEvent(entityName, DataZone.RefinedZone, zoneSubStep = "runner", logMessage)
      val refinedZone = new RefinedZoneImpl(
        refinedZoneProfile
      )
      refinedDf = refinedZone.execute()
    }
    else {
      logMessage = "There is no data to process in raw zone."
      logEntityJourneyEvent(entityName, DataZone.RefinedZone, zoneSubStep = "runner", logMessage)
      return refinedDf
    }
    refinedDf.show(truncate = false)

    refinedDf.show(truncate = false)
    refinedDf
  }

  /**
   * This method is used to get the refined zone profile repository.
   *
   * @param appName                      The name of the application being run
   * @param currentRunStartHourAndMinute The current run start hour and minute
   * @param currentRunStartDateTime      The current run start date time
   * @param applicationConfig            The application configuration
   * @return RefinedZoneProfileRepository
   */

  protected def getRefinedZoneProfileRepository(appName: String, currentRunStartHourAndMinute: String, currentRunStartDateTime: String,
                                                applicationConfig: ApplicationConfig, auditTableRepository: AuditTableRepository): RefinedZoneProfileRepository = {
    new RefinedZoneProfileRepositoryImpl(appName, currentRunStartHourAndMinute,
      currentRunStartDateTime, applicationConfig, auditTableRepository)

  }


  /**
   * This method is used to get the data zone.
   *
   * @return DataZone
   */
  override protected def getDataZone: DataZone = {
    DataZone.RefinedZone
  }


}
