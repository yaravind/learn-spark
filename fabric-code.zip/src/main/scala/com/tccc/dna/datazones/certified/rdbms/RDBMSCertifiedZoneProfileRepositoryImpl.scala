package com.tccc.dna.datazones.certified.rdbms

import com.tccc.dna.datazones.init.{ApplicationConfig, RDBMSConfig, TableConfig}
import com.tccc.dna.synapse.{DataZone, Logging}

class RDBMSCertifiedZoneProfileRepositoryImpl(val appName: String, val applicationConfig: ApplicationConfig) extends RDBMSCertifiedZoneProfileRepository with Logging {

  /**
   * Getter method for the RDBMSCertified Zone Profile
   *
   * @param entityName      Name of the entity this method will run for.
   * @param filterCondition Map of the filter conditions used on the dataframe if applicable
   * @example
   *          partition_column               |  partition_value
   *          audit_submission_date_hr_min   |  2024-04-30_16_53
   *
   * @return Return the RDBMSCertified zone profile.
   *
   */
  override def getRdbmsCertifiedZoneProfile(entityName: String, filterCondition: Map[String, Array[String]]): RDBMSCertifiedZoneProfile = {

    logEntityJourneyEvent(entityName, DataZone.RdbmsCertifiedZone, "RdbmsCertifiedZone", s"Create DB Profile for $entityName.")

    val tableConfig = new TableConfig()
    tableConfig.loadConfig(applicationConfig.getFullConfigPath,appName,entityName)

    val rdbmsConfig = new RDBMSConfig()
    rdbmsConfig.loadConfig(applicationConfig.getFullConfigPath,appName,entityName)

    val baseCertifiedPath = applicationConfig.getFullCertifiedPath

    //todo implement filter condition contract with certified
    //todo tbl_final needs to be removed from here. Requires LandingZone location fix in RawZone/TableConfig combo change
    RDBMSCertifiedZoneProfile(entityName,
      applicationConfig.getFullConfigPath,
      baseCertifiedPath + tableConfig.getCertifiedPath + "/tbl_final",
      filterCondition,
      tableConfig,
      rdbmsConfig)

  }
}
