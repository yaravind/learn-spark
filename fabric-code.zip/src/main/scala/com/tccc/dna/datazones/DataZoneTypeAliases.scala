package com.tccc.dna.datazones

import org.apache.spark.sql.DataFrame

object DataZoneTypeAliases {
  /**
   * TODO Add RunId and ActivityId to the dataframe to account for multiple pipeline runs happening in the same day
   * TODO Add ldt = LoadDateTime
   * Schema: {{{
   *   root
   *      |-- name: string (nullable = false)
   *      |-- path: string (nullable = false)
   *      |-- size: long (nullable = false)
   *      |-- isDir: boolean (nullable = false)
   *      |-- isFile: boolean (nullable = false)
   *      |-- modifyTime: long (nullable = false)
   * }}}
   */
  type FileListDataFrame = DataFrame
  type LandingDataFrame = DataFrame
  /**
   * Schema: {{{
   *   root
   *      |-- name: string (nullable = false)
   *      |-- path: string (nullable = false)
   *      |-- size: long (nullable = false)
   *      |-- isDir: boolean (nullable = false)
   *      |-- isFile: boolean (nullable = false)
   *      |-- modifyTime: long (nullable = false)
   *      |-- submissionDay: string (nullable = true)
   *      |-- submissionMonth: string (nullable = true)
   *      |-- submissionYear: string (nullable = true)
   *      |-- submissionDate: date (nullable = true)
   *      |-- isFileSizeGreaterThanZero: boolean (nullable = false)
   *      |-- isFileNameValid: boolean (nullable = false)
   *      |-- isFileNameSuffixValidDateTime: boolean (nullable = false)
   * }}}
   */
  type SyntaticallyValidDataFrame = DataFrame
  /**
   * Schema: {{{
   *   root
   *      |-- name: string (nullable = false)
   *      |-- path: string (nullable = false)
   *      |-- size: long (nullable = false)
   *      |-- isDir: boolean (nullable = false)
   *      |-- isFile: boolean (nullable = false)
   *      |-- modifyTime: long (nullable = false)
   *      |-- submissionDay: string (nullable = true)
   *      |-- submissionMonth: string (nullable = true)
   *      |-- submissionYear: string (nullable = true)
   *      |-- submissionDate: date (nullable = true)
   *      |-- isFileSizeGreaterThanZero: boolean (nullable = false)
   *      |-- isFileNameValid: boolean (nullable = false)
   *      |-- isFileNameSuffixValidDateTime: boolean (nullable = false)
   * }}}
   */
  type SyntaticallyInvalidDataFrame = DataFrame
  type SemanticallyValidDataFrame = DataFrame
  type SemanticallyInvalidDataFrame = DataFrame
}