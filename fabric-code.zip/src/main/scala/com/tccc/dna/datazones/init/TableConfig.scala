package com.tccc.dna.datazones.init

import com.tccc.dna.datazones.utils.{DataFrameUtil, JsonFile}
import com.tccc.dna.synapse.StorageFormat
import com.tccc.dna.synapse.spark.SynapseSpark
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{AnalysisException, DataFrame, Row}

import scala.Console.println

/** Table specific JSON file is processed in this Class and data is exposed thru methods.
 * Table Config has information about an entity. It contains details of all DataZones and respective configuration needed for an Entity to process successfully.
 * @see https://wiki.coke.com/confluence/display/TSDLP/Entity+Configuration
 * @example
 * {
  "dropZoneEntityName": "brand",
  "landingZonePath": "",
  "entityName": "brand",
  "refinedEntityName": "brand",
  "certifiedEntityName": "brand",
  "presentationEntityName": "Brand",
  "contacts": [
    {
      "email": "test1@alwaysko.com",
      "name": "test name 1",
      "typeOfContact": "Business"
    },
    {
      "email": "test2@alwaysko.com",
      "name": "test name 2",
      "typeOfContact": "Business"
    }
  ],
  "entity": {
    "entityDescription": "??? This will be added later on after getting further details from the SMEs.",
    "rawProperties": {
      "rawFullPath": "harmony/inbound/brand/",
      "validFileSetFullPath": "harmony/valid_file_set/brand/",
      "invalidFileSetFullPath": "harmony/invalid_file_set/brand/",
      "validDataFullPath": "harmony/valid_data/brand/",
      "invalidDataErrorFullPath": "harmony/invalid_data_error/brand/",
      "invalidDataFileRejectFullPath": "harmony/invalid_data_file_reject/brand/",
      "archiveFullPath": "harmony/archive/brand/",
      "validDataAdditionalColumnsFullPath":  "",
      "rawFileFormat": "csv",
      "rawLocation": "src/test/default/data/raw/",
      "rawResourcesLocation": "src/test/resources/experiment/data/raw/",
      "dataValidationLevel": "true",
      "landingReadOptions": {
        "header" : "true",
        "multiline" : "true",
        "delimiter" : ",",
        "quote" : "\"",
        "escape" : "\""
      },
      "rawWriteOptions": {
        "header" : "true",
        "multiline" : "true",
        "delimiter" : ",",
        "quote" : "\"",
        "escape" : "\""
      },
      "structuralValidators": {
        "isFileSizeGreaterThanZero": "true",
        "isFileNameValidCheck" : "false",
        "isFileNameSuffixValidDateTime" : "false"
      },
      "semanticValidator" : {
        "isAssetIdUniqueCheck" : "false",
        "isAssetIdValidUUIDCheck": "false",
        "isAssetCreatedCompletenessCheck": "false",
        "isAssetCreatedByEmailTypeCheck": "false"
      }
    },
    "refinedProperties": {
      "refinedFullPath": "harmony/brand/",
      "refinedFileFormat": "delta",
      "refinedValidations": {
        "dataTypeCheck": "true",
        "uniqueRecordsCheck": "true",
        "rowCountCheck": "true"
      },
      "modeOfWrite": "overwrite",
      "surrogateKeyNeeded": "false",
      "backupPlan": {
        "backupByNoOfFileProcessed": "true",
        "backupByNoOfFiles": {
          "noOfBackups": "5",
          "backupPath": "/yyyy/mm/dd",
          "backupFileFormat": "delta"
        },
        "backByNoOfDaysOfData": "false",
        "backupByDays": {
          "noOfDaysToBackup": "365",
          "backupDateColumnName": "order_date"
        }
      }
    },
    "certifiedProperties": {
      "certifiedFullPath": "harmony/brand/",
      "certifiedFileFormat": "delta",
      "modeOfWrite": "upsert"
    },
    "sqlDbCertifiedProperties": {
      "isDbLoadNeeded": "true",
      "dbKey": "harmonyData",
      "dbSchemaName": "sch_harmony",
      "dbTableName": "t_dim_brand_certified",
      "turncate": "true",
      "modeOfWrite": "overwriteFromDelta"
    }
  },
  "columns": [
    {
      "rawColumnName": "brand_cd",
      "ssdpColumnDataType": "String",
      "description": "brand_cd",
      "refinedColumnName": "brand_cd",
      "certifiedColumnName": "brand_cd",
      "presentationColumnName": "BrandID",
      "nullable": "false",
      "keyColumn": "true"
    },
    {
      "rawColumnName": "brand_desc",
      "ssdpColumnDataType": "String",
      "description": "brand_desc",
      "refinedColumnName": "brand_desc",
      "certifiedColumnName": "brand_desc",
      "presentationColumnName": "BrandDescription",
      "nullable": "false",
      "keyColumn": "false"
    },
    {
      "rawColumnName": "",
      "ssdpColumnName": "",
      "ssdpColumnDataType": "",
      "description": "Path of the file which this record was read from.",
      "refinedColumnName": "audit_file_path",
      "certifiedColumnName": "audit_file_path",
      "presentationColumnName": "AuditFilePath",
      "nullable": "true",
      "keyColumn": "false"
    },
    {
      "rawColumnName": "",
      "ssdpColumnName": "",
      "ssdpColumnDataType": "",
      "description": "Name of the file which this record was read from.",
      "refinedColumnName": "audit_file_name",
      "certifiedColumnName": "audit_file_name",
      "presentationColumnName": "AuditFileName",
      "nullable": "true",
      "keyColumn": "false"
    },
    {
      "rawColumnName": "",
      "ssdpColumnName": "",
      "ssdpColumnDataType": "",
      "description": "CreatedTimestamp",
      "refinedColumnName": "audit_crt_ts",
      "certifiedColumnName": "audit_crt_ts",
      "presentationColumnName": "AuditCrtTs",
      "nullable": "true",
      "keyColumn": "false"
    },
    {
      "rawColumnName": "",
      "ssdpColumnName": "",
      "ssdpColumnDataType": "",
      "description": "CreatedUser",
      "refinedColumnName": "audit_crt_usr",
      "certifiedColumnName": "audit_crt_usr",
      "presentationColumnName": "AuditCrtUsr",
      "nullable": "true",
      "keyColumn": "false"
    },
    {
      "rawColumnName": "",
      "ssdpColumnName": "",
      "ssdpColumnDataType": "",
      "description": "UpdatedTimestamp",
      "refinedColumnName": "audit_upd_ts",
      "certifiedColumnName": "audit_upd_ts",
      "presentationColumnName": "AuditUpdTs",
      "nullable": "true",
      "keyColumn": "false"
    },
    {
      "rawColumnName": "",
      "ssdpColumnName": "",
      "ssdpColumnDataType": "",
      "description": "UpdatedUser",
      "refinedColumnName": "audit_upd_usr",
      "certifiedColumnName": "audit_upd_usr",
      "presentationColumnName": "AuditUpdUsr",
      "nullable": "true",
      "keyColumn": "false"
    },
    {
      "rawColumnName": "",
      "ssdpColumnName": "",
      "ssdpColumnDataType": "",
      "description": "Synapse Pipeline RunId.",
      "refinedColumnName": "audit_pipeline_run_id",
      "certifiedColumnName": "audit_pipeline_run_id",
      "presentationColumnName": "AuditPipelineRunId",
      "nullable": "true",
      "keyColumn": "false"
    },
    {
      "rawColumnName": "",
      "ssdpColumnName": "",
      "ssdpColumnDataType": "",
      "description": "Synapse Pipeline Activity RunId.",
      "refinedColumnName": "audit_activity_run_id",
      "certifiedColumnName": "audit_activity_run_id",
      "presentationColumnName": "AuditActivityRunId",
      "nullable": "true",
      "keyColumn": "false"
    },
    {
      "rawColumnName": "",
      "ssdpColumnName": "",
      "ssdpColumnDataType": "",
      "description": "The date when file was dropped in landing zone. the _hour part is added during processing time to support multiple runs within the same day.",
      "refinedColumnName": "audit_submission_date_hr_min",
      "certifiedColumnName": "audit_submission_date_hr_min",
      "presentationColumnName": "AuditSubmissionDateHrMin",
      "nullable": "true",
      "keyColumn": "false"
    }
  ]
}
 */
class TableConfig {
  protected var fileConfigDf: DataFrame = SynapseSpark.getActiveSession.emptyDataFrame

  def loadConfig(path: String, appName: String, fileName: String): Unit = {
    fileConfigDf = JsonFile.readFile(
      path + appName + "/" + fileName + ".json",
      Map("header" -> "false", "multiline" -> "true"),
      StorageFormat.JSON
    ).cache
  }

  def getDataContractPath(path: String, appName: String, fileName: String): String = {
    return path + appName + "/yaml/dc-" + fileName + ".yaml"
  }

  /**
   * Get the columns expected as part of contract.
   *
   * @param useRawColName If set to `true` returns "columns_rawColumnName", else "columns_refinedColumnName".
   * @return
   */
  def getExpectedCols(useRawColName: Boolean = true): Array[String] = {
    val colName = if (useRawColName) "columns_rawColumnName" else "columns_refinedColumnName"
    getColumns
      .filter(col(colName) =!= "")
      .collect()
      .map(row => row.getString(row.fieldIndex(colName)))
  }

  /**
   * Given the `rawColumnName` or `refinedColumnName`, get the corresponding Stage column names.
   *
   * @param useRawColName If set to `true` returns "columns_rawColumnName", else "columns_refinedColumnName".
   * @return State column names as an [[Array]].
   */
  def getStageCols(useRawColName: Boolean = true): Array[String] = {
    val colName = if (useRawColName) "columns_rawColumnName" else "columns_refinedColumnName"
    getColumns
      .filter(col(colName) =!= "")
      .collect()
      .map(row => row.getString(row.fieldIndex("columns_stageColumnName")))
  }

  /**
   * Given the 'rawColumnName' or 'refinedColumnName', get the corresponding data type defined in 'ssdpColumnDataType'.
   *
   * @param useRawColName If set to `true` returns "columns_rawColumnName", else "columns_refinedColumnName".
   * @return An [[Array]] of data types.
   */
  def getStageDataTypes(useRawColName: Boolean = true): Array[String] = {
    val colName = if (useRawColName) "columns_rawColumnName" else "columns_refinedColumnName"
    getColumns
      .filter(col(colName) =!= "")
      .collect()
      .map(row => row.getString(row.fieldIndex("columns_ssdpColumnDataType")))
  }

  /**
   * Get the columns configured to be exploded into rows.
   *
   * @param useRawColName If set to `true` returns "columns_rawColumnName", else "columns_refinedColumnName".
   * @return List of column names configured to be exploded.
   */
  def getToExplodeCols(useRawColName: Boolean = true): Array[String] = {
    val colName = if (useRawColName) "columns_rawColumnName" else "columns_refinedColumnName"
    getColumns
      .filter(col("columns_explode") === "true")
      .collect()
      .map(row => row.getString(row.fieldIndex(colName)))
  }

  /**
   * Get the columns configured to be split (into array struct) with corresponding delimiter.
   *
   * @param useRawColName If set to `true` returns "columns_rawColumnName", else "columns_refinedColumnName".
   * @return Map with column name and delimiter.
   */
  def getToSplitColDelimiterMap(useRawColName: Boolean = true): Map[String, String] = {
    val colName = if (useRawColName) "columns_rawColumnName" else "columns_refinedColumnName"
    getColumns
      .filter(col("columns_split") === "true")
      .collect()
      .map(row => row.getString(row.fieldIndex(colName)) -> row.getString(row.fieldIndex("columns_delimiter"))).toMap
  }

  def getRawToRefinedColMap: Map[String, String] = {
    getColumns
      .filter(col("columns_rawColumnName") =!= "")
      .collect()
      .map(row => row.getString(row.fieldIndex("columns_rawColumnName")) -> row.getString(row.fieldIndex("columns_refinedColumnName"))).toMap
  }

  def getRawColumnList: Array[String] = {
    getColumns
      .filter(col("columns_rawColumnName") =!= "")
      .select("columns_rawColumnName")
      .collect()
      .map(_.getString(0))
  }

  /**
   *
   * @return A Tuple with 3 values (rawColName, refinedColName, refinedDataType).
   */
  def getRawToRefinedDataType: Array[(String, String, String)] = {
    getColumns
      .filter(col("columns_rawColumnName") =!= "")
      .collect()
      .map(row => (row.getString(row.fieldIndex("columns_rawColumnName")),
        row.getString(row.fieldIndex("columns_refinedColumnName")),
        row.getString(row.fieldIndex("columns_ssdpColumnDataType"))))
  }

  //Structural validations
  def isColumnPartOfContractCheckCheckEnabled: Boolean = getRawValidations
    .select("rawValidations_expectedColumnsCheck")
    .collect()
    .map(_.getString(0))
    .mkString("")
    .toBoolean

  def isColNameCheckEnabled: Boolean = getRawValidations
    .select("rawValidations_csvColNameCheck")
    .collect()
    .map(_.getString(0))
    .mkString("")
    .toBoolean

  def isFileNameFormatCheckEnabled: Boolean = getRawValidations
    .select("rawValidations_filenameFormatCheck")
    .collect()
    .map(_.getString(0))
    .mkString("")
    .toBoolean

  def isEmptyFileCheckEnabled: Boolean = getRawValidations
    .select("rawValidations_emptyFileCheck")
    .collect()
    .map(_.getString(0))
    .mkString("")
    .toBoolean

  def isColCountCheckEnabled: Boolean = getRawValidations
    .select("rawValidations_columnCountCheck")
    .collect()
    .map(_.getString(0))
    .mkString("")
    .toBoolean

  def isJsonColCheckEnabled: Boolean = getRawValidations
    .select("rawValidations_jsonColumnsCheck")
    .collect()
    .map(_.getString(0))
    .mkString("")
    .toBoolean

  //Semantic Validations
  def isExpectedColCheckEnabled: Boolean = {
    getRawValidations
      .select("rawValidations_expectedColumnsCheck")
      .collect()
      .map(_.getString(0))
      .mkString("")
      .toBoolean
  }

  def isDuplicateCheckEnabled: Boolean = {
    getRawValidations
      .select("rawValidations_dataDuplicateCheck")
      .collect()
      .map(_.getString(0))
      .mkString("")
      .toBoolean
  }

  def isDataTypeCheckEnabled: Boolean = {
    getRawValidations
      .select("rawValidations_dataTypeWithCountCheck")
      .collect()
      .map(_.getString(0))
      .mkString("")
      .toBoolean
  }

  def isNullCheckEnabled: Boolean = {
    getRawValidations
      .select("rawValidations_nullCheck")
      .collect()
      .map(_.getString(0))
      .mkString("")
      .toBoolean
  }

  def isValidValuesCheckEnabled: Boolean = {
    getRawValidations
      .select("rawValidations_validValuesCheck")
      .collect()
      .map(_.getString(0))
      .mkString("")
      .toBoolean
  }

  def isDateFormatCheckEnabled: Boolean = {
    getRawValidations
      .select("rawValidations_dateFormatCheck")
      .collect()
      .map(_.getString(0))
      .mkString("")
      .toBoolean
  }

  def isBetweenColumnCheckEnabled: Boolean = {
    getRawValidations
      .select("rawValidations_betweenColumnsCheck")
      .collect()
      .map(_.getString(0))
      .mkString("")
      .toBoolean
  }

  def isRowCountCheckEnabled: Boolean = {
    getRawValidations
      .select("rawValidations_rowCountCheck")
      .collect()
      .map(_.getString(0))
      .mkString("")
      .toBoolean
  }

  def isColumnOrderCheckEnabled: Boolean = {
    getRawValidations
      .select("rawValidations_checkColumnOrder")
      .collect()
      .map(_.getString(0))
      .mkString("")
      .toBoolean
  }

  def isCheckEnabled(checkName: String): Boolean = checkName match {
    case "csvColNameCheck" => isColNameCheckEnabled
    case "filenameFormatCheck" => isFileNameFormatCheckEnabled
    case "emptyFileCheck" => isEmptyFileCheckEnabled
    case "columnCountCheck" => isColCountCheckEnabled
    case "jsonColumnsCheck" => isJsonColCheckEnabled
    case "expectedColumnsCheck" => isExpectedColCheckEnabled
    case "dataDuplicateCheck" => isDuplicateCheckEnabled
    case "dataTypeWithCountCheck" => isDataTypeCheckEnabled
    case "validValuesCheck" => isValidValuesCheckEnabled
    case "dateFormatCheck" => isDateFormatCheckEnabled
    case "betweenColumnsCheck" => isBetweenColumnCheckEnabled
    case "rowCountCheck" => isRowCountCheckEnabled
    case "checkColumnOrder" => isColumnOrderCheckEnabled
    case "columnPartOfContractCheck" => isColumnPartOfContractCheckCheckEnabled
    case _ => println(s"$checkName is not supported")
      false
  }

  def getFileConfigDf: DataFrame = fileConfigDf

  def getEntityName: String =
    fileConfigDf.select("entityName").collect().map(_.getString(0)).mkString("")

  def getSurrogateKeyNeeded: Boolean = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.refinedProperties.surrogateKeyNeeded")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")
    .toBoolean

  def getSurrogateKeysNameList: Array[String] = DataFrameUtil
    .flattenDataFrame(fileConfigDf.select("surrogateKeys.keyName"))
    .collect()
    .map(_.getString(0))

  def getRefinedKeyCols: List[String] = {
    getColumns
      .filter(col("columns_keyColumn") === "true")
      .select("columns_refinedColumnName")
      .collect()
      .map(_.getString(0)).toList
  }

  def getRawKeyCols: List[String] = {
    getColumns
      .filter(col("columns_keyColumn") === "true")
      .select("columns_rawColumnName")
      .collect()
      .map(_.getString(0)).toList
  }

  def getCertifiedKeyCols: List[String] = {
    getColumns
      .filter(col("columns_keyColumn") === "true")
      .select("columns_certifiedColumnName")
      .collect()
      .map(_.getString(0)).toList
  }

  def getCertifiedSurrogateKeyCols: List[String] = {
    getColumns
      .filter(col("columns_surrogateKeyColumn") === "true")
      .select("columns_certifiedColumnName")
      .collect()
      .map(_.getString(0)).toList
  }

  def getCertifiedScdCols: List[String] = {
    getColumns
      .filter(col("columns_scdColumn") === "true")
      .select("columns_certifiedColumnName")
      .collect()
      .map(_.getString(0)).toList
  }

  def getKeyColumnsForSurrogateKey(surrogateKey: String): Array[String] =
    DataFrameUtil
      .flattenDataFrame(fileConfigDf.select("surrogateKeys"))
      .filter(col("surrogateKeys_keyName") === surrogateKey)
      .select("surrogateKeys_ColumnsUsed")
      .collect()
      .map(_.getString(0))

  def getDelimiterForSurrogateKeys(surrogateKey: String): String = DataFrameUtil
    .flattenDataFrame(fileConfigDf.select("surrogateKeys"))
    .select("surrogateKeys_keyName", "surrogateKeys_delimiter")
    .distinct()
    .where(col("surrogateKeys_keyName") === surrogateKey)
    .select("surrogateKeys_delimiter")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getColumns: DataFrame = DataFrameUtil.flattenDataFrame(fileConfigDf.select("columns"))

  def getContacts: DataFrame = DataFrameUtil.flattenDataFrame(fileConfigDf.select("contacts"))

  def getRawProperties: DataFrame = DataFrameUtil.flattenDataFrame(fileConfigDf.select("entity.rawProperties"))

  def getRawValidations: DataFrame = DataFrameUtil.flattenDataFrame(fileConfigDf.select("entity.rawProperties.rawValidations"))


  def getDefectFullPath: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.rawProperties.defectFullPath")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getValidatedFullPath: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.rawProperties.validateFullPath")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getProcessedFullPath: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.rawProperties.processedFullPath")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRawLocation: String = DataFrameUtil
    .flattenDataFrame(fileConfigDf.select("entity.rawProperties.rawLocation"))
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRawResourcesLocation: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.rawProperties.rawResourcesLocation")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRawFileFormat: String = DataFrameUtil
    .flattenDataFrame(fileConfigDf.select("entity.rawProperties.rawFileFormat"))
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getStagePath: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.stageProperties.stageFullPath")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRawPath: String = DataFrameUtil
    .flattenDataFrame(fileConfigDf.select("entity.rawProperties.rawFullPath"))
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRawFullPath: String = DataFrameUtil
    .flattenDataFrame(fileConfigDf.select("entity.rawProperties.rawFullPath"))
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getLandingReadOptions: DataFrame = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.rawProperties.landingReadOptions")
  )

  def getRawWriteOptions: DataFrame = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.rawProperties.rawWriteOptions")
  )

  def getStructuralValidatorIsFileSizeGreaterThanZero: Boolean = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.rawProperties.structuralValidators.isFileSizeGreaterThanZero")
  ).collect().map(_.getString(0)).mkString("").toBoolean

  def getStructuralValidatorIsFileNameValidCheck: Boolean = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.rawProperties.structuralValidators.isFileNameValidCheck")
  ).collect().map(_.getString(0)).mkString("").toBoolean

  def getStructuralValidatorIsFileNameSuffixValidDateTime: Boolean = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.rawProperties.structuralValidators.isFileNameSuffixValidDateTime")
  ).collect().map(_.getString(0)).mkString("").toBoolean


  def getSemanticValidatorIsAssetIdUniqueCheck: Boolean = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.rawProperties.semanticValidator.isAssetIdUniqueCheck")
  ).collect().map(_.getString(0)).mkString("").toBoolean

  def getSemanticValidatorIsAssetIdValidUUIDCheck: Boolean = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.rawProperties.semanticValidator.isAssetIdValidUUIDCheck")
  ).collect().map(_.getString(0)).mkString("").toBoolean

  def getSemanticValidatorIsAssetCreatedCompletenessCheck: Boolean = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.rawProperties.semanticValidator.isAssetCreatedCompletenessCheck")
  ).collect().map(_.getString(0)).mkString("").toBoolean

  def getSemanticValidatorIsAssetCreatedByEmailTypeCheck: Boolean = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.rawProperties.semanticValidator.isAssetCreatedByEmailTypeCheck")
  ).collect().map(_.getString(0)).mkString("").toBoolean


  def getSsdpProperties: DataFrame =
    DataFrameUtil.flattenDataFrame(fileConfigDf.select("entity.ssdpProperties"))

  def getSsdpFullPath: String = DataFrameUtil
    .flattenDataFrame(fileConfigDf.select("entity.ssdpProperties.ssdpFullPath"))
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getSsdpLocation: String = DataFrameUtil
    .flattenDataFrame(fileConfigDf.select("entity.ssdpProperties.ssdpLocation"))
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getSsdpResourcesLocation: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.ssdpProperties.ssdpResourcesLocation")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getSsdpFileFormat: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.ssdpProperties.ssdpFileFormat")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getStageFileFormat: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.stageProperties.stageFileFormat")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getStageValidations: DataFrame = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.stageProperties.stageValidations")
  )

  def getStageBackupByNoOfFileProcessed: Boolean = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select(
        "entity.stageProperties.backupPlan.backupByNoOfFileProcessed"
      )
    )
    .collect()
    .map(_.getString(0))
    .mkString("")
    .toBoolean

  def getStageBackupByNoOfFiles: DataFrame = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.stageProperties.backupPlan.backupByNoOfFiles")
  )

  def getStageBackByNoOfDaysOfData: Boolean = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select(
        "entity.stageProperties.backupPlan.backByNoOfDaysOfData"
      )
    )
    .collect()
    .map(_.getString(0))
    .mkString("")
    .toBoolean

  def getStageBackupByDays: DataFrame = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.stageProperties.backupPlan.backupByDays")
  )

  def getRefinedPath: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.refinedProperties.refinedFullPath")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRefinedFileFormat: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.refinedProperties.refinedFileFormat")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRefinedValidations: DataFrame = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.refinedProperties.refinedValidations")
  )

  def getRefinedBackupByNoOfFileProcessed: Boolean = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select(
        "entity.refinedProperties.backupPlan.backupByNoOfFileProcessed"
      )
    )
    .collect()
    .map(_.getString(0))
    .mkString("")
    .toBoolean

  def getRefinedBackupByNoOfFiles: DataFrame = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.refinedProperties.backupPlan.backupByNoOfFiles")
  )

  def getRefinedBackByNoOfDaysOfData: Boolean = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select(
        "entity.refinedProperties.backupPlan.backByNoOfDaysOfData"
      )
    )
    .collect()
    .map(_.getString(0))
    .mkString("")
    .toBoolean

  def getRefinedBackupByDays: DataFrame = DataFrameUtil.flattenDataFrame(
    fileConfigDf.select("entity.refinedProperties.backupPlan.backupByDays")
  )

  def getRefinedModeOfWrite: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.refinedProperties.modeOfWrite")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRefinedOnColumn: List[String] = DataFrameUtil
    .flattenDataFrame(fileConfigDf.select("entity.refinedProperties.onColumn"))
    .collect()
    .map(_.getString(0))
    .toList

  def getCertifiedPath: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.certifiedProperties.certifiedFullPath")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getCertifiedModeOfWrite: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.certifiedProperties.modeOfWrite")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getCertifiedFileFormat: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.certifiedProperties.certifiedFileFormat")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getCertifiedOnColumn: List[String] = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.certifiedProperties.onColumn")
    )
    .collect()
    .map(_.getString(0))
    .toList

  def getScd2KeyColumns: List[String] = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.scd2Properties.scd2KeyColumns")
    )
    .collect()
    .map(_.getString(0))
    .toList

  def getScd2ValueColumns: List[String] = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.scd2Properties.scd2ValueColumns")
    )
    .collect()
    .map(_.getString(0))
    .toList

  def getScd2UseCustomExpressionForEffectiveStartDate: Boolean = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.scd2Properties.useCustomExpressionForEffectiveStartDate")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")
    .toBoolean

  def getScd2CustomExpressionForEffectiveStartDate: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.scd2Properties.customExpression")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getScd2EffectiveStartDateColumnName: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.scd2Properties.scd2EffectiveStartDateColumnName")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getScd2EffectiveEndDateColumnName: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.scd2Properties.scd2EffectiveEndDateColumnName")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getScd2CreatedAtColumnName: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.scd2Properties.scd2CreatedAtColumnName")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getScd2UpdatedAtColumnName: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.scd2Properties.scd2UpdatedAtColumnName")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getScd2IsCurrentFlagColumnName: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.scd2Properties.scd2IsCurrentColumnName")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getIsRdbmsCertifiedLoadNeeded: Boolean = {
    try {
      fileConfigDf.select("entity.sqlDbCertifiedProperties.isDbLoadNeeded")
      return true
    } catch {
      case e: AnalysisException => return false
    }
  }

  def getDbKey: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.sqlDbCertifiedProperties.dbKey")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getDbCertifiedQualifiedTableName:String = s"${getDbCertifiedSchemaName}.${getDbCertifiedTableName}"

  def getDbCertifiedTableName: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.sqlDbCertifiedProperties.dbTableName")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getDbCertifiedSchemaName: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.sqlDbCertifiedProperties.dbSchemaName")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRdbmsCertifiedModeOfWrite: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.sqlDbCertifiedProperties.modeOfWrite")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getDateColumnNullNames: Array[String] = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select(
        "entity.rawProperties.dataQualityCheckInfo.dateColNamesNull"
      )
    )
    .collect()
    .map(_.getString(0))


  def getDateColumnNotNullNames: Array[String] = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select(
        "entity.rawProperties.dataQualityCheckInfo.dateColNamesNotNull"
      )
    )
    .collect()
    .map(_.getString(0))

  def getDateFormat: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select(
        "entity.rawProperties.dataQualityCheckInfo.dateFormat"
      )
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getValidValues(colName: String): Array[String] = {
    DataFrameUtil
      .flattenDataFrame(
        fileConfigDf.select(
          s"entity.rawProperties.dataQualityCheckInfo.validValues.$colName"
        )
      )
      .collect()
      .map(_.getString(0))
  }

  def getAllValidValueColumns: Map[String, List[String]] = {
    val validValuesRaw = fileConfigDf
      .select("entity.rawProperties.dataQualityCheckInfo.validValues")
      .collect()(0)(0)

    validValuesRaw match {
      case row: Row =>
        row
          .getValuesMap[Seq[String]](row.schema.fieldNames)
          .map { case (k, v) => (k, v.toList) }
      case _ => Map.empty[String, List[String]]
    }
  }

  def getColumnRegexReplaceStringWithColumnNameMap: Map[String, String] = {
    getColumns
      .filter(col("columns_split") === "true")
      .collect()
      .map(row => row.getString(row.fieldIndex("columns_refinedColumnName")) -> row.getString(row.fieldIndex("columns_columnRegexReplaceString"))).toMap
  }

  def getRegexReplaceStringForSpecifiedColumns: Map[String, String] = {
    getColumns
      .filter(col("columns_columnRegexReplaceString") =!= "")
      .collect()
      .map(row => row.getString(row.fieldIndex("columns_refinedColumnName")) -> row.getString(row.fieldIndex("columns_columnRegexReplaceString"))).toMap
  }

  def getToSplitCols(useRawColName: Boolean = true): Array[String] = {
    val colName = if (useRawColName) "columns_rawColumnName" else "columns_refinedColumnName"
    getColumns
      .filter(col("columns_split") === "true")
      .collect()
      .map(row => row.getString(row.fieldIndex(colName)))
  }


  def getDropZoneEntityName: String =
    fileConfigDf
      .select("dropZoneEntityName")
      .collect()
      .map(_.getString(0))
      .mkString("")

  def getLandingZonePath: String =
    fileConfigDf
      .select("landingZonePath")
      .collect()
      .map(_.getString(0))
      .mkString("")

  def getValidFileSetFullPath: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.rawProperties.validFileSetFullPath")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getInvalidFileSetFullPath: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.rawProperties.invalidFileSetFullPath")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getValidDataFullPath: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.rawProperties.validDataFullPath")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getInvalidDataErrorFullPath: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.rawProperties.invalidDataErrorFullPath")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getInvalidDataFileRejectFullPath: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.rawProperties.invalidDataFileRejectFullPath")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getArchiveFullPath: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.rawProperties.archiveFullPath")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getValidDataAdditionalColumnsFullPath: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.rawProperties.validDataAdditionalColumnsFullPath")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getDataValidationLevel: String = DataFrameUtil
    .flattenDataFrame(
      fileConfigDf.select("entity.rawProperties.dataValidationLevel")
    )
    .collect()
    .map(_.getString(0))
    .mkString("")

}