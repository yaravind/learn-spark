package com.tccc.dna.datazones.init

/**
 * ApplicationConstantsImpl is a class that extends ApplicationConstants. It is also used to define the application name.
 */
class ApplicationConstantsImpl(appNameFromArgs: String) extends ApplicationConstants {

  override val appName: String = appNameFromArgs
}
