package com.tccc.dna.datazones.utils

import org.apache.spark.sql.types._


object DataZoneUtilImpl extends DataZoneUtil {

  /**
   * This method is used to get the final write options for the given entity name
   *
   * @param entityName Name of the entity
   * @return Map of write options
   */
  def getFinalWriteOptions(entityName: String): Map[String, String] = {
    entityName match {
      case _ => Map.empty[String, String]
    }
  }

  /**
   * This method is used to get the raw schema for the given entity name
   *
   * @param entityName Name of the entity
   * @return Schema for the entity
   */

  def getFinalRawTableSchema(entityName: String): StructType = {
    entityName match {
      case _ => null
    }
  }

  /**
   * This method is used to get the Refine schema for the given entity name
   *
   * @param entityName Name of the entity
   * @return Schema for the entity
   */
  def getFinalRefinedTableSchema(entityName: String): StructType = {
    entityName match {
      case _ => null
    }
  }

  /**
   * This method is used to get the schema as string for the given entity name for json validation
   *
   * @param entityName Name of the entity
   * @return Schema as string
   */
  def getSchemaAsString(entityName: String): String = {
    entityName match {
      case _ => ""
    }
  }

  def getJsonSchemaResourcePath(entityName: String): String = {
    entityName match {
      case _ => ""
    }
  }

}