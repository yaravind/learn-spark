package com.tccc.dna.datazones.certified.rdbms

/**
 * Repository abstract class for the [[RDBMSCertifiedZoneProfile]]
 *
 */
abstract class RDBMSCertifiedZoneProfileRepository {


  /**
   * Definition for getting the [[RDBMSCertifiedZoneProfile]]
   *
   * @param entityName      Name of the entity this method will run for.
   * @param filterCondition Map of the filter conditions used on the dataframe if applicable
   * @example
   *          partition_column               |  partition_value
   *          audit_submission_date_hr_min   |  2024-04-30_16_53
   *
   * @return Return the [[RDBMSCertifiedZoneProfile]]. Or it would if it did anything.
   *
   */

  def getRdbmsCertifiedZoneProfile(entityName: String, filterCondition: Map[String, Array[String]]): RDBMSCertifiedZoneProfile

}
