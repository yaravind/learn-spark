package com.tccc.dna.datazones.validators

import com.amazon.deequ.checks.Check
import com.amazon.deequ.{VerificationResult, VerificationSuite}
import com.tccc.dna.synapse.Logging
import com.tccc.dna.synapse.spark.SynapseSpark
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, round}

/** A base implementation of [[SemanticValidator]] that uses [[https://github.com/awslabs/deequ Deequ]] to perform semantic record level validation.
  */
class DeequBackedSemanticValidator extends SemanticValidator with Logging {
  protected var checks: Seq[Check] = Seq.empty

  def getSemanticChecks: Seq[Check] = checks

  def addCheck(ch: Check): Unit = {
    this.checks :+= ch
  }

  def removeCheck(ch: Check): Unit = {
    this.checks = checks.filterNot(_ == ch)
  }

  /** Performs semantic validation on the provided DataFrame. A '''new column is added''' to the DataFrame '''for each check'''
    * containing the result of the check performed. The column name is the same as the check name.
    *
    * Checks are performed in the order they are added to the [[DeequBackedSemanticValidator]] using [[addCheck()]].
    *
    * @param inputDf The DataFrame to be checked.
    * @return The DataFrame with the new columns added for each check performed. For e.g. if 3 checks
    *         '''(isAssetIdUnique, isColumnContainsEmail, isUUIDUnique)''' are
    *         configured then the Schema would be (Note the last three columns added to the inputDf : {{{
    *           root
    *            |-- name: string (nullable = true)
    *            |-- path: string (nullable = true)
    *            |-- size: long (nullable = false)
    *            |-- isDir: boolean (nullable = false)
    *            |-- isFile: boolean (nullable = false)
    *            |-- modifyTime: long (nullable = false)
    *            |-- isAssetIdUnique: boolean (nullable = false)
    *            |-- isColumnContainsEmail: boolean (nullable = false)
    *            |-- isUUIDUnique: boolean (nullable = false)
    * }}}
    */
  override def check(inputDf: DataFrame): DataFrame = {
    logInfo(s"Performing ${checks.size} checks.")
    inputDf.printSchema()
    val verificationResult = VerificationSuite()
      .onData(inputDf)
      .addChecks(checks)
      .run()

    logInfo("Semantic check: Summary")
    VerificationResult
      .checkResultsAsDataFrame(
        SynapseSpark.getActiveSession,
        verificationResult
      )
      .show(numRows = 100, truncate = false)

    logInfo("Semantic check: Metrics")
    val metricsSummary = VerificationResult
      .successMetricsAsDataFrame(
        SynapseSpark.getActiveSession,
        verificationResult
      )
      .withColumn("valuePercentage", round(col("value").multiply(100), 2))
    metricsSummary.show(truncate = false)

    val result = VerificationResult.rowLevelResultsAsDataFrame(
      SynapseSpark.getActiveSession,
      verificationResult,
      inputDf
    )
    result
  }

  def getCheckNames() = getSemanticChecks.map(ch => ch.description)
}
