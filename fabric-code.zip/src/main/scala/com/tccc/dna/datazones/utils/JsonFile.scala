package com.tccc.dna.datazones.utils

import com.tccc.dna.synapse.StorageFormat
import com.tccc.dna.synapse.spark.SynapseSpark
import org.apache.spark.sql.DataFrame

/** This Object contains all JSON File related operations.
  */
object JsonFile extends File {
  override def readFile(
      path: String,
      additionalOption: Map[String, String] = Map(),
      fileFormat: StorageFormat
  ): DataFrame = {
    SynapseSpark.getActiveSession.read.options(additionalOption).json(path)

  }
}
