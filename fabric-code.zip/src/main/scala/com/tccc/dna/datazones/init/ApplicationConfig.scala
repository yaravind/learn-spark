package com.tccc.dna.datazones.init

import com.tccc.dna.datazones.utils.{DataFrameUtil, JsonFile}
import com.tccc.dna.synapse.spark.{SynapseSpark => SS}
import com.tccc.dna.synapse.{DataZone, Logging, StorageFormat, Utils}
import org.apache.spark.sql.DataFrame

import scala.collection.mutable.ListBuffer

/**
 * Encapsulates method to initialize configuration based on the application. Application here means a subject area/ a business process that needs to be
 * processed together for data ingestion unit of work.
 * @see https://wiki.coke.com/confluence/pages/viewpage.action?pageId=218065842
 * @example Below is a sample for Application Configuration
 * {
  "localExperiment": {
    "defaultPath": "src/test/resources/experiment",
    "storageAccount": "",
    "configFolder": "",
    "rawFolder": "",
    "refinedFolder": "",
    "certifiedFolder": "",
    "at": "",
    "userName": "",
    "configPath": "metadata/control_files/",
    "rawPath": "data/raw/",
    "refinedPath": "data/refined/",
    "certifiedPath": "data/certified/",
    "appName": "harmony",
    "landingZonePath": "src/test/resources/experiment/data/landing/harmony/",
    "baseAemSourcePath": "",
    "baseDestPath": "harmony/inbound/",
    "auditTablePath": "src/test/resources/experiment/data/shared/application_transaction_log",
    "configToProcess": {
      "brand": "true",
      "country": "true",
      "search_synonym": "true"
    },
    "email": {
      "from": "xxx@coca-cola.com",
      "smtp_host": "servermail.coca-cola.com"
    }
  },
  "testEnvironment": {
    "defaultPath": "src/test/resources/experiment/",
    "defaultConfigPath": "src/test/resources/experiment/",
    "storageAccount": "",
    "configFolder": "",
    "rawFolder": "",
    "refinedFolder": "",
    "certifiedFolder": "",
    "at": "",
    "userName": "",
    "configPath": "metadata/control_files/",
    "rawPath": "data/raw/",
    "refinedPath": "data/refined/",
    "certifiedPath": "data/certified/",
    "appName": "harmony",
    "landingZonePath": "src/test/resources/testdata/input_data/harmony/",
    "baseDestPath": "harmony/inbound/",
    "auditTablePath": "src/test/resources/experiment/data/shared/application_transaction_log",
    "configToProcess": {
      "brand": "true",
      "country": "true",
      "search_synonym": "true"
    },
    "email": {
      "from": "xxx@coca-cola.com",
      "smtp_host": "servermail.coca-cola.com"
    }
  },
  "synapseDevExperiment": {
    "defaultPath": "abfss://",
    "storageAccount": "xxx.dfs.core.windows.net",
    "configFolder": "experiment",
    "rawFolder": "experiment",
    "refinedFolder": "experiment",
    "certifiedFolder": "experiment",
    "at": "@",
    "userName": "",
    "configPath": "metadata/harmony/control_files/",
    "dataPath": "data/",
    "rawPath": "raw/",
    "refinedPath": "refined/",
    "certifiedPath": "certified/",
    "appName": "harmony",
    "landingZonePath": "",
    "baseDestPath": "harmony/inbound/",
    "auditTablePath": "abfss://shared@xxx.dfs.core.windows.net/application_transaction_log/",
    "configToProcess": {
      "brand": "true",
      "country": "true",
      "search_synonym": "true"
    },
    "email": {
      "from": "xxx@coca-cola.com",
      "smtp_host": "servermail.coca-cola.com"
    }
  },
  "synapseUatExperiment": {
    "defaultPath": "abfss://",
    "storageAccount": "xxx.dfs.core.windows.net",
    "configFolder": "experiment",
    "rawFolder": "experiment",
    "refinedFolder": "experiment",
    "certifiedFolder": "experiment",
    "at": "@",
    "userName": "",
    "configPath": "metadata/harmony/control_files/",
    "dataPath": "data/",
    "rawPath": "raw/",
    "refinedPath": "refined/",
    "certifiedPath": "certified/",
    "appName": "harmony",
    "landingZonePath": "",
    "baseDestPath": "harmony/inbound/",
    "auditTablePath": "abfss://shared@xxx.dfs.core.windows.net/application_transaction_log/",
    "configToProcess": {
      "brand": "true",
      "country": "true",
      "search_synonym": "true"
    },
    "email": {
      "from": "xxx@coca-cola.com",
      "smtp_host": "servermail.coca-cola.com"
    }
  },
  "syn-tccc-udp-xxx-us2-dev-01": {
    "defaultPath": "abfss://",
    "storageAccount": "xxx.dfs.core.windows.net",
    "configFolder": "metadata",
    "rawFolder": "raw",
    "refinedFolder": "refined",
    "certifiedFolder": "certified",
    "at": "@",
    "userName": "",
    "configPath": "harmony/control_files/",
    "rawPath": "",
    "refinedPath": "",
    "certifiedPath": "",
    "appName": "harmony",
    "landingZonePath": "abfss://landing@xxx.dfs.core.windows.net/harmony/",
    "baseDestPath": "harmony/inbound/",
    "auditTablePath": "abfss://shared@xxx.dfs.core.windows.net/application_transaction_log/",
    "configToProcess": {
      "brand": "true",
      "country": "true",
      "search_synonym": "true"
    },
    "email": {
      "from": "xxx@coca-cola.com",
      "smtp_host": "servermail.coca-cola.com"
    }
  },
  "syn-tccc-udp-xxx-us2-uat-03": {
    "defaultPath": "abfss://",
    "storageAccount": "xxx.dfs.core.windows.net",
    "dataFolder": "experiment",
    "configFolder": "metadata",
    "rawFolder": "raw",
    "refinedFolder": "refined",
    "certifiedFolder": "certified",
    "at": "@",
    "userName": "",
    "configPath": "harmony/control_files/",
    "rawPath": "",
    "refinedPath": "",
    "certifiedPath": "",
    "appName": "harmony",
    "landingZonePath": "abfss://landing@xxx.dfs.core.windows.net/harmony/",
    "baseDestPath": "harmony/inbound/",
    "auditTablePath": "abfss://shared@xxx.dfs.core.windows.net/application_transaction_log/",
    "configToProcess": {
      "brand": "true",
      "country": "true",
      "search_synonym": "true"
    },
    "email": {
      "from": "xxx@coca-cola.com",
      "smtp_host": "servermail.coca-cola.com"
    }
  },
  "syn-tccc-udp-xxx-us2-prd-02": {
    "defaultPath": "abfss://",
    "storageAccount": "xxx.dfs.core.windows.net",
    "dataFolder": "experiment",
    "configFolder": "metadata",
    "rawFolder": "raw",
    "refinedFolder": "refined",
    "certifiedFolder": "certified",
    "at": "@",
    "userName": "",
    "configPath": "harmony/control_files/",
    "rawPath": "",
    "refinedPath": "",
    "certifiedPath": "",
    "appName": "harmony",
    "landingZonePath": "abfss://landing@xxx.dfs.core.windows.net/harmony/",
    "baseDestPath": "harmony/inbound/",
    "auditTablePath": "abfss://shared@xxx.dfs.core.windows.net/application_transaction_log/",
    "configToProcess": {
      "brand": "true",
      "country": "true",
      "search_synonym": "true"
    },
    "email": {
      "from": "xxx@coca-cola.com",
      "smtp_host": "servermail.coca-cola.com"
    }
  }
}
 *
 */
class ApplicationConfig(applicationConstants: ApplicationConstants) extends Logging {

  private var appConfigDf: DataFrame = SS.getActiveSession.emptyDataFrame
  var environment: String = null
  private var user: String = null
  var testBasePath = ""

  /** loads the configuration details
   *
   * @param baseConfigPath The path pointing to where the configuration file is located
   * @param appName        The name of the application being run
   * @param environment    The synapse or local environment where the application is running
   * @param user           The user or managed identity id running the application
   * @return appConfigDf of DataFrame Type
   */

  def loadConfig(
                  baseConfigPath: String,
                  appName: String,
                  environment: String,
                  user: String
                ): DataFrame = {
    val logMessage = s"Loading config for [env: $environment, appName: $appName, and user: $user] from path: $baseConfigPath"
    logDataZoneEvent(DataZone.RawZone, "Processing", message = logMessage)
    this.environment = environment
    this.user = user
    appConfigDf = JsonFile
      .readFile(
        baseConfigPath + appName + "/InitApplication.json",
        Map("multiline" -> "true"),
        StorageFormat.JSON
      )
      .select(environment)
    appConfigDf.cache()
  }

  /** @return App Config DataFrame */
  def getAppConfigDf: DataFrame = appConfigDf

  /** @return Returns the list of entities to be processed. */
  def getConfiguredEntities: List[String] = {
    val toBeProcessed = ListBuffer[String]()
    for (table <- getConfigToProcess.schema.names) {
      val entityName = table.substring(16)
      if (shouldProcess(entityName)) {
        toBeProcessed += entityName
      }
    }
    toBeProcessed.toList
  }

  def shouldProcess(tableName: String): Boolean = {
    getConfigToProcess
      .select(s"configToProcess_$tableName")
      .collect()
      .map(_.getString(0))
      .mkString("")
      .toBoolean
  }

  def getBasePath: String = {
    if (environment == "testEnvironment") {
      testBasePath
    } else {
      appConfigDf
        .select(environment + ".defaultPath")
        .collect()
        .map(_.getString(0))
        .mkString("")
    }

  }

  def getStorageAccount: String = appConfigDf
    .select(environment + ".storageAccount")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRawFolder: String = appConfigDf
    .select(environment + ".rawFolder")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRefinedFolder: String = appConfigDf
    .select(environment + ".refinedFolder")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getCertifiedFolder: String = appConfigDf
    .select(environment + ".certifiedFolder")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getConfigFolder: String = appConfigDf
    .select(environment + ".configFolder")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getAt: String = appConfigDf
    .select(environment + ".at")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRelativeConfigPath: String = appConfigDf
    .select(environment + ".configPath")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRelativeRawPath: String = appConfigDf
    .select(environment + ".rawPath")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRelativeRefinedPath: String = appConfigDf
    .select(environment + ".refinedPath")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRelativeCertifiedPath: String = appConfigDf
    .select(environment + ".certifiedPath")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getConfigToProcess: DataFrame = DataFrameUtil.flattenDataFrame(
    appConfigDf.select(environment + ".configToProcess")
  )

  def getBaseAemSourcePath: String = {

    appConfigDf
      .select(environment + ".baseAemSourcePath")
      .collect()
      .map(_.getString(0))
      .mkString("")

  }

  def getBaseLandingPath: String = {

    appConfigDf
      .select(environment + ".landingZonePath")
      .collect()
      .map(_.getString(0))
      .mkString("")

  }

  def getBaseCdsLandingPath: String = {

    appConfigDf
      .select(environment + ".cdsLandingZonePath")
      .collect()
      .map(_.getString(0))
      .mkString("")

  }

  def getBaseCdsArchivePath: String = {

    appConfigDf
      .select(environment + ".cdsArchivePath")
      .collect()
      .map(_.getString(0))
      .mkString("")

  }

  def getBaseLookupPath: String = {

    appConfigDf
      .select(environment + ".lookupPath")
      .collect()
      .map(_.getString(0))
      .mkString("")

  }

  def getRelativeBaseAemDestPath: String = appConfigDf
    .select(environment + ".baseAemDestPath")
    .collect()
    .map(_.getString(0))
    .mkString("")

  private def getExceptionsPath: String = appConfigDf
    .select(environment + ".exceptionsPath")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getAssetTablePath: String = appConfigDf
    .select(environment + ".assetTablePath")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getAssetMetadataPath: String = appConfigDf
    .select(environment + ".assetMetadataTablePath")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getLandingZonePath: String = appConfigDf
    .select(environment + ".landingZonePath")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRelativeBaseDestPath: String = appConfigDf
    .select(environment + ".baseDestPath")
    .collect()
    .map(_.getString(0))
    .mkString("")

  def getRelativeAuditTablePath: String = appConfigDf
    .select(environment + ".auditTablePath")
    .collect()
    .map(_.getString(0))
    .mkString("")


  def getFullConfigPath: String = {
    getBasePath + getConfigFolder + getAt + getStorageAccount + "/" + user + "/" + getRelativeConfigPath
  }

  def getFullDataPath: String =
    getBasePath + getConfigFolder + getAt + getStorageAccount + "/" + user + "/" + getRelativeConfigPath

  def getFullRawPath: String =
    getBasePath + getRawFolder + getAt + getStorageAccount + "/" + user + "/" + getRelativeRawPath

  def getFullRefinedPath: String =
    getBasePath + getRefinedFolder + getAt + getStorageAccount + "/" + user + "/" + getRelativeRefinedPath

  def getFullCertifiedPath: String =
    getBasePath + getCertifiedFolder + getAt + getStorageAccount + "/" + user + "/" + getRelativeCertifiedPath

  def getFullExceptionsPath: String = getBasePath + getExceptionsPath

  def getFullAemDestPath: String =
    getBasePath + getRawFolder + getAt + getStorageAccount + "/" + user + "/" + getRelativeRawPath + getRelativeBaseAemDestPath

  def getFullBaseDestPath: String =
    getBasePath + getRawFolder + getAt + getStorageAccount + "/" + user + "/" + getRelativeRawPath

  /** @return Control file base path */
  def getControlFileBasePath(environment: String): String = {
    getAppBasePathForDataZone(environment, applicationConstants.metadata, getEnvironmentStorageAccount(environment))
  }

  /** @return Data Zone Base Path */
  def getDataZoneBasePath(environment: String, dataZone: String): String = {
    getAppBasePathForDataZone(environment, dataZone, getEnvironmentStorageAccount(environment))
  }

  def getAppBasePathForDataZone(environment: String, dataZone: String, storageAccountName: String): String = {
    val appName = if (applicationConstants.additionalAppName == applicationConstants.notAvailable) (applicationConstants.appName) else (applicationConstants
      .additionalAppName)
    if (environment == applicationConstants.localEnvironment || environment == applicationConstants.testEnvironment) {
      applicationConstants.localBasePathLoc
      //      + dataZone + appName
    } else {
      if (!SS.isRunAsManagedIdentity)
        s"${applicationConstants.fileProtocol}$dataZone@$storageAccountName${applicationConstants.storageAccountUrlPostFix}/${appName}/${applicationConstants.controlFileLoc}/"
      else
        s"${applicationConstants.fileProtocol}${applicationConstants.experiment}@$storageAccountName${applicationConstants.storageAccountUrlPostFix}/${
          Utils.getUserNameFromEmail(SS
            .getCurrentUserName)
        }" +
          //TODO check it and delete it. Add control files as well as additional path name work on monday.
          s"/${applicationConstants.appName}/{$dataZone}"
    }
  }

  def getEnvironmentStorageAccount(environment: String): String = {
    var storageAccountName = ""
    if (environment == applicationConstants.localEnvironment || environment == applicationConstants.testEnvironment) {
      storageAccountName = ""
    } else {
      environment match {
        case applicationConstants.devSynapseName =>
          storageAccountName = applicationConstants.devStorageAccount
        case applicationConstants.uatSynapseName =>
          storageAccountName = applicationConstants.uatStorageAccount
        case applicationConstants.prodSynapseName =>
          storageAccountName = applicationConstants.prodStorageAccount

        case applicationConstants.synapseDevExperiment =>
          storageAccountName = applicationConstants.devStorageAccount
        case applicationConstants.synapseUatExperiment =>
          storageAccountName = applicationConstants.uatStorageAccount
        case applicationConstants.synapseProdExperiment =>
          storageAccountName = applicationConstants.prodStorageAccount

      }
    }
    storageAccountName
  }


}
