package com.tccc.dna.datazones.validators

import org.apache.spark.sql.DataFrame

/**
 * A semantic validator specifically designed for JSON data validation.
 *
 * @param cacheDf Boolean indicating whether to cache the DataFrame (default: false).
 */
class JsonSemanticValidator(cacheDf: Boolean = false) extends DeequBackedSemanticValidator {

  /**
   * Performs custom semantic validation on the input DataFrame, including additional logging and schema printing.
   *
   * @param inputDf The DataFrame to be checked.
   * @return The DataFrame after performing semantic validation and custom operations.
   */
  override def check(inputDf: DataFrame): DataFrame = {

    val semanticResultDf = super.check(inputDf)
    logInfo(s"After Custom DQ validation. Row count: ${semanticResultDf.count()}")
    semanticResultDf.printSchema(level = 1)
    semanticResultDf
  }
  /**
   * Overrides the superclass method to add an additional "isValid" check to the existing list of checks.
   *
   * @return A sequence of check names, including the default checks from the superclass and "isValid".
   * [[DeequBackedSemanticValidator]].
   *
   */
  override def getCheckNames(): Seq[String] = super.getCheckNames() :+ "isValid"
}
