package com.tccc.dna.datazones.validators

import com.tccc.dna.synapse.StorageFormat
import com.tccc.dna.synapse.spark.DataFrames
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, from_json}
import org.apache.spark.sql.types.StructType

/**
 * A DataLoader implementation for loading JSON data.
 *
 * @param jsonSchemaAsStr Optional JSON schema as a string.
 * @param entitySchema    Optional entity schema as a StructType.
 * @param readOptions     Read options for loading JSON data.
 * @param cacheDf         Flag indicating whether to cache the DataFrame after loading.
 */
class JsonDataLoader(jsonSchemaAsStr: Option[String], entitySchema: Option[StructType], readOptions: Map[String, String], cacheDf: Boolean = false)
  extends DataLoader(jsonSchemaAsStr, entitySchema, StorageFormat.JSON, readOptions, cacheDf) {

  /**
   * Loads JSON data into a DataFrame.
   *
   * @param inputDf The input DataFrame containing JSON data to be loaded.
   * @return The DataFrame after loading.
   */

  override def load(inputDf: DataFrame): DataFrame = {
    val validFiles: Array[String] =
      inputDf.select("validFileSetPath").collect().map(row => row.getString(0))
    logInfo(s"Total files for semantic validation: ${validFiles.length}")
    logInfo(s"Files:")
    validFiles.foreach(file => logInfo(file))

    val semanticResultDf = jsonSchemaAsStr match {
      case Some(jsonSchemaAsStr) =>
        val semanticResultDf = DataFrames.loadAndValidateJsonV2(
          jsonSchemaAsStr,
          addInputFilePath = true,
          validFiles: _*
        )

        semanticResultDf.show(5, truncate = false)
        logInfo(s"3.1.2 Perform Custom DQ validation.")
        val jsonStrCol = col("input") //The entire input json is put in "input" column
        logInfo(s"Parsing out json from column: $jsonStrCol")

        semanticResultDf
          .withColumn("parsed", from_json(jsonStrCol, entitySchema.get, Map("timestampFormat" -> "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")))
          .select("parsed.*", "input_file_path", "is_valid", "error_count", "error_list")
          .withColumnRenamed("is_valid", "isValid")
          .withColumnRenamed("input_file_path", "audit_file_path")
    }

    if (cacheDf) {
      logInfo(s"Caching enabled (cacheDf = true). Calling df.cache() on the resulting DataFrame.")
      semanticResultDf.cache()
    } else {
      semanticResultDf
    }
  }
}

