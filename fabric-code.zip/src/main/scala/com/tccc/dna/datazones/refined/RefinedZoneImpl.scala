package com.tccc.dna.datazones.refined

import com.tccc.dna.datazones.utils.DataZoneUtilImpl
import com.tccc.dna.datazones.validators.GenericValidator
import com.tccc.dna.synapse.spark.{SynapseSpark => SS}
import com.tccc.dna.synapse.{DataZone, StorageFormat}
import org.apache.spark.sql.DataFrame

/**
 * RefinedZoneImpl is the implementation of RefinedZoneTemplate.
 *
 * @param refinedZoneProfile Instance of [[RefinedZoneProfile]].
 */
class RefinedZoneImpl(refinedZoneProfile: RefinedZoneProfile
                     ) extends RefinedZoneTemplate(refinedZoneProfile) {

  override def loadData(FinalRawPath: String): DataFrame = {
    //logInfo(s"Read data from $FinalRawPath: START")
    logMessage = s"Read data from $FinalRawPath: START"
    logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "load raw data", logMessage)
    var refinedDf = SS.getActiveSession.emptyDataFrame
    if (refinedZoneProfile.tableCfg.getRawFileFormat == "json") {
      refinedDf = DataZoneUtilImpl.getDataFrameFromUriWithFilters(
        FinalRawPath,
        StorageFormat.JSON,
        GenericValidator.getSchemaWithMetadata(refinedZoneProfile.tableCfg),
        GenericValidator.getRawWriteOptions(tableConfig = refinedZoneProfile.tableCfg),
        refinedZoneProfile.filterCondition,
      )
      //logInfo(s"dataframe count: ${refinedDf.count()}")
      logMessage = s"dataframe count: ${refinedDf.count()}"
      logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "load raw data", logMessage)
      refinedDf.show(5, false)
      //logInfo(s"Read data from $FinalRawPath: End")
      logMessage = s"Read data from $FinalRawPath: End"
      logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "load raw data", logMessage)
    } else if (refinedZoneProfile.tableCfg.getRawFileFormat == "parquet") {
      refinedDf = DataZoneUtilImpl.getDataFrameFromUriWithFilters(
        FinalRawPath,
        StorageFormat.Parquet,
        GenericValidator.getSchemaWithMetadata(refinedZoneProfile.tableCfg),
        GenericValidator.getRawWriteOptions(tableConfig = refinedZoneProfile.tableCfg),
        refinedZoneProfile.filterCondition,
      )
    }
    else {
      refinedDf = DataZoneUtilImpl.getDataFrameFromUriWithFilters(
        BaseValidDataPath,
        StorageFormat.Csv,
        GenericValidator.getSchemaWithMetadata(refinedZoneProfile.tableCfg),
        GenericValidator.getRawWriteOptions(tableConfig = refinedZoneProfile.tableCfg),
        refinedZoneProfile.filterCondition,
        addInputFilePath = false
      )
      //logInfo(s"dataframe count: ${refinedDf.count()}")
      logMessage = s"dataframe count: ${refinedDf.count()}"
      logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "load raw data", logMessage)
      refinedDf.show(5, false)
      logInfo(s"Read data from $FinalRawPath: End")
      logMessage = s"Read data from $FinalRawPath: End"
      logEntityJourneyEvent(refinedZoneProfile.entityName, DataZone.RefinedZone, zoneSubStep = "load raw data", logMessage)
    }

    refinedDf.show(10, false)
    return refinedDf
  }

}
