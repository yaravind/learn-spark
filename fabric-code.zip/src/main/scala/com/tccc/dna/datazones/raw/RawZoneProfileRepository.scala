package com.tccc.dna.datazones.raw

import com.tccc.dna.datazones.init.TableConfig
import com.tccc.dna.datazones.utils.DataZoneUtilImpl
import com.tccc.dna.datazones.validators._
import com.tccc.dna.synapse.StorageFormat
import org.apache.spark.sql.types.StructType

trait RawZoneProfileRepository {

  /**
   * Retrieves the RawZoneProfile for the specified entity.
   *
   * @param entityName The name of the entity for which the RawZoneProfile is requested.
   * @param tableConfig The [[TableConfig]] instance.
   * @return A RawZoneProfile instance corresponding to the specified entity name.
   */
  def getRawZoneProfile(entityName: String, tableConfig: TableConfig): RawZoneProfile

  /**
   * Retrieves the StructuralValidator for the specified entity.
   *
   * @param entityName The name of the entity for which the StructuralValidator is requested.
   * @return A StructuralValidator instance corresponding to the specified entity name.
   */
  def getRawStructuralValidator(entityName: String): StructuralValidator

//  def getRawSemanticValidator(entityName: String, yamlDataContractPath: Option[String]): SemanticValidator

  /**
   * Retrieves the SemanticValidator for the specified entity.
   *
   * @param entityName The name of the entity for which the SemanticValidator is requested.
   * @return A SemanticValidator instance corresponding to the specified entity name.
   */
  def getRawSemanticValidator(entityName: String): SemanticValidator

  /**
   * Return the storage format of the entity. This is used to select appropriate reader from Spark while reading the data.
   *
   * @param entityName Name of the entity.
   * @return Given the name of the entity, returns the format as enum. One of the constants defined in [[StorageFormat]].
   */
  def getEntityFormat(entityName: String): StorageFormat

  /**
   * Return the schema of the entity. This is used to validate the schema of the data while reading the data.
   *
   * @param entityName Name of the entity.
   * @param entityFormat Format of the entity.
   * @param tableConfig The [[TableConfig]] instance.
   * @return Given the name of the entity, returns the schema of the entity.
   */

  def getEntitySchema(entityName: String, entityFormat: StorageFormat, tableConfig: TableConfig): Option[StructType]

  /**
   * Return the landing options for the entity in JSON format.
   *
   * @param entityName Name of the entity.
   * @return Given the name of the entity, returns the landing options for the entity in JSON format.
   */

 def getJsonLandingOptions(entityName: String): Map[String, String]

    /**
    * Return the landing options for the entity in TSV format.
    *
    * @param entityName Name of the entity.
    * @return Given the name of the entity, returns the landing options for the entity in TSV format.
    */

 def getTsvLandingOptions(entityName: String): Map[String, String]

      /**
      * Return the landing options for the entity in CSV format.
      *
      * @param entityName Name of the entity.
      * @return Given the name of the entity, returns the landing options for the entity in CSV format.
      */

 def getCsvLandingOptions(entityName: String): Map[String, String]

  /**
   * Return the landing options for the entity in Parquet format.
   *
   * @param entityName Name of the entity.
   * @return Given the name of the entity, returns the landing options for the entity in CSV format.
   */

  def getParquetLandingOptions(entityName: String): Map[String, String] = ???


  /**
   * Retrieves the appropriate DataLoader based on the entity name.
   *
   * @param entityName The name of the entity for which the DataLoader is requested.
   * @return A DataLoader instance corresponding to the specified entity name.
   */
  def getLoader(entityName: String, tableConfig: TableConfig): DataLoader = {
    val jsonSchemaAsStr: Option[String] = Some(DataZoneUtilImpl.getSchemaAsString(entityName))
    val entityFormat: StorageFormat = getEntityFormat(entityName)
    val entitySchema: Option[StructType] = getEntitySchema(entityName, entityFormat, tableConfig)
    val cacheDf: Boolean = true

    val dataLoader: DataLoader = entityFormat match {
      case StorageFormat.JSON =>
        new JsonDataLoader(jsonSchemaAsStr, entitySchema, getJsonLandingOptions(entityName), cacheDf)
      case StorageFormat.Tsv =>
        new TsvDataLoader(entitySchema, getTsvLandingOptions(entityName), cacheDf)
      case StorageFormat.Csv =>
        new CsvDataLoader(entitySchema, getCsvLandingOptions(entityName), cacheDf)
      case StorageFormat.Parquet =>
        new ParquetDataLoader(entitySchema, getParquetLandingOptions(entityName), cacheDf)
    }
    dataLoader
  }
}