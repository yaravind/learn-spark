package com.tccc.dna.datazones.utils

import com.tccc.dna.synapse.spark.{DataFrames, SynapseSpark}
import com.tccc.dna.synapse.{Logging, StorageFormat}
import org.apache.commons.io.FileUtils
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, regexp_extract}
import org.apache.spark.sql.types._

import java.io.{File => javaFile}
import java.nio.file.{Files, Paths}

abstract class DataZoneUtil extends Logging {

  val dataTypeMap: Map[String, DataType] = Map(
    "String" -> StringType,
    "Integer" -> IntegerType,
    "Byte" -> ByteType,
    "Decimal" -> DecimalType(24, 12),
    "Long" -> LongType,
    "Short" -> ShortType,
    "TimeStamp" -> TimestampType,
    "Date" -> DateType,
    "String Array" -> ArrayType(StringType, containsNull = true)
  )

  /**
   * This method is used to get the dataframe with a filter condition
   *
   * @param pathUri          Path of the file to be read
   * @param fileFormat       File format of the file to be read
   * @param schema           Schema of the file to be read
   * @param readOptions      Additional options to be passed to the reader
   * @param readFilters      Filters to be applied to the dataframe
   * @param addInputFilePath Flag to add the input file path to the DataFrame
   * @param printExplainPlan Flag to print the explain plan of the DataFrame
   * @return
   */
  def getDataFrameFromUriWithFilters(
                                      pathUri: String,
                                      fileFormat: StorageFormat,
                                      schema: StructType,
                                      readOptions: Map[String, String],
                                      readFilters: Map[String, Array[String]] = Map.empty,
                                      addInputFilePath: Boolean = false,
                                      printExplainPlan: Boolean = false
                                    ): DataFrame = {
    val spark = SynapseSpark.getActiveSession
    logInfo(
      s"Reading from $pathUri as '${fileFormat.format}', readFilters: $readFilters",
      logToNotebook = true
    )

    var resultDf = spark.read
      .format(fileFormat.format)
      .options(readOptions)
      .schema(schema)
      .load(pathUri)

    resultDf = if (readFilters.nonEmpty) {
      // Build the filter condition
      val filterCondition = readFilters
        .map { case (colName, valueArray) =>

          valueArray
            .map(value => s"$colName = '$value'")
            .mkString(" or ")


        }
        .mkString(" and ")
      logInfo(s"Read filters are enabled. Applying condition: $filterCondition")
      // Apply the filter condition
      resultDf.filter(filterCondition)

    } else resultDf

    if (printExplainPlan) logInfo(s"${resultDf.queryExecution.executedPlan}")
    if (addInputFilePath) {
      DataFrames.addFileNameCol(DataFrames.addFilePathCol(resultDf))
    } else resultDf
  }


  /**
   * Read the dataframes from the given path and return a DataFrame.
   *
   * @param fileFormat       File format of the file to be read.
   * @param readOptions      Additional options to be passed to the reader.
   * @param addInputFilePath Flag to add the input file path to the DataFrame.
   * @param pathUris         Path of the file to be read.
   * @return
   */
  def getDataFrameFromUris(
                            fileFormat: StorageFormat,
                            readOptions: Map[String, String],
                            addInputFilePath: Boolean,
                            pathUris: Array[String]
                          ): DataFrame = {
    val spark = SynapseSpark.getActiveSession
    logInfo(s"Reading from ${pathUris.mkString(",")} as '${fileFormat.format}'")
    val df = spark.read
      .format(fileFormat.format)
      .options(readOptions)
      .load(pathUris: _*)

    if (addInputFilePath) {
      DataFrames.addFileNameCol(DataFrames.addFilePathCol(df))
    } else df
  }


  /**
   * This method is used to add audit_file_name column to the DataFrame
   *
   * @param df Input DataFrame
   * @return DataFrame with audit_file_path column
   */
  def addFileNameCol(df: DataFrame): DataFrame = {
    df.withColumn(
      "audit_file_name",
      regexp_extract(col("audit_file_path"), """[\/]([^\/]+[\/][^\/]+)$""", 1)
    )
  }

  /**
   * This method is used to explode the mentioned columns to individual rows
   *
   * @param resolvedColsToExplode Array of columns to be exploded
   * @param cfgRawToRefinedColMap Map of raw to refined column names
   * @param columnsToBeSelected   Columns to be selected
   * @param inputDf               Input DataFrame after explosion
   * @return
   */
  def explosion(
                 resolvedColsToExplode: Array[String],
                 cfgRawToRefinedColMap: Map[String, String],
                 columnsToBeSelected: Seq[String],
                 inputDf: DataFrame
               ): DataFrame = {
    inputDf.createOrReplaceTempView("tempDf")

    val sql = "select " + columnsToBeSelected
      .map(x => s"`$x`")
      .mkString(",") + " from tempDf\n" +
      resolvedColsToExplode
        .map(x => s"LATERAL VIEW OUTER explode(`$x`) AS ${x}_explode")
        .mkString("\n")
    logInfo("Explode sql:")
    println(sql)

    val explodedDf = SynapseSpark.getActiveSession.sql(sql)

    val droppedColDf =
      DataFrames.dropCols(explodedDf, resolvedColsToExplode.toList)

    def renameColumns(
                       df: DataFrame,
                       oldNewColNames: Array[(String, String)]
                     ): DataFrame = {
      oldNewColNames.foldLeft(df) { (tempDF, colName) =>
        tempDF.withColumnRenamed(colName._1, colName._2)
      }
    }

    val oldNewColNames = resolvedColsToExplode.map(x => (x + "_explode", x))

    val renamedDf = renameColumns(droppedColDf, oldNewColNames)

    renamedDf
  }


  /**
   * Copy files from a list of source paths to a destination path
   *
   * @param fromList       List of source paths
   * @param toDir          Destination path
   * @param overwriteFiles If true, will overwrite the destination file if exists
   */
  def copyFiles(
                 fromList: List[String],
                 toDir: String,
                 overwriteFiles: Boolean = true
               ): Unit = {
    if (SynapseSpark.isLocalEnv) {
      val targetDirPath = Paths.get(toDir)
      if (!Files.exists(targetDirPath)) {
        Files.createDirectories(targetDirPath)
      }
      val CreateDestDir = true

      for (from <- fromList) {
        //Remove file: prefix
        val fromFile =
          if (from.startsWith("file:"))
            new javaFile(from.substring(from.indexOf(":") + 1))
          else new javaFile(from)
        val toFile = new javaFile(toDir)

        if (overwriteFiles) {
          val targetFilePath = toFile + from.substring(from.lastIndexOf("/"))

          Files.deleteIfExists(Paths.get(targetFilePath))
        }
        FileUtils.copyFileToDirectory(fromFile, toFile, CreateDestDir)
      }

      fromList.map(file => {
        val arr = file.split("/")
        val fileName = arr.last
      })
    } else {
      val DoNotCopyRecursively =
        false
      for (from <- fromList) {
        mssparkutils.fs.cp(from, toDir, DoNotCopyRecursively)
      }
    }
  }

  /**
   * Copy files from a list of source paths to a list of destination paths
   *
   * @param fromList       List of source paths
   * @param toList         List of destination paths
   * @param overwriteFiles If true, will overwrite the destination file if exists
   */
  def copyFiles(
                 fromList: List[String],
                 toList: List[String],
                 overwriteFiles: Boolean
               ): Unit = {
    if (SynapseSpark.isLocalEnv) {
      var count = 0
      for (from <- fromList) {
        val tempDir = toList(count)
        val toDir = tempDir.substring(0, tempDir.lastIndexOf(("/")))
        val targetDirPath = Paths.get(toDir)
        if (!Files.exists(targetDirPath)) {
          Files.createDirectories(targetDirPath)
        }
        val CreateDestDir = true

        //Remove file: prefix
        val fromFile =
          if (from.startsWith("file:"))
            new javaFile(from.substring(from.indexOf(":") + 1))
          else new javaFile(from)
        val toFile = new javaFile(toDir)
        if (overwriteFiles) {
          val targetFilePath = toFile + from.substring(from.lastIndexOf("/"))
          logInfo(
            s"overwriteFiles set to true. Deleting from target dir: $targetFilePath"
          )
          Files.deleteIfExists(Paths.get(targetFilePath))
        }
        FileUtils.copyFileToDirectory(fromFile, toFile, CreateDestDir)
        logInfo(s"Copied [$from] to [$targetDirPath]")
        count = count + 1
      }
      fromList.map(file => {
        val arr = file.split("/")
        val fileName = arr.last
      })
    } else {
      //TODO: test it on Synapse
      var count = 0
      val DoNotCopyRecursively =
        false
      for (from <- fromList) {
        val tempDir = toList(count)
        val toDir = tempDir.substring(0, tempDir.lastIndexOf(("/")))
        mssparkutils.fs.mkdirs(toDir + "/")
        mssparkutils.fs.cp(from, toDir, DoNotCopyRecursively)
        logInfo(s"Copied [$from] to [$toDir]")
        println(s"Copied [$from] to [$toDir]")
        count = count + 1
      }
    }
  }

  /**
   * Move files from a list of source paths to a list of destination paths
   *
   * @param fromList       List of source paths
   * @param toList         List of destination paths
   * @param overwriteFiles If true, will overwrite the destination file if exists
   */
  def moveFiles(
                 fromList: List[String],
                 toList: List[String],
                 overwriteFiles: Boolean
               ): Unit = {
    if (SynapseSpark.isLocalEnv) {
      var count = 0
      for (from <- fromList) {
        val tempFile = toList(count)
        val toDir = tempFile.substring(0, tempFile.lastIndexOf(("/")))
        val targetDirPath = Paths.get(toDir)
        if (!Files.exists(targetDirPath)) {
          Files.createDirectories(targetDirPath)
        }
        val CreateDestDir = true
        //Remove file: prefix
        val fromFile =
          if (from.startsWith("file:"))
            new javaFile(from.substring(from.indexOf(":") + 1))
          else new javaFile(from)
        val toFile = new javaFile(toDir)
        if (overwriteFiles) {
          val targetFilePath = toDir
          logInfo(s"overwriteFiles set to true. Deleting from target dir: $targetFilePath")
          Files.deleteIfExists(Paths.get(tempFile))
        }
        FileUtils.moveFileToDirectory(fromFile, toFile, CreateDestDir)
        logInfo(s"Moved [$from] to [$targetDirPath]")
        count = count + 1
      }
      fromList.map(file => {
        val arr = file.split("/") //todo find a system agnostic file separator
        val fileName = arr.last
      })
    } else {
      var count = 0
      val CreateParentDir =
        true
      val OverwriteDestFolder =
        true
      for (from <- fromList) {
        val tempDir = toList(count)
        val toDir = tempDir.substring(0, tempDir.lastIndexOf(("/")))
        mssparkutils.fs.mkdirs(toDir + "/")
        mssparkutils.fs.mv(from, toDir, CreateParentDir, OverwriteDestFolder)
        count = count + 1
      }
    }
  }

  /**
   * Move files from a list of source paths to a destination directory
   *
   * @param fromList       List of source paths
   * @param toDir          Destination directory
   * @param overwriteFiles If true, will overwrite the destination file if exists
   */
  def moveFiles(
                 fromList: List[String],
                 toDir: String,
                 overwriteFiles: Boolean = true
               ): Unit = {
    if (SynapseSpark.isLocalEnv) {
      val targetDirPath = Paths.get(toDir)
      if (!Files.exists(targetDirPath)) {
        Files.createDirectories(targetDirPath)
      }
      val CreateDestDir = true
      for (from <- fromList) {
        //Remove file: prefix
        val fromFile =
          if (from.startsWith("file:"))
            new javaFile(from.substring(from.indexOf(":") + 1))
          else new javaFile(from)
        val toFile = new javaFile(toDir)
        if (overwriteFiles) {
          val targetFilePath = toFile + from.substring(from.lastIndexOf("/"))
          logInfo(
            s"overwriteFiles set to true. Deleting from target dir: $targetFilePath"
          )
          Files.deleteIfExists(Paths.get(targetFilePath))
        }
        FileUtils.moveFileToDirectory(fromFile, toFile, CreateDestDir)
        logInfo(s"Moved [$from] to [$targetDirPath]")
      }
      fromList.map(file => {
        val arr = file.split("/") //todo find a system agnostic file separator
        val fileName = arr.last
      })
    } else {
      //TODO: test it on Synapse
      val CreateParentDir =
        true //If true, will firstly create the parent dir if not exists before move op
      val OverwriteDestFolder =
        true //If true, will overwrite the destination folder if exists
      for (from <- fromList) {
        mssparkutils.fs.mv(from, toDir, CreateParentDir, OverwriteDestFolder)
      }
    }
  }

  /**
   * This method is used to get the final write options for the given entity name
   *
   * @param entityName Name of the entity
   * @return Map of write options
   */
  protected def getFinalWriteOptions(entityName: String): Map[String, String]

  /**
   * This method is used to get the raw schema for the given entity name
   *
   * @param entityName Name of the entity
   * @return Schema for the entity
   */

  protected def getFinalRawTableSchema(entityName: String): StructType

  /**
   * This method is used to get the Refine schema for the given entity name
   *
   * @param entityName Name of the entity
   * @return Schema for the entity
   */
  protected def getFinalRefinedTableSchema(entityName: String): StructType

  /**
   * This method is used to get the schema as string for the given entity name for json validation
   *
   * @param entityName Name of the entity
   * @return Schema as string
   */
  protected def getSchemaAsString(entityName: String): String

  /**
   * This method returns path of JSON contract file
   *
   * @param entityName Name of the entity
   * @return json contract file path
   */
  protected def getJsonSchemaResourcePath(entityName: String): String

}
