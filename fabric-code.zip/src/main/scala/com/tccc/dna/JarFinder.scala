package com.tccc.dna
import com.tccc.dna.synapse.AzStorage

object JarFinder {
  def findJarFileName(clazz: Class[_]): Option[String] = {
    val protectionDomain = clazz.getProtectionDomain
    if (protectionDomain != null) {
      val codeSource = protectionDomain.getCodeSource
      if (codeSource != null) {
        val location = codeSource.getLocation
        if (location != null) {
          return Some(location.getFile)
        }
      }
    }
    None
  }

  def main(args: Array[String]): Unit = {
    //get the current thread's context class loader
    val cl = Thread.currentThread.getContextClassLoader
    //get the classpath URLs
    val jarFileName = findJarFileName(cl.loadClass("com.tccc.dna.synapse.AzStorage"))
    println(s"JAR file: ${jarFileName.getOrElse("Not found")}")
  }
}
