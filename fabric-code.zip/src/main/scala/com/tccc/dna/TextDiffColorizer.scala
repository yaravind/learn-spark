package com.tccc.dna

object TextDiffColorizer {

  val LIGHT_YELLOW = "\u001b[103m"
  val LIGHT_GREEN = "\u001b[102m"
  val LIGHT_RED = "\u001b[101m"
  val LIGHT_CYAN = "\u001b[106m"
  val LIGHT_MAGENTA = "\u001b[105m"

  def highlightDiff(left: String, diff1: String, highlightColor: String) = {
    val highlightedStr1 = left.map { char =>
      if (diff1.contains(char)) highlightColor + char + "\u001b[0m" else char.toString
    }.mkString
    highlightedStr1
  }

  def printDiff(str1: String, str2: String, highlightColor: String = "\u001b[106m"): Unit = {
    val diff1 = str1.diff(str2)
    val diff2 = str2.diff(str1)

    val highlightedStr1 = highlightDiff(str1, diff1, highlightColor)
    val highlightedStr2 = highlightDiff(str2, diff2, highlightColor)

    println(highlightedStr1)
    println(highlightedStr2)
  }

  def printPositionalDiff(str1: String, str2: String, highlightColor: String = "\u001b[106m"): Unit = {
    val highlightedStr1: String = highlightPositionalDiff(str1, str2, highlightColor)
    val highlightedStr2 = highlightPositionalDiff(str2, str1, highlightColor)

    println(highlightedStr1)
    println(highlightedStr2)
  }

  def highlightPositionalDiff(str1: String, str2: String, highlightColor: String) = {
    val escapeChar = "\u001b"
    val resetEscapeChar = "\u001b[0m"

    val highlightedStr1 = str1.zipAll(str2, ' ', ' ').map {
      case (char1, char2) if char1 != char2 => s"$escapeChar$highlightColor" + char1 + s"$resetEscapeChar"
      case (char1, _) => char1.toString
    }.mkString
    highlightedStr1
  }
}
