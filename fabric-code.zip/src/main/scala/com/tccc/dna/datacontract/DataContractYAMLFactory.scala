package com.tccc.dna.datacontract

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory
import com.fasterxml.jackson.module.scala.{DefaultScalaModule, ScalaObjectMapper}
import com.google.common.io.Resources

import java.nio.charset.StandardCharsets
import scala.io.Source

/** *
 * Utility methods to work with data contract YAML files. Refer to [[https://datacontract.com/ datacontract.com]]
 */
object DataContractYAMLFactory {

  /**
   * Parse the data contract YAML. To be used locally from IDE.
   *
   * @param relativeFilePath Relative path from project folder.
   * @return Map[String, Any]
   */
  def parseFromFile(relativeFilePath: String): Map[String, Any] = {
    val src = Source.fromFile(relativeFilePath)
    val yamlContent = src.getLines.mkString("\n")
    parseFromString(yamlContent)
  }

  /**
   * Parse the data contract YAML. To be used on cluster.
   *
   * @param yamlContent Data contract YAML as [[String]]
   * @return Map[String, Any]
   */
  def parseFromString(yamlContent: String): Map[String, Any] = {
    val mapper = new ObjectMapper(new YAMLFactory) with ScalaObjectMapper
    mapper.registerModule(DefaultScalaModule)

    mapper.readValue[Map[String, Any]](yamlContent.getBytes)
  }

  /**
   * Returns the [[https://datacontract.com/#info-object Info object]] of the data contract YAML.
   *
   * @param root Output (or root of YAML) of [[parseFromString()]] or [[parseFromFile()]].
   * @return Map[String, String]
   */
  def getInfoObject(root: Map[String, Any]): Map[String, String] = {
    val info: Map[String, String] = root("info").asInstanceOf[Map[String, String]]
    info
  }

  /**
   * Returns the [[https://datacontract.com/#servers-object Servers object]] of the data contract YAML.
   *
   * @param root Output (or root of YAML) of [[parseFromString()]] or [[parseFromFile()]].
   * @return Map[String, String]
   */
  def getServersObject(root: Map[String, Any]): Map[String, String] = {
    val servers: Map[String, String] = root("servers").asInstanceOf[Map[String, String]]
    servers
  }

  /**
   * Returns the [[https://datacontract.com/#terms-object Terms object]] of the data contract YAML.
   *
   * @param root Output (or root of YAML) of [[parseFromString()]] or [[parseFromFile()]].
   * @return Map[String, String]
   */
  def getTermsObject(root: Map[String, Any]): Map[String, String] = {
    val terms: Map[String, String] = root("terms").asInstanceOf[Map[String, String]]
    terms
  }

  /**
   * Returns the [[https://datacontract.com/#schema-object Schema object]] of the data contract YAML.
   *
   * @param root Output (or root of YAML) of [[parseFromString()]] or [[parseFromFile()]].
   * @return Map[String, String]
   */
  def getSchemaObject(root: Map[String, Any]): Map[String, String] = {
    val schema: Map[String, String] = root("schema").asInstanceOf[Map[String, String]]
    schema
  }

  /**
   * Returns the [[https://datacontract.com/#quality-object Quality object]] of the data contract YAML.
   *
   * @param root Output (or root of YAML) of [[parseFromString()]] or [[parseFromFile()]].
   * @return Map[String, String]
   */
  def getQualityObject(root: Map[String, Any]): Map[String, String] = {
    val quality: Map[String, String] = root("quality").asInstanceOf[Map[String, String]]
    quality
  }

  /**
   * Returns the **specification** property of the [[https://datacontract.com/#schema-object Schema object]]. For e.g. this returns the full JSON Schema as [[String]].
   *
   * @param schemaObj Map[String, String] as returned by [[getSchemaObject()]].
   * @return JSON Schema embedded in data contract YAML as [[String]].
   */
  def getSchemaSpecification(schemaObj: Map[String, String]): String = {
    Source.fromString(schemaObj("specification")).mkString
  }

  /**
   * Returns the JSON Schema embedded in the [[https://datacontract.com/ datacontract YAML]].
   *
   * @param resourcePath Relative path to the classpath. If you have datacontract.yaml in `src/main/resources/contracts` folder then pass `contracts/datacontract.yaml`.
   * @return JSON Schema as String
   */
  def getJsonSchemaAsStr(resourcePath: String): String = {
    val dataContractUrl = Resources.getResource(resourcePath)
    val contractYaml = Resources.toString(dataContractUrl, StandardCharsets.UTF_8)

    val schemaYaml = DataContractYAMLFactory.getSchemaObject(DataContractYAMLFactory.parseFromString(contractYaml))
    val jsonSchemaAsStr = DataContractYAMLFactory.getSchemaSpecification(schemaYaml)
    jsonSchemaAsStr
  }
}