package com.tccc.dna.datacontract

import com.tccc.dna.synapse.Logging
import org.apache.spark.sql.DataFrame
import com.amazon.deequ.{VerificationResult, VerificationSuite}
import com.amazon.deequ.checks.{Check, CheckLevel, CheckStatus}
import com.amazon.deequ.constraints.ConstraintStatus

import scala.util.matching.Regex

object DataQualityValidator extends Logging {
  val a: Regex = """\d""".r
  def validate(inputDf: DataFrame, validationName: String): VerificationResult = {

    val nonNullCols = Seq("asset_id", "asset_name", "asset_title", "event_created_by", "asset_creation_timestamp", "original_asset_path", "event_type",
      "asset_size", "mime_type", "event_creation_timestamp")
    val verificationResult = VerificationSuite()
      .onData(inputDf)
      .addCheck(
        Check(CheckLevel.Error, validationName)
          //.hasSize(_ == 5) // we expect 5 rows
          // should never be NULL
          .isComplete("asset_id")
        /*// should not contain duplicates
        .isUnique("id")
        // should never be NULL
        .isComplete("productName")
        // should only contain the values "high" and "low"
        .isContainedIn("priority", Array("high", "low"))
        // should not contain negative values
        .isNonNegative("numViews")
        // at least half of the descriptions should contain a url
        .containsURL("description", _ >= 0.5)
        // half of the items should have less than 10 views
        .hasApproxQuantile("numViews", 0.5, _ <= 10)*/)
      .run()

    verificationResult
  }

  def printVerificationResults(result: VerificationResult): Unit = {

    if (result.status == CheckStatus.Success) {
      println("The data passed the test, everything is fine!")
    } else {
      println("We found errors in the data:\n")

      val resultsForAllConstraints = result.checkResults
        .flatMap { case (_, checkResult) => checkResult.constraintResults }

      resultsForAllConstraints
        .filter {
          _.status != ConstraintStatus.Success
        }
        .foreach { result => println(s"${result.constraint}: ${result.message.get}") }
    }

  }
}