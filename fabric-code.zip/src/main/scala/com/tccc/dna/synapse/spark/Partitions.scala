package com.tccc.dna.synapse.spark

import com.tccc.dna.synapse.Logs._
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.TableIdentifier
import org.apache.spark.sql.functions.{col, collect_list}

object Partitions {
  @transient private val log: Logger = LogManager.getLogger(getClass.getName.stripSuffix("$"))

  /** Returns '''in-memory''' partition count.
    *
    * @param df
    *   input.
    * @return
    *   in-memory partition count.
    */
  def getNumPartitionsInMem(df: DataFrame): Int = df.rdd.getNumPartitions

  /** Use to get the total # of records for each '''memory''' partition.
    *
    * @param df
    *   input.
    * @return
    *   [[DataFrame]] with two columns: partition_id and record_count
    */
  def getRecordsPerPartitionInMem(df: DataFrame): DataFrame = {
    import org.apache.spark.sql.functions.spark_partition_id
    df.withColumn("partition_id", spark_partition_id)
      .groupBy("partition_id")
      .count
      .withColumnRenamed("count", "record_count")
  }

  /** Check if a '''SQL table''' is partitioned.
    *
    * You can check if a table in a Spark SQL data source is partitioned by examining the metadata of the table.
    *
    * {{{
    *  if(isTablePartitioned("test.emp_table")) {
    *      println("Table is partitioned. Partition cols:")
    *      println(getPartitionColumns(spark,"test.emp_table"))
    *  } else {
    *      println("--NO_PARTITIONS--")
    *  }
    * }}}
    *
    * @param table
    *   name of the Spark table. Format: 'schema_name.table_name'.
    * @return
    *   'true' if table is partitioned, 'false' otherwise.
    */
  def isTablePartitioned(schemaOrDb: String, table: String): Boolean = {
    logDebug(log, s"Input Schema: $schemaOrDb, table: $table")

    getPartitionCols(schemaOrDb, table).nonEmpty
  }

  private def getPartitionCols(schemaOrDb: String, table: String): Seq[String] = {
    val spark     = SynapseSpark.getActiveSession
    val currentDb = spark.catalog.currentDatabase
    logDebug(log, s"Current Db: $currentDb")

    Catalogs.switchToDatabase(schemaOrDb)

    val metadata      = spark.sessionState.catalog.getTableMetadata(TableIdentifier(table))
    var partitionCols = Seq[String]()

    if (Catalogs.isDeltaFormat(schemaOrDb, table)) {
      // Try 1 - Doesn't work
      /*
      val location = metadata.location.toString
      logDebug(log, s"$table path: $location")
      val deltaTable = DeltaTable.forPath(spark, location)
      logDebug(log, s"--------> ${metadata.tracksPartitionsInCatalog}")
      partitionCols = metadata.partitionColumnNames
       */

      // Try 2 - Doesn't work. Fails with java.util.NoSuchElementException: next on empty iterator
      /*
      val deltaTable = DeltaTable.forName(spark, table)
      val metadata = deltaTable.toDF.queryExecution.analyzed.collect { case t: org.apache.spark.sql.catalyst.catalog.CatalogTable => t }.head
      val partitionColumns = metadata.partitionColumnNames
       */

      // Try 3 - Doesn't work. Fails with partitionColumns isn't a member of DeltaTable
      /*
      val location = metadata.location.toString
      val deltaTable = DeltaTable.forPath(spark, location)
      partitionCols = deltaTable.partitionColumns
       */

      // Try 4 - Works for Delta
      // TODO Replace contains with regex
      /*
      The partition columns are printed under "# Partitioning" section with col_names as Part #. For e.g.
      If a table is partitioned by 2 columns namely year and month then the dataframe has following
      rows related to partitioning

      Row n   : # Partitioning
      Row n+1 : Part 0          year
      Row n+2 : Part 1          month
       */
      val rows = spark
        .sql(s"DESCRIBE FORMATTED $table")
        // col("col_name").contains("# Partitioning") ||
        .filter(col("col_name").contains("Part "))
        .select("col_name", "data_type")
        .collect

      partitionCols = rows.map(row => row.getString(1))
    } else {
      // Parquet
      partitionCols = metadata.partitionColumnNames
    }

    Catalogs.switchToDatabase(currentDb)

    partitionCols
  }

  /** Get the name of '''SQL table''' partition column(s).
    *
    * @param table
    *   name of the Spark table. Format: 'schema_name.table_name'.
    * @return
    *   comma separated list of partition columns if the table is partitioned, empty string otherwise.
    */
  def getTablePartitionCols(schemaOrDb: String, table: String): String = {
    val partitionCols = getPartitionCols(schemaOrDb, table)

    if (partitionCols.nonEmpty) {
      logDebug(log, s"$table is partitioned by columns: " + partitionCols.mkString(", "))
    } else {
      logDebug(log, s"$table is not partitioned.")
    }
    partitionCols.mkString(", ")
  }

  /** Check if a '''Parquet file''' is partitioned.
    *
    * You can check if a Parquet file is partitioned by reading its schema and checking for partition columns.
    *
    * {{{
    *  if(isParquetFilePartitioned("/path/to/file")) {
    *      println("File is partitioned. Partition cols:")
    *      println(getParquetFilePartitionColumns(/path/to/file))
    *  } else {
    *      println("--NO_PARTITIONS--")
    *  }
    * }}}
    *
    * @param pathToFile
    *   path to the parquet file.
    * @return
    *   'true' if file is partitioned, 'false' otherwise.
    */
  def isParquetFilePartitioned(pathToFile: String): Boolean = {
    val spark = SynapseSpark.getActiveSession
    val df    = spark.read.parquet(pathToFile)

    val path = new Path(pathToFile)
    // Check if the file is partitioned
    val is_partitioned = df.isStreaming ||
      df.rdd.getNumPartitions > 1 ||
      FileSystem.get(path.toUri, spark.sparkContext.hadoopConfiguration).getFileStatus(path).isDirectory

    is_partitioned
  }

  /** TODO Works with Delta 2.0 API Check if a '''Delta file''' is partitioned.
    *
    * You can check if a Delta file is partitioned by reading table details as explained here
    * https://docs.delta.io/latest/delta-utility.html#retrieve-delta-table-details.
    *
    * {{{
    *  if(isPDeltaFilePartitioned("/path/to/file")) {
    *      println("File is partitioned. Partition cols:")
    *      println(getDeltaFilePartitionColumns(/path/to/file))
    *  } else {
    *      println("--NO_PARTITIONS--")
    *  }
    * }}}
    *
    * @param pathToFile
    *   path to the parquet file.
    * @return
    *   'true' if file is partitioned, 'false' otherwise.
    */
  def isDeltaFilePartitioned(pathToFile: String): Boolean = {
    val spark = SynapseSpark.getActiveSession
    val df    = spark.read.parquet(pathToFile)

    val path = new Path(pathToFile)
    // Check if the file is partitioned
    /*val deltaTable = DeltaTable.forPath(spark, pathToFile)
    val detailDF = deltaTable.detail()
    val partitionCols=detailDF.select("partitionColumns").collect
    if (partitionCols.nonEmpty) {
      logDebug(log, s"$table is partitioned by columns: " + partitionCols.mkString(", "))
    } else {
      logDebug(log, s"$table is not partitioned.")
    }
    partitionCols.mkString(", ")*/
    val is_partitioned = false

    is_partitioned
  }

  /** Check if a '''Parquet file''' is partitioned.
    *
    * You can check if a Parquet file is partitioned by reading its schema and checking for partition columns.
    *
    * {{{
    *  if(isParquetFilePartitioned("/path/to/file")) {
    *      println("File is partitioned. Partition cols:")
    *      println(getParquetFilePartitionColumns(/path/to/file))
    *  } else {
    *      println("--NO_PARTITIONS--")
    *  }
    * }}}
    *
    * @param pathToFile
    *   path to the parquet file.
    * @return
    *   'true' if file is partitioned, 'false' otherwise.
    */
  def isParquetFilePartitionedOld(pathToFile: String): Boolean = {
    val spark = SynapseSpark.getActiveSession
    val df    = spark.read.parquet(pathToFile)
    /*
    The filter and map methods are used to extract the names of the columns that have a metadata key of "isPartition",
    which indicates that the column is a partition column in the Parquet file.
    If the resulting list of partition columns is non-empty, the Parquet file is considered to be partitioned.
     */
    val partitionColumns = df.schema.filter(f => f.metadata.contains("isPartition")).map(_.name)

    partitionColumns.nonEmpty
  }

  /** TODO This should be defined for Spark 3.3/Delta 2.0. See [[isDeltaFilePartitioned()]]
    *
    * @param pathToFile
    *   Path to the parquet file.
    * @return
    *   Comma separated list of partition columns if the file is partitioned, empty string otherwise.
    */
  def getDeltaFilePartitionCols(pathToFile: String): String = { "" }

  /** Get the names of '''Parquet''' partition column(s).
    *
    * @param pathToFile
    *   Path to the parquet file.
    * @return
    *   Comma separated list of partition columns if the file is partitioned, empty string otherwise.
    */
  def getParquetFilePartitionCols(pathToFile: String): String = {
    val spark = SynapseSpark.getActiveSession
    val df    = spark.read.parquet(pathToFile)
    /*
    The filter and map methods are used to extract the names of the columns that have a metadata key of "isPartition",
    which indicates that the column is a partition column in the Parquet file.
    If the resulting list of partition columns is non-empty, the Parquet file is considered to be partitioned.
     */
    val partitionCols = df.schema.filter(f => f.metadata.contains("isPartition")).map(_.name)

    if (partitionCols.nonEmpty) {
      logDebug(log, s"$pathToFile is partitioned by columns: " + partitionCols.mkString(", "))
    } else {
      logDebug(log, s"$pathToFile is not partitioned.")
    }
    partitionCols.mkString(", ")
  }

  /** Check if a '''CSV file''' is partitioned.
    *
    * You can check if a CSV file is partitioned by checking if the path is a directory.
    *
    * {{{
    *  if(isCsvFilePartitioned("/path/to/file")) {
    *      println("CSV is partitioned. Partition cols:")
    *      println(getCsvPartitionColumns("/path/to/file"))
    *  } else {
    *      println("--NO_PARTITIONS--")
    *  }
    * }}}
    *
    * @param pathToFile
    *   path to the CSV file.
    * @return
    *   'true' if file is partitioned, 'false' otherwise.
    */
  def isCsvFilePartitioned(pathToFile: String): Boolean = {
    val spark = SynapseSpark.getActiveSession
    val df    = spark.read.format("csv").load(pathToFile)

    val path = new Path(pathToFile)
    // Check if the file is partitioned
    val is_partitioned = df.isStreaming ||
      df.rdd.getNumPartitions > 1 ||
      FileSystem.get(path.toUri, spark.sparkContext.hadoopConfiguration).getFileStatus(path).isDirectory
    /* The following fails with warning: method isDirectory in class FileSystem is deprecated
    FileSystem.get(spark.sparkContext.hadoopConfiguration, new Path(pathToFile)).isDirectory(new Path(pathToFile))*/

    is_partitioned
  }

  def isCsvFilePartitionedOld(pathToFile: String): Boolean = {
    val spark = SynapseSpark.getActiveSession
    val df    = spark.read.format("csv").load(pathToFile)

    // Check if the file is partitioned
    val isPartitioned = df.isStreaming ||
      df.rdd.getNumPartitions > 1 ||
      FileSystem
        .get(new Path(pathToFile).toUri, spark.sparkContext.hadoopConfiguration)
        .isDirectory(new Path(pathToFile))
    // FileSystem.get(spark.sparkContext.hadoopConfiguration, new Path(pathToFile)).isDirectory(new Path(pathToFile))
    /*
    TODO Use the following simple code to find if the given path is a directory
    import com.microsoft.spark.notebook.msutils.MSFileInfo

        val tables : Array[MSFileInfo] = mssparkutils.fs.ls("/synapse/workspaces/syn-tccc-cdl-use2-dev-01/warehouse/vbc.db")
        val tableOne = tables(0)
        println("Table name: "+tableOne.name)
        println("Is Directory: "+tableOne.isDir)
        println("Is file: "+tableOne.isFile)
     */
    isPartitioned
  }

  /** Get the names of '''CSV''' partition column(s).
    *
    * @param pathToFile
    *   path to the CSV file.
    * @return
    *   comma separated list of partition columns if the file is partitioned, empty string otherwise.
    */
  def getCsvFilePartitionCols(pathToFile: String): String = {
    val spark = SynapseSpark.getActiveSession
    val df    = spark.read.format("csv").load(pathToFile)

    // Get the input file paths
    val inputFiles = df.inputFiles
    logDebug(log, s"input file path count: ${inputFiles.length}")

    // Parse the input file paths to extract the partition column names
    val partitionCols =
      inputFiles.head.split(pathToFile)(1).split("/").filter(_.contains("=")).map(_.split("=")(0)).toList

    if (partitionCols.nonEmpty) {
      logDebug(log, s"The $pathToFile is partitioned on the following columns:")
      partitionCols.foreach(println)
    } else {
      logDebug(log, s"The $pathToFile file is not partitioned.")
    }
    partitionCols.mkString(", ")
  }

  /** Use to find out if a table is partitioned '''on-disk'''.
    *
    * You can check if a table in a Spark SQL data source is partitioned by examining the metadata of the table.
    *
    * {{{
    *  if(isTablePartitioned("test.emp_table")) {
    *      println("Table is partitioned. Partition cols:")
    *      println(getPartitionColumns(spark,"test.emp_table"))
    *  } else {
    *      println("--NO_PARTITIONS--")
    *  }
    * }}}
    *
    * @param table
    *   name of the Spark table. Format: 'schema_name.table_name'.
    * @return
    *   'true' if table is partitioned, 'false' otherwise.
    */
  def isTablePartitionedOld(table: String): Boolean = {
    val spark = SynapseSpark.getActiveSession
    import spark.implicits._ // Needed to fix error: No implicit arguments of type: Encoder[Array[String]]
    val colDetails = spark
      .sql(s" describe extended $table ")
      .select("col_name")
      .select(collect_list(col("col_name")))
      .as[Array[String]]
      .first
    // colDetails.foreach(println)
    colDetails.exists(x => x.contains("# Partition Information"))
  }

  /** Use to get the name of '''on-disk''' partition column(s).
    *
    * @param table
    *   name of the Spark table. Format: 'schema_name.table_name'.
    * @return
    *   comma separated list of partition columns if the table is partitioned, empty string otherwise.
    */
  def getPartitionColsOld(table: String): String = {
    val spark = SynapseSpark.getActiveSession

    import spark.implicits._ // Needed to fix error: No implicit arguments of type: Encoder[Array[String]]
    val pat = """(?ms)^\s*#( Partition Information)(.+)(Detailed Table Information)\s*$""".r
    val colDetails = spark
      .sql(s" describe extended $table ")
      .select("col_name")
      .select(collect_list(col("col_name")))
      .as[Array[String]]
      .first

    val colDetails2 = colDetails.filter(_.trim.nonEmpty).mkString("\n")

    val arr = pat
      .findAllIn(colDetails2)
      .matchData
      .collect { case pat(a, b, c) => b }
      .toList
      .head
      .split("\n")
      .filterNot(x => x.contains("#"))
      .filter(_.nonEmpty)
    arr.mkString(",")
  }

  def selectCoalesceOrRepartition(df: DataFrame, numPartitions: Int): DataFrame = {
    var tempDf = df
    numPartitions match {
      case n if n == 1 =>
        tempDf = df.coalesce(1)
        logDebug(log, s"Coalescing to single partition before save")
      case n if n > 1 =>
        tempDf = df.repartition(numPartitions)
        logDebug(log, s"Repartitioning to $numPartitions before save")

      case _ => logDebug(log, s"Keeping current partitions before save: ${df.rdd.getNumPartitions}")
    }

    tempDf
  }
}
