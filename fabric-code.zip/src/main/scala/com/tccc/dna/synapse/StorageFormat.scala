package com.tccc.dna.synapse

sealed abstract class StorageFormat(val format: String)

object StorageFormat {
  final case object Parquet extends StorageFormat(format = "parquet")

  final case object Delta extends StorageFormat(format = "delta")

  final case object Csv extends StorageFormat(format = "csv")

  final case object Tsv extends StorageFormat(format = "csv")

  final case object JSON extends StorageFormat(format = "json")

  final case object Text extends StorageFormat(format = "text")
}