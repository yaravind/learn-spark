package com.tccc.dna.synapse.spark

import java.net.URL

object Classpath {
  private lazy val classpath: Array[URL] = {
    val classpath = System.getProperty("java.class.path")
    classpath.split(java.io.File.pathSeparator).map(new java.io.File(_).toURI.toURL)
  }

  /** Number of dependencies in the classpath of current cluster.
   *
   * @return
   * count of jar files in cluster's classpath.
   */
  def getAllDependencyCount: Int = getAllDependencies.length

  def getAllDependencies: Array[URL] = {
    classpath
  }

  /**
   * Number of Fabric specific dependencies in the classpath of current cluster.
   *
   * @return count of Fabric jar files in cluster's classpath.
   */
  def getFabricDependencyCount: Int = getFabricDependencies.length


  /**
   * Get Fabric specific dependencies in the classpath of current cluster.
   *
   * @return
   */
  def getFabricDependencies: Array[URL] = {
    classpath.filter(_.toString.contains("fabric"))
  }


  /** Number of Synapse specific dependencies in the classpath of current cluster.
   *
   * @return
   * count of Synapse jar files in cluster's classpath.
   */
  def getSynapseDependencyCount: Int = getSynapseDependencies.length

  def getSynapseDependencies: Array[URL] = {
    classpath.filter(_.toString.contains("synapse"))
  }

  /** Number of Azure specific dependencies in the classpath of current cluster.
   *
   * @return
   * count of Azure jar files in cluster's classpath.
   */
  def getAzureDependencyCount: Int = getAzureDependencies.length

  def getAzureDependencies: Array[URL] = {
    classpath.filter(_.toString.contains("azure"))
  }

  /** Number of Microsoft (non Synapse and Azure) specific dependencies in the classpath of current cluster.
   *
   * @return
   * count of Microsoft jar files in cluster's classpath.
   */
  def getMicrosoftDependencyCount: Int = getMicrosoftDependencies.length

  def getMicrosoftDependencies: Array[URL] = {
    classpath.filter(_.toString.contains("microsoft"))
  }

  /** Number of Azure connector specific dependencies in the classpath of current cluster. Use this to understand
   * out-of-box Spark connectors provided by Synapse Spark Pool.
   *
   * @return
   * count of Microsoft jar files in cluster's classpath.
   */
  def getAzureConnectorDependencyCount: Int = getAzureConnectorDependencies.length

  def getAzureConnectorDependencies: Array[URL] = {
    classpath.filter(_.toString.contains("connector"))
  }

  /** Number of logger dependencies in the classpath of current cluster.
   *
   * @return
   * count of logging related jar files in cluster's classpath.
   */
  def getLogDependencyCount: Int = getLogDependencies.length

  def getLogDependencies: Array[URL] = {
    classpath.filter(s => s.toString.contains("log") && !s.toString.contains("catalog"))
  }

  /** Number of additional dependencies added my Azure to open source Apache Spark in the classpath of current cluster.
   *
   * @return
   * count of Microsoft jar files in cluster's classpath.
   */
  def getNonOpenSourceSparkDependencyCount: Int = getNonOpenSourceSparkDependencies.length

  def getNonOpenSourceSparkDependencies: Array[URL] = classpath.filter {
    case s: URL
      if s.toString.contains("azure") || s.toString.contains("microsoft")
        || s.toString.contains("synapse") || s.toString.contains("connector") =>
      true
    case _ => false
  }

  /** Number of Coke/KO dependencies in the classpath of current cluster.
   *
   * @return
   * count of KO/TCCC/Coke related jar files in cluster's classpath.
   */
  def getCokeTCCCDependencyCount: Int = getCokeTCCCDependencies.length

  def getCokeTCCCDependencies: Array[URL] = classpath.filter {
    case s: URL
      if s.toString.contains("tccc") || s.toString.contains("coke")
        || s.toString.contains("ko") || s.toString.contains("ssdp") =>
      true
    case _ => false
  }

  val cl2 = ClassLoader.getSystemClassLoader
}
