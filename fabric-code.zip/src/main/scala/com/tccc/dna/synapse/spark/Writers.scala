package com.tccc.dna.synapse.spark

import com.tccc.dna.synapse.{AzStorage, StorageFormat}
import com.tccc.dna.synapse.StorageFormat.{Csv, Delta, JSON, Parquet}
import com.tccc.dna.synapse.Utils._
import io.delta.tables.DeltaTable
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.sql.{DataFrame, SaveMode}

import java.nio.charset.StandardCharsets

/**
 * Encapsulates helper methods used for writing to storage systems.
 * Save modes:
 * <uL
 * <li>append:</li>
 * <li>verwrite</li>
 * <li>ignore</li>
 * <li>errorifexists</li>
 * </ul>
 *
 * @author Aravind Yarram
 */
object Writers {
  @transient private val log: Logger =
    LogManager.getLogger(getClass.getName.stripSuffix("$"))

  def initialLoad(df: DataFrame,
                  dbOrSchemaName: String,
                  tableName: String,
                  fileFormat: StorageFormat = StorageFormat.Delta,
                  saveMode: SaveMode = SaveMode.Overwrite,
                  numPartitions: Int = -1,
                  partitionColNames: Array[String] = Array.empty[String],
                  dbComment: String = "Not provided by caller.",
                  otherWriterOpts: Map[String, String] = Map.empty): Unit = {
    saveAsManagedTable(
      df,
      dbOrSchemaName,
      tableName,
      fileFormat,
      SaveMode.Overwrite,
      numPartitions,
      partitionColNames,
      dbComment,
      otherWriterOpts
    )
  }

  def incrementalAppend(df: DataFrame,
                        dbOrSchemaName: String,
                        tableName: String,
                        numPartitions: Int = -1): Unit = {
    saveAsManagedTable(
      df,
      dbOrSchemaName = dbOrSchemaName,
      tableName = tableName,
      numPartitions = numPartitions,
      saveMode = SaveMode.Append
    )
  }

  def incrementalOverwrite(df: DataFrame,
                           dbOrSchemaName: String,
                           tableName: String,
                           numPartitions: Int = -1): Unit = {
    saveAsManagedTable(
      df,
      dbOrSchemaName = dbOrSchemaName,
      tableName = tableName,
      numPartitions = numPartitions,
      saveMode = SaveMode.Overwrite
    )
  }

  /**
   * Use for seeding and feeding of data into a '''managed table'''.
   * <ul>
   * <li>Seeding: Initial load to the table. Uses '''saveAsTable'''.</li>
   * <li>Feeding: Incremental load to the table. Uses '''insertInto'''.</li>
   * </ul>
   *
   * This method takes advantage of dynamic overwrite. This feature lets you overwrite a specific partition in a
   * partitioned table. For example, if your table is partitioned by '''year''' and you want to update only one year,
   * then with '''saveAsTable''' you would have to overwrite the entire table, but with '''insertInto''', you can __overwrite
   * only this single partition__ so it will be a much cheaper operation especially if there are lots of big partitions.
   *
   * '''insertInto''' uses the order of the columns instead of the names. So, you should guarantee that always have the
   * same number of columns and keep them in the same insertion order.
   *
   * @note When feeding, make sure the column order in input DataFrame is same as the column order of the existing table.
   * @note The data types are different in input DataFrame and can't be safely cast.
   * @param df                [[DataFrame]] to be loaded.
   * @param dbOrSchemaName    Name of the spark schema/database.
   * @param tableName         Name of the '''managed table''' to be created under the specified schema.
   * @param fileFormat        Optional. [[StorageFormat.Delta]] by default.
   * @param saveMode          Optional. Defaults to '''ErrorIfExists'''.
   * @param numPartitions     Optional. Number of partitions to write. '''-1''' by default which means it honors the partition of the DataFrame being saved.
   * @param partitionColNames [[Array]] of one or more partition columns.
   * @param dbComment         comment to be added while creating the table. Applicable only during seeding.
   * @param otherWriterOpts   Optional. Additional write options.
   * @throws IllegalArgumentException when pre-conditions (see `note`'s in ScalaDoc for pre-condition list.
   */
  def saveAsManagedTable(
                          df: DataFrame,
                          dbOrSchemaName: String,
                          tableName: String,
                          fileFormat: StorageFormat = StorageFormat.Delta,
                          saveMode: SaveMode = SaveMode.ErrorIfExists,
                          numPartitions: Int = -1,
                          partitionColNames: Array[String] = Array.empty[String],
                          dbComment: String = "Not provided by caller.",
                          otherWriterOpts: Map[String, String] = Map.empty
                        ): Unit = {
    //Check pre-conditions
    require(
      fileFormat.equals(StorageFormat.Delta) || fileFormat.equals(
        StorageFormat.Parquet
      ),
      "StorageFormat can be one of Delta or Parquet."
    )
    val inMemPartitions = Partitions.getNumPartitionsInMem(df)
    println(s"Input dataframe in-memory partition count: $inMemPartitions")
    val spark = SynapseSpark.getActiveSession

    val fullTableName = s"$dbOrSchemaName.$tableName"
    println(
      s"""Saving as : $fullTableName, at location: ${
        spark.conf.get(
          "spark.sql.warehouse.dir"
        )
      },
         | with partition cols: ${
        partitionColNames
          .mkString(", ")
      } and save mode: $saveMode""".stripMargin)

    if (!spark.catalog.databaseExists(dbOrSchemaName)) {
      //TODO doesn't work when running job as a managed identity
      //TODO check which of the following doesn't work when run as managed identity
      val userName = getOrElse(mssparkutils.env.getUserName()) //Email Id when NOT run as managed identity
      val userUUID = getOrElse(mssparkutils.env.getUserId())
      val jobId = getOrElse(mssparkutils.env.getJobId()) //Livy Session ID
      val pool = getOrElse(mssparkutils.env.getPoolName())
      val workspace = getOrElse(mssparkutils.env.getWorkspaceName())
      val clusterUUID = getOrElse(mssparkutils.env.getClusterId())

      println(
        s"""Database '$dbOrSchemaName' doesn't exist. Creating with props (
           | createdByName = '$userName',
           | createdById = '$userUUID',
           | jobId = '$jobId',
           | sparkPool = '$pool',
           | workspaceName  = '$workspace',
           | clusterId = '$clusterUUID'
           |).""".stripMargin
      )

      spark.sql(
        s"""CREATE DATABASE IF NOT EXISTS $dbOrSchemaName
           |COMMENT '$dbComment'
           |WITH DBPROPERTIES (
           | createdByName = '$userName',
           | createdById = '$userUUID',
           | jobId = '$jobId',
           | sparkPool = '$pool',
           | workspaceName  = '$workspace',
           | clusterId = '$clusterUUID'
           |)
           |""".stripMargin)
    }
    val tempDf = Partitions.selectCoalesceOrRepartition(df, numPartitions)

    if (!spark.catalog.tableExists(fullTableName)) {
      println(s"Table '$fullTableName' doesn't exist. Creating it.")
      //TODO figure out how to sepcify comments and properties at table level
      tempDf.write
        .partitionBy(partitionColNames: _*)
        .format(fileFormat.format)
        .options(otherWriterOpts)
        .option("encoding", StandardCharsets.UTF_8.name())
        .mode(saveMode)
        .saveAsTable(fullTableName)
    } else {
      //Raises "AnalysisException: Table not found." if the table already doesn't exist
      println(
        s"$fullTableName already exists in catalog. Operation: $saveMode."
      )
      tempDf.write
        //.partitionBy(partitionCol) Not required as the information is available in catalog
        //.format(fileFormat.format) Not required as the information is available in catalog
        .options(otherWriterOpts)
        .option("partitionOverwriteMode", "dynamic") //The dynamic value makes sure that Spark will overwrite only partitions that we have data for in our DataFrame.
        .option("encoding", StandardCharsets.UTF_8.name())
        .mode(saveMode) //mode is not needed as it is "Append" by default
        .insertInto(fullTableName)
    }
  }

  /**
   * When writing a dataframe to delta format, the 'nullable' property of a field ise always 'true' in the resulting
   * delta file regardless of the source dataframe schema. This behavior can be prevented using a catalog, that will
   * validate that the dataframe follows the expected schema.
   *
   * Reason: Parquet, the underlying format of delta lake, can't guarantee the nullability of the column.
   * MERGE INTO target_table_name [target_alias]
   * USING source_table_reference [source_alias]
   * ON merge_condition
   * { WHEN MATCHED [ AND matched_condition ] THEN matched_action |
   * WHEN NOT MATCHED [BY TARGET] [ AND not_matched_condition ] THEN not_matched_action |
   * WHEN NOT MATCHED BY SOURCE [ AND not_matched_by_source_condition ] THEN not_matched_by_source_action } [...]
   *
   * merge_condition = How the rows from one relation are combined with the rows of another relation. An expression with a return type of BOOLEAN
   *
   * matched_action
   * { DELETE |
   * UPDATE SET * |
   * UPDATE SET { column = { expr | DEFAULT } } [, ...] }
   *
   * not_matched_action
   * { INSERT * |
   * INSERT (column1 [, ...] ) VALUES ( expr | DEFAULT ] [, ...] )
   *
   * not_matched_by_source_action
   * { DELETE |
   * UPDATE SET { column = { expr | DEFAULT } } [, ...] }
   *
   * @param targetPath         path to the target delta table.
   * @param sourceDf           input data to be merged.
   * @param mergeOnCols        list of columns to merge on.
   * @param partitionPruneCols Optional [[List]] of partition columns. Used for partition pruning to improve merge performance with large datasets.
   * @param insertExcludeCols  [[List]] of columns to be excluded from '''NEW rows''' during merge.
   * @param updateExcludeCols  [[List]] of columns to be excluded from '''UPDATED rows''' during merge.
   * @param customInsertExpr   Rules to apply during a new row insert as a Scala map between target column names and corresponding update expressions as SQL formatted strings.
   * @param customUpdateExpr   Rules to update a row as a Scala map between target column names and corresponding update expressions as SQL formatted strings.
   */
  def upsert(targetPath: String,
             sourceDf: DataFrame,
             mergeOnCols: List[String],
             partitionPruneCols: List[String] = List(),
             insertExcludeCols: List[String] = List(),
             updateExcludeCols: List[String] = List(),
             customInsertExpr: Map[String, String] = Map(),
             customUpdateExpr: Map[String, String] = Map()): Unit = {
    println(
      s"targetPath: $targetPath, mergeOnCols: [${mergeOnCols.mkString(", ")}], partitionPruneCols: [${
        partitionPruneCols
          .mkString(", ")
      }]"
    )
    println(s"insertExcludeCols: [${insertExcludeCols.mkString(", ")}]")
    println(s"updateExcludeCols: [${updateExcludeCols.mkString(", ")}]")
    println(s"customInsertExpr:  [${customInsertExpr.mkString(", ")}]")
    println(s"customUpdateExpr:  [${customUpdateExpr.mkString(", ")}]")

    val targetTable =
      DeltaTable.forPath(SynapseSpark.getActiveSession, targetPath)
    val targetDf = targetTable.toDF
    println(
      s"Target table cols (${targetDf.columns.length})    : ${targetDf.columns.mkString(", ")}"
    )
    println(
      s"Source Dataframe cols (${sourceDf.columns.length}): ${sourceDf.columns.mkString(", ")}"
    )

    /*val mergeCols = sourceDf.columns

    val updateExpr = mergeCols.map(colName => (s"target.$colName", s"source.$colName")).toMap*/
    val mergeCols = sourceDf.columns
      .map(colName => (s"target.$colName", s"source.$colName"))
      .toMap
    val tempUpdateExpr = mergeCols.filterKeys(col => {
      val lookup = col.replace("target.", "")
      !updateExcludeCols.contains(lookup)
    })

    val finalUpdateExpr = tempUpdateExpr ++ customUpdateExpr
    println(
      "Filtered cols from updateExpr: " + mergeCols.keySet
        .diff(finalUpdateExpr.keySet)
    )

    //val insertExpr: mutable.Map[String, String] = mutable.Map[String, String]() ++= finalUpdateExpr
    val tempInsertExpr = mergeCols.filterKeys(col => {
      val lookup = col.replace("target.", "")
      !insertExcludeCols.contains(lookup)
    })
    val finalInsertExpr = tempInsertExpr ++ customInsertExpr
    println(
      "Filtered cols from insertExpr: " + mergeCols.keySet
        .diff(finalInsertExpr.keySet)
    )

    println(s"updateExpr: $finalUpdateExpr")
    println(s"insertExpr: $finalInsertExpr")

    val mergeCondition =
      mergeOnCols.map(col => s"target.$col = source.$col").mkString(" AND ")
    println(s"mergeCondition: [$mergeCondition]")

    targetTable
      .as("target")
      .merge(sourceDf.as("source"), mergeCondition)
      .whenMatched
      .updateExpr(finalUpdateExpr)
      .whenNotMatched
      .insertExpr(finalInsertExpr)
      .execute()
  }

  def writeAsCsv(inputDf: DataFrame, saveToPath: String, overwriteFolder: Boolean = false, saveMode: SaveMode = SaveMode.Overwrite,
                 partitionColNames: Option[Array[String]] = None, performCompression: Boolean = false,
                 writeOptions: Map[String, String] = Map.empty): Unit = {
    println(s"saveToPath: $saveToPath, saveMode: $saveMode, partitionColNames: ${partitionColNames.getOrElse(Array("EMPTY")).mkString(",")}, force: $overwriteFolder")
    if (AzStorage.ifFileExists(saveToPath) && !overwriteFolder)
      throw new RuntimeException(s"$saveToPath to path already exists. Call with argument 'force=true' to overwrite.")

    write(inputDf, saveToPath, StorageFormat.Csv, saveMode, partitionColNames, performCompression, writeOptions)
  }

  def writeAsJson(inputDf: DataFrame, saveToPath: String, overwriteFolder: Boolean = false, saveMode: SaveMode = SaveMode.Overwrite,
                  partitionColNames: Option[Array[String]] = None, performCompression: Boolean = false,
                  writeOptions: Map[String, String] = Map.empty): Unit = {
    println(s"saveToPath: $saveToPath, saveMode: $saveMode, partitionColNames: ${partitionColNames.getOrElse(Array("EMPTY")).mkString(",")}, force: $overwriteFolder")
    if (AzStorage.ifFileExists(saveToPath) && !overwriteFolder)
      throw new RuntimeException(s"$saveToPath to path already exists. Call with argument 'force=true' to overwrite.")

    write(inputDf, saveToPath, StorageFormat.JSON, saveMode, partitionColNames, performCompression, writeOptions)
  }

  def writeAsParquet(inputDf: DataFrame, saveToPath: String, force: Boolean = false, saveMode: SaveMode = SaveMode.Overwrite,
                     partitionColNames: Option[Array[String]] = None, performCompression: Boolean = false,
                     writeOptions: Map[String, String] = Map.empty): Unit = {
    println(s"saveToPath: $saveToPath, saveMode: $saveMode, partitionColNames: ${partitionColNames.getOrElse(Array("EMPTY")).mkString(",")}, force: $force")
    if (AzStorage.ifFileExists(saveToPath) && !force)
      throw new RuntimeException(s"$saveToPath to path already exists. Call with argument 'force=true' to overwrite.")

    write(inputDf, saveToPath, StorageFormat.Parquet, saveMode, partitionColNames, performCompression, writeOptions)
  }

  def writeAsDelta(inputDf: DataFrame, saveToPath: String, force: Boolean = false, saveMode: SaveMode = SaveMode.Overwrite,
                   partitionColNames: Option[Array[String]] = None, performCompression: Boolean = false,
                   writeOptions: Map[String, String] = Map.empty): Unit = {
    println(s"saveToPath: $saveToPath, saveMode: $saveMode, partitionColNames: ${partitionColNames.getOrElse(Array("EMPTY")).mkString(",")}, force: $force")
    if (AzStorage.ifFileExists(saveToPath) && !force)
      throw new RuntimeException(s"$saveToPath to path already exists. Call with argument 'force=true' to overwrite.")

    write(inputDf, saveToPath, StorageFormat.Delta, saveMode, partitionColNames, performCompression, writeOptions)
  }

  /**
   * Use to write the inputDf into different supported formats: [[StorageFormat]].
   *
   * @param inputDf            [[DataFrame]] to be saved.
   * @param saveToPath         Target path to save. Use relative path ("/poc/parquet/nyc_yellow_taxi_trips") if storing in primary storage account of the workspace,
   *                           full absolute path (abfss://containerName@storageAcctName.dfs.core.windows.net/folder1/folder2/fileName/) otherwise.
   * @param fileFormat         One of the formats defined in [[StorageFormat]].
   * @param saveMode           Optional. Defaults to [[SaveMode.Overwrite]]. One of the save modes defined in [[SaveMode]].
   * @param partitionColNames  Optional. Name of the columns used for partitioning. Defaults to [[None]].
   * @param performCompression Optional. Defaults to false. Whether to perform compression or not.
   * @param writeOptions       Other write options supported by corresponding storage format.
   */
  def write(inputDf: DataFrame, saveToPath: String, fileFormat: StorageFormat, saveMode: SaveMode = SaveMode.Overwrite,
            partitionColNames: Option[Array[String]] = None, performCompression: Boolean = false,
            writeOptions: Map[String, String] = Map.empty): Unit = {

    val writer = inputDf
      .write
      .mode(saveMode)
      .options(writeOptions)

    if (partitionColNames.isDefined && partitionColNames.get.nonEmpty) {
      writer.partitionBy(partitionColNames.get: _*)
    }

    if (performCompression) {
      writer.option("compression", "snappy")
    }

    fileFormat match {
      case Csv => writer.csv(saveToPath)
      case Parquet => writer.parquet(saveToPath)
      case Delta => writer.format(fileFormat.format).save(saveToPath)
      case JSON => writer.json(saveToPath)
    }
  }
}