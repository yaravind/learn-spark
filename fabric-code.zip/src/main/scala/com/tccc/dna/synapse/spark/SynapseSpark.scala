package com.tccc.dna.synapse.spark

import com.microsoft.spark.notebook.msutils.MSFileInfo
import com.tccc.dna.synapse.Utils._
import com.tccc.dna.synapse.{AzStorage, Logging, Utils}
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.immutable.ListMap
import scala.util.Try

/**
 * TODO Add support for printing spark.sql.adaptive.optimizeSkewedJoin.enabled
 */
object SynapseSpark extends Logging {
  private lazy val sparkConfProps: Map[String, String] = ListMap(getActiveSession.conf.getAll.toSeq.sortBy(_._1): _*)

  /** Prints version info of JDK, Spark, Delta and other important libraries and services.
   */
  def printVersions(): Unit = {
    val spark = getActiveSession
    println("Spark version: " + spark.version) //3.3.1.5.2-108696741
    println("Delta version: " + io.delta.VERSION) //2.2.0.9
    println("Scala version:  " + util.Properties.versionNumberString) //2.12.15
    println("Java version:  " + System.getProperty("java.version")) //1.8.0_382
    println("JRE name: " + sys.props.get("java.runtime.name").getOrElse("**Not Available**")) //OpenJDK Runtime Environment
    println("JRE version: " + sys.props.get("java.runtime.version").getOrElse("**Not Available**")) //1.8.0_382-8u382-ga-1~18.04.1-b05
    println("Metastore version: " + getSparkConfProp("spark.sql.hive.metastore.version")) //2.3.2
    println("Catalog/Metastore type: " + getSparkConfProp("spark.sql.catalogImplementation")) //hive
    //abfss://default@storageaact.dfs.core.windows.net/synapse/workspaces/syn-tccc-udp-mai-us2-dev-01/warehouse
    println("Spark warehouse location: " + getSparkConfProp("spark.sql.warehouse.dir"))
    println("java.vendor: " + System.getProperty("java.vendor")) //Private Build
    println("java.home: " + System.getProperty("java.home")) ///usr/lib/jvm/java-8-openjdk-amd64/jre

    println("user.timezone: " + sys.props.get("user.timezone").getOrElse("**Not Available**")) //Etc/UTC
    println("os.name: " + sys.props.get("os.name").getOrElse("**Not Available**")) //Linux
    println("spark.sql.session.timeZone: " + SynapseSpark.getSparkConfProp("spark.sql.session.timeZone"))
    /*
    When System.getProperty("java.vendor") returns "private build" in Java, it means that the Java runtime installed
    on your system is a custom-built version rather than an official release from the leading Java providers
    like Oracle or OpenJDK
     */
  }

  /** Every running Spark application is assigned (by developer or by system) a name and an id. This will print that
   * information.
   */
  def printAppInfo(): Unit = {
    val allConf = getSparkConfProps

    println("App Name (from SparkSession):\t " + getCurrentSparkAppName)
    println("App Id (from SparkSession):\t " + getCurrentSparkAppId)
    val spark = SynapseSpark.getActiveSession
    println("App Name (from SparkContext):\t " + spark.sparkContext.appName)
    println("App Id (from SparkContext):\t " + spark.sparkContext.applicationId)

    println("Notebook Name:\t " + getCurrentNotebookName)

    // Synapse/ADF Pipeline info
    println("Pipeline Run Id:\t " + getCurrentPipelineRunId)
    println("Activity Run Id:\t " + getCurrentPipelineActivityRunId)

    // Synapse workspace & pool info
    println("Workspace:\t " + getCurrentSynapseWorkspaceName)
    println("Pool:\t " + getCurrentSynapseSparkPoolName)
  }

  /*{
    val spark = getActiveSession
    //Retrieve configuration properties from SparkSession
    val runtimeCfg: RuntimeConfig = spark.conf
    val confMap = runtimeCfg.getAll

    //sort the keys
    val allConf = ListMap(confMap.toSeq.sortBy(_._1): _*)
    allConf
  }*/

  /** Name of the current executing Notebook.
   *
   * @return
   * notebook name.
   */
  def getCurrentNotebookName: String = getSparkConfProp("spark.synapse.context.notebookname")

  /** Run Id of the Synapse or ADF Pipeline run.
   *
   * @return
   * pipeline run id.
   */
  def getCurrentPipelineRunId: String = if (isLocalEnv) Utils.getRandomUUIDAsString else getSparkConfProp("spark.synapse.context.pipelinejobid")

  /** Run Id of the Synapse or ADF activity run.
   *
   * @return
   * activity run id.
   */
  def getCurrentPipelineActivityRunId: String = if (isLocalEnv) Utils.getRandomUUIDAsString else getSparkConfProp("spark.synapse.context.activityrunid")

  /** Name of the Synapse workspace.
   *
   * @return
   * workspace name.
   */
  def getCurrentSynapseWorkspaceName: String = getOrElse(
    mssparkutils.env.getWorkspaceName()
  ) // getSparkConfProps("spark.synapse.workspace.name")

  /** Name of the Synapse Spark Pool.
   *
   * @return
   * Spark Pool name.
   */
  def getCurrentSynapseSparkPoolName: String = getOrElse(
    mssparkutils.env.getPoolName()
  ) // getSparkConfProps("spark.synapse.pool.name")

  /** Name of running Spark application. Retrieved from `spark.app.name`.
   *
   * @return
   * Name of running Spark application.
   */
  def getCurrentSparkAppName: String = getSparkConfProps("spark.app.name")

  /** Id of running Spark application.
   *
   * @return
   * Id of running Spark application.
   */
  def getCurrentSparkAppId: String = getSparkConfProps("spark.app.id")

  /** Principal (User or Service or Managed Identity) name.
   *
   * @note This function only works in notebooks. Use [[getUserUUID]] to get the UUID of the current principal to be saved in audit table.
   * @return Email for user principal or "Not Available".
   */
  def getCurrentUserName: String = {
    var principal = ""
    try {
      principal = mssparkutils.env.getUserName()
    } catch {
      case ex: org.json.JSONException => logWarning("Can't get username.", ex)
    }
    getOrElse(principal)
  }

  def isRunAsManagedIdentity: Boolean = {
    var principal = ""
    try {
      principal = mssparkutils.env.getUserName()
    } catch {
      case ex: org.json.JSONException => logWarning("Can't get username.", ex)
    }
    principal.nonEmpty
  }

  /** UUID of the current principal. Use this to save in audit table.
   *
   * @return
   * UUID of the current principal or "Not Available".
   */
  def getUserUUID: String = getOrElse(mssparkutils.env.getUserId())

  /** Livy session id
   *
   * @return
   * Livy session id or "Not Available".
   */
  def getLivySessionId: String = getOrElse(mssparkutils.env.getJobId())

  /** UUID of the spark cluster.
   *
   * @return
   * UUID of the spark cluster or "Not Available".
   */
  def getClusterId: String = getOrElse(mssparkutils.env.getClusterId())

  /** Check if the code is running in synapse cluster. Useful for get [[SparkSession]] object to run spark app on local
   * laptop or Mac.
   *
   * @return
   * true if not running in synapse/trident workspace.
   */
  def isLocalEnv: Boolean = mssparkutils.env.getWorkspaceName().isEmpty

  def printSparkConfMasterProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("master") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfDeltaProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("delta") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfDatabricksProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("databrick") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfDriverProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("driver") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfExecutorProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) =>
        k.contains("executor")
        // || v.contains("executor")
      }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfAppProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) =>
        k.contains("app") && !k.contains("yarn")
        // || v.contains("app")
      }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfYARNAppProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) =>
        k.contains("yarn.app")
        // || v.contains("app")
      }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfYARNProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("yarn") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  /** All [[org.apache.spark.SparkConf]] properties sorted.
   *
   * @return
   * sorted [[Map[String, String]]] of key/value pairs from [[org.apache.spark.SparkConf]]
   */
  def getSparkConfProps: Map[String, String] = sparkConfProps

  def printSparkConfLivyProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) =>
        k.contains("livy")
        // || v.contains("livy")
      }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfSQLProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("spark.sql") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfAzureProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("azure") || v.contains("azure") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfMicrosoftProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("microsoft") || v.contains("microsoft") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfSynapseProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("synapse") || v.contains("synapse") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfSparkUIProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("spark.ui") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfHistoryServerProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("spark.history") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfClusterProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("spark.cluster") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfShuffleProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("spark.shuffle") || k.contains("spark.sql.shuffle") || v.contains("shuffle") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfDynamicAllocProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("spark.dynamicAllocation") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfSynapseHistoryServerProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("spark.synapse.history") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfHiveMetastoreProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("spark.hadoop.javax.jdo") || k.contains("hive") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printSparkConfEventLogProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("eventLog") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  /** References: <ol> <li>[[http://www.russellspitzer.com/2017/09/01/Spark-Locality/ Data Locality docs]]</li>
   * <li>[[https://www.waitingforcode.com/general-big-data/data-processing-locality-cloud-based-data-processing/read
    * Locality in Cloud]]</li> <li>[[https://spark.apache.org/docs/latest/tuning.html#data-locality Locality
   * details]]</li> </ol>
   */
  def printSparkConfLocalityProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) => k.contains("locality") }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  def printPartitionSplitRelatedProps(): Unit = {
    val spark = getActiveSession
    val maxPartitionBytes =
      Utils.humanReadableByteSize(SynapseSpark.getSparkConfProp("spark.sql.files.maxPartitionBytes").toLong)
    println(s"spark.sql.files.maxPartitionBytes: $maxPartitionBytes")

    // Using SynapseSpark.getSparkConfProp doesn't work
    val strCostInBytes = spark.conf.get("spark.sql.files.openCostInBytes")
    // returns the last char as 'b' for bytes. E.g. 4194304b
    val openCostInBytes = Utils.humanReadableByteSize(strCostInBytes.substring(0, strCostInBytes.length - 1).toLong)
    println(s"spark.sql.files.openCostInBytes: $openCostInBytes")

    println(
      "spark.default.parallelism: " + Try(spark.conf.get("spark.default.parallelism"))
        .getOrElse("Error 'spark.default.parallelism' is not set.")
    )
    println(
      "spark.sql.shuffle.partitions: " + Try(spark.conf.get("spark.sql.shuffle.partitions"))
        .getOrElse("Error 'spark.default.parallelism' is not set.")
    )
    println(
      "spark.sql.files.minPartitionNum: " + Try(spark.conf.get("spark.sql.files.minPartitionNum"))
        .getOrElse("Error 'spark.sql.files.minPartitionNum' is not set.")
    )
    println(
      "spark.sql.sources.parallelPartitionDiscovery.parallelism: " + Try(
        spark.conf.get("spark.sql.sources.parallelPartitionDiscovery.parallelism")
      ).getOrElse("Error 'spark.sql.sources.parallelPartitionDiscovery.parallelism' is not set.")
    )

    println(
      "mapred.min.split.size: " + Try(spark.conf.get("mapred.min.split.size"))
        .getOrElse("Error 'mapred.min.split.size' is not set.")
    )
    println("dfs.blocksize: " + Try(spark.conf.get("dfs.blocksize")).getOrElse("Error 'dfs.blocksize' is not set."))
  }

  /** Retrieve value for the given key from [[org.apache.spark.SparkConf]].
   *
   * @param key
   * key name
   * @return
   * corresponding value
   */
  def getSparkConfProp(key: String): String = {
    try {
      getSparkConfProps(key)
    }
    catch {
      case ex: java.util.NoSuchElementException =>
        "**Not Available**"
    }
  }

  def printSparkConfOtherProps(): Unit = {
    getSparkConfProps
      .filter { case (k, v) =>
        !k.contains("azure") && !k.contains("microsoft") && !k.contains("synapse") && !k.contains("spark.cluster") &&
          !v.contains("azure") && !v.contains("microsoft") && !v.contains("synapse") && !k.contains("spark.ui") && !k
          .contains("spark.dynamicAllocation") &&
          !k.contains("spark.sql") && !k.contains("yarn") && !k.contains("synapse") && !k.contains("yarn.app") && !k
          .contains("spark.history") &&
          !k.contains("driver") && !k.contains("executor") && !k.contains("livy") && !k.contains("app") && !k.contains(
          "spark.master"
        ) && !k.contains("shuffle") &&
          !k.contains("spark.hadoop.javax.jdo") && !k.contains("eventLog") &&
          !k.contains("spark.arcadia.session.token") // Redact token
      }
      .foreach { case (k, v) => println(k + " = " + v) }
  }

  /** Collects all files and folders of the given path and sub-folders recursively and creates a Spark [[DataFrame]] to
   * enable querying and pretty print using Notebook's '''display()''' method. Method also dedupes duplicate rows that will show up if '''nested paths''' are
   * provides as input.
   *
   * @param adlsUriOrPaths An [[Array]] of paths to the directory to start the listing from. Shouldn't include file-name. It can be either a full abfss URI or
   *                       relative path to a director starting with '''/'''
   * @return A Spark [[DataFrame]] with columns '''name, path, size, isDir, isFile, modifyTime'''. Schema: {{{
   *           root
   *            |-- name: string (nullable = true)
   *            |-- path: string (nullable = true)
   *            |-- size: long (nullable = false)
   *            |-- isDir: boolean (nullable = false)
   *            |-- isFile: boolean (nullable = false)
   *            |-- modifyTime: long (nullable = false)
   * }}}
   * @example
   * {{{
   * val adlsUri = "abfss://container@storage-account.net/data/v1"
   * val fileDf = toDataFrame(Array(adlsUri))
   *
   * val path = "/data/v1"
   * val fileDf = toDataFrame(Array(path))
   * }}}
   */
  def deepLsToDataFrame(adlsUriOrPaths: Array[String]): DataFrame = {
    val spark = getActiveSession
    val fileDf = adlsUriOrPaths.map(path => {
      val root = MSFileInfo(name = null, path = path, size = 0, isDir = true, isFile = false, modifyTime = System.currentTimeMillis)
      val files = AzStorage.deepLs(root)
      // sc.parallelize() method creates a distributed and parallelized dataset on existing collection on the "driver"
      val df = spark.createDataFrame(spark.sparkContext.parallelize(files))

      df
    }).reduce(_ union _).distinct()

    fileDf
  }

  def activeExecutorCount: Int = {
    activeExecutors.size
  }

  def activeExecutors: Seq[String] = {
    val spark = getActiveSession
    // allExecutors: Iterable[String] = List(192.168.1.228:64834)
    val allExecutors = spark.sparkContext.getExecutorMemoryStatus.keys

    // driverHost: String = 192.168.1.228
    // val driverHost: String = spark.sparkContext.getConf.get("spark.driver.host")
    val driverHost: String = getSparkConfProps("spark.driver.host")

    // Filter out driver from executor list.
    allExecutors.filter(!_.split(":")(0).equals(driverHost)).toList
  }

  /** @return
   * Current active [[SparkSession]] or throws a [[RuntimeException]] if the session is not found.
   */
  def getActiveSession: SparkSession = {
    val spark = SparkSession.getActiveSession.getOrElse {
      throw new RuntimeException("Active SparkSession not found.")
    }
    spark
  }

  def totalClusterExecutorCores: Int = {
    val spark = getActiveSession
    spark.sparkContext.defaultParallelism
  }
}