package com.tccc.dna.synapse.spark.test

import org.apache.spark.sql.SparkSession

/**
 * The `lazy` keyword ensures that the SparkSession object is only initialized when it's first used; this allows for
 * better resource management and avoids unnecessary initialization.
 * It is important to note that '''lazy vals are instance-level''', not class-level. Each instance of a class that extends
 * this trait would have its own separate `spark` instance.
 *
 * So, all the tests in a given suite will re-use the same spark instance.
 */
trait SparkSessionTestWrapper {

  /** It's typically best set the number of shuffle partitions to one in your test suite.
   * This configuration can make your tests run up to 70% faster. You can remove this configuration option
   * or adjust it if you're working with big DataFrames in your test suite. * */
  lazy val spark: SparkSession = {
    SparkSession
      .builder()
      .master("local")
      .appName("spark-fast-tests test session")
      .config("spark.sql.shuffle.partitions", "1")
      .config("spark.sql.autoBroadcastJoinThreshold", -1)
      // Adding these 2 config to work with delta table.
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
      //Can't assign requested address: Service 'sparkDriver' failed after 16 retries (on a random free port)!
      // Consider explicitly setting the appropriate binding address for the service 'sparkDriver' (for example spark.driver.bindAddress for SparkDriver)
      // to the correct binding address.
      .config("spark.driver.bindAddress", "127.0.0.1")
      //org.apache.spark.SparkContext - Error initializing SparkContext.
      //java.lang.AssertionError: assertion failed: Expected hostname or IPv6 IP enclosed in [] but got 2600:1700:3d70:91f0:86:8d75:268d:9c98
      .config("spark.driver.host", "localhost")
      .getOrCreate()
  }
}