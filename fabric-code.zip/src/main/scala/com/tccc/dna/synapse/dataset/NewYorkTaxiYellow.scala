package com.tccc.dna.synapse.dataset

import com.tccc.dna.synapse.StorageFormat._
import com.tccc.dna.synapse.spark.{SynapseSpark, Writers}
import com.tccc.dna.synapse.{AzStorage, StorageFormat}
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.sql.{DataFrame, SaveMode}

/**
 * Contains helper methods to work with [[https://learn.microsoft.com/en-us/azure/open-datasets/dataset-taxi-yellow?tabs=azureml-opendatasets NewYork Yellow Taxi Trips.]]
 * <ul>
 * <li>This dataset is stored in Parquet format. There are about 1.5B rows (50 GB) in total as of 2018.</li>
 * <li>Contains historical records accumulated from 2009 to 2018.</li>
 * </ul>
 */
object NewYorkTaxiYellow {
  @transient private val log: Logger = LogManager.getLogger(getClass.getName.stripSuffix("$"))

  //Azure storage access info
  val storageAcct = "azureopendatastorage"
  val fileSysOrContainer = "nyctlc"
  val relativePath = "yellow"
  val sasToken = ""
  val partitionColNames: Option[Array[String]] = Some(Array("puYear", "puMonth"))

  //Allow SPARK to read from Blob remotely
  val fullPath = s"wasbs://$fileSysOrContainer@$storageAcct.blob.core.windows.net/$relativePath"

  def getOpenDatasetDataFrame: DataFrame = {
    val session = SynapseSpark.getActiveSession
    session.conf.set(s"fs.azure.sas.$fileSysOrContainer.$storageAcct.blob.core.windows.net", sasToken)
    log.debug(s"Reading from: $fullPath")

    //the data is in parquet
    val df = session.read.parquet(fullPath)
    df
  }

  def writeAsCsv(saveToPath: String, force: Boolean = false): Unit = {
    if (AzStorage.ifFileExists(saveToPath) && !force)
      throw new RuntimeException(s"$saveToPath to path already exists. Call with argument 'force=true' to overwrite.")

    Writers.write(getOpenDatasetDataFrame, saveToPath, StorageFormat.Csv, SaveMode.Overwrite, partitionColNames)
  }

  def writeAsParquet(saveToPath: String, force: Boolean = false): Unit = {
    if (AzStorage.ifFileExists(saveToPath) && !force)
      throw new RuntimeException(s"$saveToPath to path already exists. Call with argument 'force=true' to overwrite.")

    Writers.write(getOpenDatasetDataFrame, saveToPath, StorageFormat.Parquet, partitionColNames = partitionColNames)
  }

  def writeAsDelta(saveToPath: String, force: Boolean = false): Unit = {
    if (AzStorage.ifFileExists(saveToPath) && !force)
      throw new RuntimeException(s"$saveToPath to path already exists. Call with argument 'force=true' to overwrite.")

    Writers.write(getOpenDatasetDataFrame, saveToPath, StorageFormat.Delta, partitionColNames = partitionColNames)
  }

}