package com.tccc.dna.synapse.spark

import com.fasterxml.jackson.databind.JsonNode
import com.github.fge.jackson.JsonLoader
import com.github.fge.jsonschema.main.{JsonSchemaFactory, JsonValidator}
import com.tccc.dna.datacontract.{DataContractYAMLFactory, JsonSchemaValidator}
import com.tccc.dna.datacontract.JsonSchemaValidator.{JsonError, ValidationResult}
import com.tccc.dna.synapse.spark.Ddl.jsonValidatorResultSchema
import com.tccc.dna.synapse.{Logging, StorageFormat}
import org.apache.commons.lang3.time.DateFormatUtils
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

import java.util.Date
import scala.collection.immutable
import scala.io.Source

object DataFrames extends Logging {

  /** Might fail with a AuthorizationPermissionMismatch error. To resolve this, make sure the Service Principal have the
   * Storage Blob Data Contributor role assignment
   *
   * @group Load
   * @param storageAcct
   * name of storage account. E.g. sause2udpuat08
   * @param containerOrFileSys
   * name of file system a.k.a container. E.g. gold
   * @param filePath
   * relative path from container. Do not prefix with a folder separator
   * @param fileFormat
   * one of [[StorageFormat.Delta]], [[StorageFormat.Csv]], [[StorageFormat.Parquet]] or , [[StorageFormat.JSON]].
   * Defaults to [[StorageFormat.Delta]] SparkSession
   * @throws java.util.concurrent.ExecutionException
   * with roout cause java.nio.file.AccessDeniedException when the principal doesn't have Blob Data Contributor role
   * @throws org.apache.spark.sql.AnalysisException
   * when the path isn't a Delta table.
   * @return
   * A DataFrame representing the Delta table
   */
  def getDataFrame(
                    storageAcct: String,
                    containerOrFileSys: String,
                    filePath: String,
                    addInputFilePath: Boolean,
                    fileFormat: StorageFormat = StorageFormat.Delta,
                    readOptions: Map[String, String] = Map.empty
                  ): DataFrame = {
    val spark = SynapseSpark.getActiveSession
    val adlsGen2Path = s"abfss://$containerOrFileSys@$storageAcct.dfs.core.windows.net/$filePath"
    logInfo(s"Reading from $adlsGen2Path as '${fileFormat.format}'", logToNotebook = true)
    val df = spark.read
      .format(fileFormat.format)
      .options(readOptions)
      .load(adlsGen2Path)

    if (addInputFilePath) {
      addFileNameCol(addFilePathCol(df))
      //df.withColumn("input_file_path", input_file_name())
    } else df
  }

  /** Critical data -> Fail Fast Lame analysis mode -> Permissive Get Only Valid Data -> Drop Malformed
   *
   * @param pathUri
   * Absolute or relative path.
   * @param fileFormat
   * One of enum values from [[StorageFormat]].
   * @param schema
   * Schema [[StructType]] of to be applied to the [[DataFrame]]
   * @param readOptions
   * [[String]] key/value [[Map]] of read options. Options for some file types:
   * [[https://spark.apache.org/docs/latest/sql-data-sources-generic-options.html Generic Files Source Options]],
   * [[https://spark.apache.org/docs/latest/sql-data-sources-parquet.html Parquet Source Options]],
   * [[https://spark.apache.org/docs/latest/sql-data-sources-csv.html#data-source-option Csv Source Options]]
   * @return
   * @group Load
   */
  def getDataFrameFromUri(
                           pathUri: String,
                           fileFormat: StorageFormat = StorageFormat.Delta,
                           schema: StructType,
                           addInputFilePath: Boolean,
                           readOptions: Map[String, String] = Map.empty
                         ): DataFrame = {
    val spark = SynapseSpark.getActiveSession
    logInfo(s"Reading from $pathUri as '${fileFormat.format}'", logToNotebook = true)
    val df = spark.read
      .format(fileFormat.format)
      .options(readOptions)
      .schema(schema)
      .load(pathUri)
    if (addInputFilePath) {
      addFileNameCol(addFilePathCol(df))
      //df.withColumn("input_file_path", input_file_name())
    } else df
  }

  /**
   *
   * @param pathUri     Absolute or relative path.
   * @param fileFormat  One of enum values from [[StorageFormat]].
   * @param readOptions [[String]] key/value [[Map]] of read options. Options for some file types:
   *                    [[https://spark.apache.org/docs/latest/sql-data-sources-generic-options.html Generic Files Source Options]],
   *                    [[https://spark.apache.org/docs/latest/sql-data-sources-parquet.html Parquet Source Options]],
   *                    [[https://spark.apache.org/docs/latest/sql-data-sources-csv.html#data-source-option Csv Source Options]]
   * @return
   * @group Load
   */
  def getDataFrameFromUri(
                           pathUri: String,
                           fileFormat: StorageFormat,
                           addInputFilePath: Boolean,
                           readOptions: Map[String, String],
                         ): DataFrame = {
    val spark = SynapseSpark.getActiveSession
    logInfo(s"Reading from $pathUri as '${fileFormat.format}'", logToNotebook = true)
    val df = spark.read
      .format(fileFormat.format)
      .options(readOptions)
      .load(pathUri)

    if (addInputFilePath) {
      addFileNameCol(addFilePathCol(df))
      //df.withColumn("input_file_path", input_file_name())
    } else df
  }

  /**
   *
   * @param pathUri          Path to load the data from.
   * @param fileFormat       One of enum values from [[StorageFormat]].
   * @param readOptions      [[String]] key/value [[Map]] of read options. Options for some file types:
   *                         [[https://spark.apache.org/docs/latest/sql-data-sources-generic-options.html Generic Files Source Options]],
   *                         [[https://spark.apache.org/docs/latest/sql-data-sources-parquet.html Parquet Source Options]],
   *                         [[https://spark.apache.org/docs/latest/sql-data-sources-csv.html#data-source-option Csv Source Options]]
   * @param partitions       A [[Map]] with partition column name as key and values to be filtered as an [[Array]]. For e.g.
   *                         `Map("submissionDate", Array("2023-12-01", "2023-12-04"))`.
   * @param addInputFilePath `false` by default. If `true`, adds the 'input_file_name() function value to 'input_file_path' column.
   * @param printExplainPlan `false` by default. If `true`, prints execution plan (`df.queryExecution.executedPlan`) for debugging.
   * @return A [[DataFrame]].
   */
  def getDataFrameForPartitions(
                                 pathUri: String,
                                 fileFormat: StorageFormat,
                                 readOptions: Map[String, String],
                                 partitions: Map[String, Array[String]],
                                 addInputFilePath: Boolean = false,
                                 printExplainPlan: Boolean = false
                               ): DataFrame = {
    val spark = SynapseSpark.getActiveSession
    logInfo(s"Reading from $pathUri as '${fileFormat.format}', readFilters: $partitions", logToNotebook = true)

    var resultDf = spark.read
      .format(fileFormat.format)
      .options(readOptions)
      .load(pathUri)

    resultDf = if (partitions.nonEmpty) {
      // Build the filter condition
      val filterCondition = partitions
        .map { case (colName, valueArray) => valueArray.map(value => s"to_date($colName, 'yyyy-MM-dd') = '$value'").mkString(" or ")
        }.mkString(" and ")
      logInfo(s"Read filters are enabled. Applying condition: $filterCondition")
      // Apply the filter condition
      resultDf.filter(filterCondition)

    } else resultDf

    if (printExplainPlan) logInfo(s"${resultDf.queryExecution.executedPlan}")
    if (addInputFilePath) {
      DataFrames.addFileNameCol(DataFrames.addFilePathCol(resultDf))
    } else resultDf
  }


  /**
   * @param pathUri          Path to load the data from.
   * @param fileFormat       One of enum values from [[StorageFormat]].
   * @param readOptions      [[String]] key/value [[Map]] of read options. Options for some file types:
   *                         [[https://spark.apache.org/docs/latest/sql-data-sources-generic-options.html Generic Files Source Options]],
   *                         [[https://spark.apache.org/docs/latest/sql-data-sources-parquet.html Parquet Source Options]],
   *                         [[https://spark.apache.org/docs/latest/sql-data-sources-csv.html#data-source-option Csv Source Options]]
   * @param conditionExpr    Arbitrary filter SQL expression to apply. For e.g. `peopleDf.filter("age > 15")`
   * @param addInputFilePath `false` by default. If `true`, adds the 'input_file_name() function value to 'input_file_path' column.
   * @param printExplainPlan `false` by default. If `true`, prints execution plan (`df.queryExecution.executedPlan`) for debugging.
   * @return A [[DataFrame]].
   */
  def getDataFrameFromUriWithFilterCondition(pathUri: String, fileFormat: StorageFormat, readOptions: Map[String, String],
                                             conditionExpr: String, addInputFilePath: Boolean = false, printExplainPlan: Boolean = false
                                            ): DataFrame = {
    val spark = SynapseSpark.getActiveSession
    logInfo(s"Reading from $pathUri as '${fileFormat.format}', readFilters: $conditionExpr", logToNotebook = true)

    var resultDf = spark.read
      .format(fileFormat.format)
      .options(readOptions)
      .load(pathUri)

    resultDf = resultDf.filter(conditionExpr)

    if (printExplainPlan) logInfo(s"${resultDf.queryExecution.executedPlan}")

    if (addInputFilePath) {
      DataFrames.addFileNameCol(DataFrames.addFilePathCol(resultDf))
    }
    else resultDf
  }

  /**
   *
   * @param pathUri          Path to load the data from.
   * @param fileFormat       One of enum values from [[StorageFormat]].
   * @param schema           User defined schema for the entity of type [[StructType]].
   * @param readOptions      [[String]] key/value [[Map]] of read options. Options for some file types:
   *                         [[https://spark.apache.org/docs/latest/sql-data-sources-generic-options.html Generic Files Source Options]],
   *                         [[https://spark.apache.org/docs/latest/sql-data-sources-parquet.html Parquet Source Options]],
   *                         [[https://spark.apache.org/docs/latest/sql-data-sources-csv.html#data-source-option Csv Source Options]]
   * @param readFilters      Equality filter. A [[Map]] with column name as key and value to filter on. For e.g. `Map("age", "30"))` will result in checking
   *                         `age = 30`.
   * @param printExplainPlan `false` by default. If `true`, prints execution plan (`df.queryExecution.executedPlan`) for debugging.
   * @return A [[DataFrame]].
   */
  def getDataFrameFromUriWithFilters(
                                      pathUri: String,
                                      fileFormat: StorageFormat,
                                      schema: StructType,
                                      readOptions: Map[String, String],
                                      readFilters: Map[String, String] = Map.empty,
                                      printExplainPlan: Boolean = false
                                    ): DataFrame = {
    val spark = SynapseSpark.getActiveSession
    logInfo(s"Reading from $pathUri as '${fileFormat.format}', readFilters: $readFilters", logToNotebook = true)

    var resultDf = spark.read
      .format(fileFormat.format)
      .options(readOptions)
      .schema(schema)
      .load(pathUri)

    resultDf = if (readFilters.nonEmpty) {
      // Build the filter condition
      val filterCondition = readFilters.map { case (colName, value) => s"$colName = '$value'" }.mkString(" and ")
      logInfo(s"Read filters are enabled. Applying condition: $filterCondition")
      // Apply the filter condition
      resultDf.filter(filterCondition)

    } else resultDf

    if (printExplainPlan) logInfo(s"${resultDf.queryExecution.executedPlan}")

    resultDf
  }

  /**
   * @param fileFormat  One of enum values from [[StorageFormat]].
   * @param schema      Schema [[StructType]] to apply while reading the data.
   * @param readOptions [[String]] key/value [[Map]] of read options. Options for some file types:
   *                    [[https://spark.apache.org/docs/latest/sql-data-sources-generic-options.html Generic Files Source Options]],
   *                    [[https://spark.apache.org/docs/latest/sql-data-sources-parquet.html Parquet Source Options]],
   *                    [[https://spark.apache.org/docs/latest/sql-data-sources-csv.html#data-source-option Csv Source Options]]
   * @param pathUris    A list of path uri's to load the data from.
   * @return A [[DataFrame]].
   */
  def getDataFrameFromUris(
                            fileFormat: StorageFormat,
                            schema: StructType,
                            readOptions: Map[String, String],
                            pathUris: Array[String]
                          ): DataFrame = {
    val spark = SynapseSpark.getActiveSession
    logInfo(s"Reading from ${pathUris.mkString(",")} as '${fileFormat.format}'", logToNotebook = true)
    spark.read
      .format(fileFormat.format)
      .options(readOptions)
      .schema(schema)
      .load(pathUris: _*)
  }

  /**
   *
   * @param fileFormat       One of enum values from [[StorageFormat]].
   * @param readOptions      [[String]] key/value [[Map]] of read options. Options for some file types:
   *                         [[https://spark.apache.org/docs/latest/sql-data-sources-generic-options.html Generic Files Source Options]],
   *                         [[https://spark.apache.org/docs/latest/sql-data-sources-parquet.html Parquet Source Options]],
   *                         [[https://spark.apache.org/docs/latest/sql-data-sources-csv.html#data-source-option Csv Source Options]]
   * @param addInputFilePath If true, adds the 'input_file_name() function value to 'input_file_path' column.
   * @param pathUris         A list of path uri's to load the data from.
   * @return A [[DataFrame]].
   */
  def getDataFrameFromUris(
                            fileFormat: StorageFormat,
                            schema: StructType,
                            readOptions: Map[String, String],
                            addInputFilePath: Boolean,
                            pathUris: Array[String]
                          ): DataFrame = {
    val spark = SynapseSpark.getActiveSession
    logInfo(s"Reading from ${pathUris.mkString(",")} as '${fileFormat.format}'")
    val df = spark.read
      .format(fileFormat.format)
      .options(readOptions)
      .schema(schema)
      .load(pathUris: _*)

    if (addInputFilePath) {
      addFileNameCol(addFilePathCol(df))
      //df.withColumn("input_file_path", input_file_name())
    } else df
  }


  def loadAndValidateJson(landingUri: String, dataContractSource: Source): DataFrame = {
    val landingDf = DataFrames.getDataFrameFromUri(landingUri, StorageFormat.Text, addInputFilePath = false, schema = null)
    val (rowCnt, colCnt) = DataFrames.getShape(landingDf)
    logInfo(s"Before validate. Row count: $rowCnt, Col count: $colCnt")

    val landingValidatedDf = validateJson(landingDf, dataContractSource)
    val (rowCnt1, colCnt1) = DataFrames.getShape(landingValidatedDf)
    logInfo(s"After validate. Row count: $rowCnt, Col count: $colCnt")

    landingValidatedDf
  }

  /**
   * Load and validate json file(s) against a json schema
   *
   * @param jsonSchemaAsStr  [[https://json-schema.org/specification JSON Schema Spec]] as a string.
   * @param addInputFilePath If true, adds the 'input_file_name() function value to 'inputFilePath' column.
   * @param filePaths        List of files to be validated.
   * @return A [[DataFrame]] with the following columns: {{{
   *  root
   *    |-- input: string (nullable = true)
   *    |-- inputFilePath: string (nullable = true, only if inputFilePath set to true)
   *    |-- is_valid: boolean (nullable = false)
   *    |-- error_count: integer (nullable = false)
   *    |-- error_list: array (nullable = true)
   *    |    |-- element: string (containsNull = true)
   * }}}
   * @group Validate
   */
  def loadAndValidateJson(jsonSchemaAsStr: String, addInputFilePath: Boolean, filePaths: String*): DataFrame = {
    val landingDf = DataFrames.getDataFrameFromUris(StorageFormat.Text, null, Map.empty[String, String], addInputFilePath, filePaths.toArray)

    //val (rowCnt, colCnt) = DataFrames.getShape(landingDf)
    val validatedDf = validateJson(landingDf, jsonSchemaAsStr, addInputFilePath)

    //val (rowCnt1, colCnt1) = DataFrames.getShape(validatedDf)

    validatedDf
  }

  def loadAndValidateJsonV2(jsonSchemaAsStr: String, addInputFilePath: Boolean, filePaths: String*): DataFrame = {
    val landingDf = DataFrames.getDataFrameFromUris(StorageFormat.Text, null, Map.empty[String, String], addInputFilePath, filePaths.toArray)

    //val (rowCnt, colCnt) = DataFrames.getShape(landingDf)
    val validatedDf = validateJsonV2(landingDf, jsonSchemaAsStr, addInputFilePath)

    //val (rowCnt1, colCnt1) = DataFrames.getShape(validatedDf)

    validatedDf
  }

  def validateJson(inputDf: DataFrame, dataContract: Source): DataFrame = {
    val contractYaml = dataContract.getLines.mkString("\n")
    val schemaYaml = DataContractYAMLFactory.getSchemaObject(DataContractYAMLFactory.parseFromString(contractYaml))

    //Optimized version
    val jsonSchema = DataContractYAMLFactory.getSchemaSpecification(schemaYaml)

    //Iterate over partition
    val rdd: RDD[ValidationResult] = inputDf.rdd.mapPartitions { iterator => {
      //Initialize the validator and create schema instance once per partition
      val jsonSchemaNode: JsonNode = JsonLoader.fromString(jsonSchema)
      val validator: JsonValidator = JsonSchemaFactory.byDefault.getValidator

      //Iterate over each row
      val validationResult = iterator.map(row => JsonSchemaValidator.validateOptimized(validator, jsonSchemaNode, row.mkString))
      validationResult
    }
    }
    SynapseSpark.getActiveSession.createDataFrame(rdd).toDF("input", "is_valid", "error_count", "error_list")
  }

  /*
  def validateJson(inputDf: DataFrame, dataContract: Source): DataFrame = {
    val contractYaml = dataContract.getLines.mkString("\n")
    val schemaYaml = DataContractYAMLFactory.getSchemaObject(DataContractYAMLFactory.parseFromString(contractYaml))

    //Optimized version
    val jsonSchema = DataContractYAMLFactory.getSchemaSpecification(schemaYaml)

    //Iterate over partition
    val rdd: RDD[ValidationResult] = inputDf.rdd.mapPartitions { iterator => {
      //Initialize the validator and create schema instance once per partition
      val jsonSchemaNode: JsonNode = JsonLoader.fromString(jsonSchema)
      val validator: JsonValidator = JsonSchemaFactory.byDefault.getValidator

      //Iterate over each row
      val validationResult = iterator.map(row => JsonSchemaValidator.validateOptimized(validator, jsonSchemaNode, row.mkString))
      validationResult
    }
    }
    SynapseSpark.getActiveSession.createDataFrame(rdd).toDF("input", "is_valid", "error_count", "error_list")
  }
   */

  def validateJsonV2(inputDf: DataFrame, jsonSchemaAsStr: String, addInputFilePath: Boolean, jsonInstanceColName: String = "value"): DataFrame = {
    //Iterate over partition
    val rdd: RDD[Row] = inputDf.rdd.mapPartitions { iterator => {
      //Initialize the validator and create schema instance once per partition
      val jsonSchemaNode: JsonNode = JsonLoader.fromString(jsonSchemaAsStr)
      val validator: JsonValidator = JsonSchemaFactory.byDefault.getValidator

      //Iterate over each row
      val validationResult = iterator.map(row => {
        val result = JsonSchemaValidator.validateOptimizedV2(validator, jsonSchemaNode, row.getAs[String](jsonInstanceColName))
        if (addInputFilePath && row.length == 1)
          logError("Passed addInputFilePath = true but inputDf has only 1 column. So returning null for inputFilePath column. Make sure fix the code. " +
            "Schema: " + DataFrames.getSchemaAsJson(inputDf))
        if (addInputFilePath && row.length > 1)
          Row(result(0), result(1), result(2), result(3), row.getAs[String]("audit_file_path"))
        else
          Row(result(0), result(1), result(2), result(3), null)
      })
      validationResult
    }
    }

    SynapseSpark.getActiveSession.createDataFrame(rdd, jsonValidatorResultSchema)
  }


  def validateJson(inputDf: DataFrame, jsonSchemaAsStr: String, addInputFilePath: Boolean, jsonInstanceColName: String = "value"): DataFrame = {
    //Iterate over partition
    val rdd: RDD[(String, Boolean, Int, List[String], String)] = inputDf.rdd.mapPartitions { iterator => {
      //Initialize the validator and create schema instance once per partition
      val jsonSchemaNode: JsonNode = JsonLoader.fromString(jsonSchemaAsStr)
      val validator: JsonValidator = JsonSchemaFactory.byDefault.getValidator

      //Iterate over each row
      val validationResult = iterator.map(row => {
        val result = JsonSchemaValidator.validateOptimized(validator, jsonSchemaNode, row.getAs[String](jsonInstanceColName))
        if (addInputFilePath && row.length == 1)
          logError("Passed addInputFilePath = true but inputDf has only 1 column. So returning null for inputFilePath column. Make sure fix the code. " +
            "Schema: " + DataFrames.getSchemaAsJson(inputDf))
        if (addInputFilePath && row.length > 1)
          (result.inputJson, result.isValid, result.errorCount, result.errorList, row.getAs[String]("audit_file_path"))
        else
          (result.inputJson, result.isValid, result.errorCount, result.errorList, null)
      })
      validationResult
    }
    }
    SynapseSpark.getActiveSession.createDataFrame(rdd).toDF("input", "is_valid", "error_count", "error_list", "input_file_path")
  }


  /** Prints the shape (rows, cols) and schema of the DataFrame.
   *
   * @param df
   * DataFrame object.
   */
  def printInfo(df: DataFrame): Unit = {
    println(f"Shape (rows, cols): ${getShape(df)}")
    df.printSchema
  }

  /** * Returns the number of rows and columns as a tuple (number of rows, number of columns)
   *
   * @param df
   * DataFrame object
   * @return
   * (number of rows, number of columns)
   */
  def getShape(df: DataFrame): (Long, Int) = {
    val rows: Long = df.count()
    val columns = df.columns.length
    val size = (rows, columns)
    size
  }

  /** * Get the JSON version of the schema of given [[DataFrame]].
   */
  def getSchemaAsJson(df: DataFrame): String = {
    df.schema.json
  }

  def addFilePathCol(df: DataFrame): DataFrame = {
    val spark = SynapseSpark.getActiveSession
    spark.udf.register(
      "get_file_name",
      (path: String) => path.split("/").last.split("\\.").head
    )
    df.withColumn("audit_file_path", input_file_name())
  }

  def addFileNameCol(df: DataFrame): DataFrame = {
    df.withColumn(
      "audit_file_name",
      regexp_extract(input_file_name, """[\/]([^\/]+[\/][^\/]+)$""", 1)
    )
  }

  /** Create a schema from json
   *
   * @param jsonStr
   * json version of serialized StructType
   * @return
   * [[StructType]]
   */
  def fromJsonToSchema(jsonStr: String): StructType = {
    DataType.fromJson(jsonStr).asInstanceOf[StructType]
  }

  /**
   * Return the inferred schema of the given dataframe.
   *
   * @param df Input [[DataFrame]].
   * @return A [[StructType]].
   */
  def getSchemaAsDictionary(df: DataFrame): StructType = {
    df.schema
  }

  /** Sometimes the data being read has spaces in the column names and mixed case alphabet etc. This function does the
   * following in that order.
   *
   *   1. trims leading and trailing whitespaces
   *   1. removes hyphens.
   *   1. removes forward slashes.
   *   1. removes periods.
   *   1. replaces spaces with '_'.
   *   1. changes to lowercase.
   *
   * @return
   * new [[DataFrame]] with new column names
   */
  def cleanColNames(df: DataFrame): DataFrame = {
    val oldCols = df.columns
    val renamedColumns: Array[String] =
      oldCols.map(oldColName => cleanName(oldColName))

    val oldVsNew = oldCols.zip(renamedColumns)
    if (log.isInfoEnabled) {
      oldVsNew.foreach(x => log.info(s"(${x._1}, ${x._2})"))
    }

    val renamedDf = df.toDF(renamedColumns: _*)
    renamedDf
  }

  def cleanName(oldName: String): String = {
    oldName
      .trim() // Remove leading and trailing whitespaces
      .replaceAll("-", " ") // Replace hyphen used as a separator
      .replaceAll("\\/", " ") // Replace / used as a separator
      .replaceAll("[()]", " ") // Replace left  and right parenthesis used as a separator
      .replaceAll("\\.", " ") // Dot notation is used to fetch values from fields that are nested
      .replaceAll("\\s+", " ") // Reduce multiple consecutive whitespaces to one
      .replaceAll(" ", "_") // Replace all single whitespace with underscores
      .toLowerCase()
  }

  /**
   * Drops dataframe columns in bulks, which is available since spark 2.x.
   *
   * @param df   Input [[DataFrame]] to drop the columns from.
   * @param cols [[List]] of columns to drop.
   * @return A New [[DataFrame]] with columns removed.
   */
  def dropCols(df: DataFrame, cols: List[String]): DataFrame = {
    // function to drop spark dataframe columns in bulks, which is available after spark2.x
    /*
    x => new Column(x)): _* doesn't work for columns that have special characters in their name. For e.g. 'tccc:description' column raises
    the following error: org.apache.spark.sql.AnalysisException: Can't extract value from tccc:description#84353: need struct type but got string
    */
    df.select(df.columns.diff(cols).map(c => col("`" + c + "`")): _*)
  }

  def stringifyColNames(df: DataFrame): String = df.columns.mkString(", ")

  def changeMulColType(df: DataFrame, colName: List[String], newType: List[String]): DataFrame = {
    val types =
      if (newType.length == 1) List.fill(colName.length)(newType.head)
      else newType
    colName.zip(types).foldLeft(df) { (table, zipped_col_type) =>
      changeColType(table, zipped_col_type._1, zipped_col_type._2)
    }
  }

  /**
   * Changes the type of a given column.
   *
   * TODO doesn't sypport all the types yet.
   *
   * @param df      Input dataframe.
   * @param colName Name of the column we are chaging the type for.
   * @param newType New type to cast to.
   * @return A new [[DataFrame]] with changed type for the given column.
   */
  def changeColType(df: DataFrame, colName: String, newType: String): DataFrame = {
    df.withColumn(colName, df(colName).cast(typeMatch(newType)))
  }

  def typeMatch(input: String): DataType = {
    input match {
      case "Int" => IntegerType
      case "String" => StringType
      case "Date" => DateType
      case "Double" => DoubleType
      case "Timestamp" => TimestampType
    }
  }

  def changeAllColType(df: DataFrame, sourceType: String, newType: String): DataFrame = {
    df.schema.filter(_.dataType == typeMatch(sourceType)).foldLeft(df) {
      // keyword case is optional
      case (table, col) => changeColType(table, col.name, newType)
    }
  }

  def addLoadDateTime(df: DataFrame, addHourCol: Boolean = true): DataFrame = {
    val datePart = DateFormatUtils.format(new Date(), "YYYY-MM-dd-HH-mm-ss")
    var resultDf = df.withColumn("audit_ldt", lit(datePart))
    if (addHourCol) resultDf.withColumn("audit_ldt_hour", hour(df("audit_ldt"))) else resultDf
  }

  def addPipelineRunId(df: DataFrame, colName: String = "audit_pipeline_run_id"): DataFrame = {
    df.withColumn(colName, lit(SynapseSpark.getCurrentPipelineRunId).cast(StringType))
  }

  def addActivityRunId(df: DataFrame, colName: String = "audit_activity_run_id"): DataFrame = {
    df.withColumn(colName, lit(SynapseSpark.getCurrentPipelineActivityRunId).cast(StringType))
  }

  /** Schema diff between provided DataFrame and existing table. Checks for <ul> <li>Total number of columns match</li>
   * <li>names match and</li> <li>data type match</li> </ul>
   *
   * @param df
   * [[DataFrame]] of the '''new''' data.
   * @param tableDF
   * [[DataFrame]] of the '''existing''' table.
   * @return
   * [[Set]] with schema differences. Empty set if there are no differences.¬
   */
  def getMissingTableColumnsAgainstDataFrameSchema(
                                                    df: DataFrame,
                                                    tableDF: DataFrame
                                                  ): Set[String] = {
    val dfSchema = df.schema.fields.map(v => (v.name, v.dataType)).toMap
    val tableSchema = tableDF.schema.fields.map(v => (v.name, v.dataType)).toMap
    val columnsMissingInTable = dfSchema.keys.toSet
      .diff(tableSchema.keys.toSet)
      .map(x => x.concat(s" ${dfSchema(x).sql}"))

    columnsMissingInTable
  }

  /**
   * Returns a list of columns in the input DataFrame(inputDf) that are not present in the list of expected or known columns (knownCols).
   *
   * @param inputDf   Input DataFrame.
   * @param knownCols Expected column as [[Array]].
   * @return List of cloumn names not present in `knownCols`
   */
  def getUnknownColumns(inputDf: DataFrame, knownCols: Array[String]): List[String] = {
    val inboundColNames = getColumnNames(inputDf).toList
    val commonColumns = inboundColNames.intersect(knownCols)
    val unknownColumns = inboundColNames.diff(commonColumns)
    unknownColumns
  }

  /**
   * This function is recursively fetching all the column names from a DataFrame, irrespective of their level in a nested structure,
   * and prefixing the parent column names to nested column names with a . delimiter. To illustrate how this function works, let's take a
   * sample DataFrame having following schema:
   *
   * {{{
   *   root
   *    |-- user: struct (nullable = true)
   *    |    |-- id: integer (nullable = true)
   *    |    |-- name: string (nullable = true)
   *    |    |-- address: struct (nullable = true)
   *    |    |    |-- city: string (nullable = true)
   *    |    |    |-- state: string (nullable = true)
   *    |-- time: long (nullable = true)
   * }}}
   *
   * If you pass this DataFrame and a prefix string "df." to getColumnNames, the function will return the following sequence of column names:
   *
   * {{{
   *   Seq("df.user.id", "df.user.name", "df.user.address.city", "df.user.address.state", "df.time")
   * }}}
   *
   * @param df     Input DataFrame.
   * @param prefix The prefix can be used to identify the dataframe the columns belong to, particularly useful when multiple dataframes has same column names.
   * @return [[Seq]] of column names.
   */
  def getColumnNames(df: DataFrame, prefix: String = ""): Seq[String] = {
    df.schema.fields.flatMap {
      case StructField(name, StructType(fields), _, _) =>
        /*
        If the field is of StructType, which means it is a nested structure, then the function calls itself with the selected nested
        DataFrame and a new prefix that includes the current nested column name.
         */
        getColumnNames(df.select(s"$prefix$name.*"), s"$prefix$name.")
      case StructField(name, _, _, _) =>
        // Regular column. Returns a sequence containing the prefixed column name.
        Seq(s"$prefix$name")
    }
  }

  /**
   * Returns a Dataframe after exploding the specified array columns to individual rows.
   *
   * @param resolvedColsToExplode Columns to be exploded.
   * @param columnsToBeSelected Columns to be selected after explode.
   * @param inputDf   Input DataFrame.
   * @return Returns a Dataframe with all columns in columnsToBeSelected after exploding the resolvedColsToExplode columns.
   */
  def explosion(
                 resolvedColsToExplode: Array[String],
                 columnsToBeSelected: Seq[String],
                 inputDf: DataFrame
               ): DataFrame = {
    inputDf.createOrReplaceTempView("temp_DfToExplode")

    val sql = "select " + columnsToBeSelected
      .map(x => s"`$x`")
      .mkString(",") + " from temp_DfToExplode\n" +
      resolvedColsToExplode
        .map(x => s"LATERAL VIEW OUTER explode(`$x`) AS ${x}_explode")
        .mkString("\n")
    logInfo("Explode sql:")
    println(sql)

    val explodedDf = SynapseSpark.getActiveSession.sql(sql)

    val droppedColDf =
      DataFrames.dropCols(explodedDf, resolvedColsToExplode.toList)

    def renameColumns(
                       df: DataFrame,
                       oldNewColNames: Array[(String, String)]
                     ): DataFrame = {
      oldNewColNames.foldLeft(df) { (tempDF, colName) =>
        tempDF.withColumnRenamed(colName._1, colName._2)
      }
    }

    val oldNewColNames = resolvedColsToExplode.map(x => (x + "_explode", x))

    val renamedDf = renameColumns(droppedColDf, oldNewColNames)

    renamedDf
  }

  def reorderColumns(inputDf: DataFrame, targetColumnOrder: Array[String]): DataFrame = {
    inputDf.select(targetColumnOrder.map(x => col(x)): _*)
  }
}