package com.tccc.dna.synapse

import com.microsoft.spark.notebook.msutils.MSFileInfo
import com.tccc.dna.synapse.spark.SynapseSpark
import org.apache.hadoop.fs.{FileSystem, LocatedFileStatus, Path, RemoteIterator}

import scala.collection.mutable
import com.microsoft.azure.storage.CloudStorageAccount
import com.microsoft.azure.storage.StorageCredentials
import com.microsoft.azure.storage.blob.CloudBlobClient
import com.microsoft.azure.storage.blob.CloudBlobContainer
import com.microsoft.azure.storage.blob.CloudBlockBlob
import org.apache.commons.io.FileUtils
import java.io.{File => javaFile}
import java.nio.file.{Files, Paths}

/** *
 * Utility methods to work with Synapse Storage and files.
 */
object AzStorage extends Logging {


  /**
   * Checks if the given file exists.
   *
   * @param filePath file to check for existence.
   * @return true if file exists, false otherwise.
   */
  def ifFileExists(filePath: String): Boolean = {
    var exists = false
    exists = if (!SynapseSpark.isLocalEnv) {
      try {
        if (mssparkutils.fs.ls(filePath) == null) false else true
      } catch {
        case e: Exception => logInfo(s"Informational message only! [$filePath] does not exist so creating it. Error: ${e.getMessage}")
      }
      exists
    } else {
      //Files.exists(Paths.get(filePath)) doesn't work with file:/// prefix. The following works with or without file:/// prefix.
      val fs = FileSystem.get(SynapseSpark.getActiveSession.sparkContext.hadoopConfiguration)
      fs.exists(new Path(filePath))
    }
    exists
  }

  /**
   * Creates passed in folders, if doesn't exist, also '''creating any necessary parent directories'''.
   * Can be used for creating different zones in medallian Lakehouse architecture or creating user's home directories
   * as part of user onboarding.
   *
   * Takes relative or absolute URI's.
   * <ul>
   * <li>Relative path example: `List("/experiment/userhome/gold", "/silver", "/bronze")`</li>
   * <li>Absolute path example: `List("abfss://containerName@storageAccount.dfs.core.windows.net/experiment/userhome/gold")`</li>
   * </ul>
   *
   * @param paths list of folders (absolute path or relative path) that need to be created.
   * @return `SortedMap[String, String]]` with folderName as the key and value as outcome of the dir creation.
   */
  def createFolders(paths: List[String]): mutable.SortedMap[String, String] = {
    val result = mutable.SortedMap[String, String]()
    paths.foreach(path => {
      if (AzStorage.ifFileExists(path)) {
        result += (path -> "Folder already exists. No need to create!")
      } else {
        val isSuccess = mssparkutils.fs.mkdirs(path)
        result += (path -> s"Created successfully? = ${isSuccess.toString}")
      }
    })
    result
  }

  /**
   * List all files and folders in specified path and sub-folders recursively. The out-of-the-box
   * [[mssparkutils.fs.ls]] isn't recursive and doesn't work on local environment. This function fixes both the issues.
   *
   * @param root initial directory to start the listing from
   * @return an [[Array]] of [[MSFileInfo]] objects
   */
  def deepLs(root: MSFileInfo): Array[MSFileInfo] = {
    if (!SynapseSpark.isLocalEnv) {
      val these = mssparkutils.fs.ls(root.path)
      if (these != null) {
        these ++ these.filter(_.isDir).flatMap(deepLs)
      }
      else Array()
    }
    else {
      val iterator: RemoteIterator[LocatedFileStatus] = FileSystem
        .get(SynapseSpark.getActiveSession.sparkContext.hadoopConfiguration)
        .listFiles(new Path(root.path), true)
      var list = Array[MSFileInfo]()
      while (iterator.hasNext) {
        val fs: LocatedFileStatus = iterator.next()
        list :+= MSFileInfo(name = fs.getPath.getName, path = fs.getPath.toString, size = fs.getLen, isDir = fs.isDirectory, isFile = fs.isFile, modifyTime =
          fs.getModificationTime)
      }
      list
    }
  }


  /**
   * Returns up to the first 'maxBytes' bytes of the given file as a String encoded in UTF-8
   *
   * @param fileUri  Use relative path ("/folder1/folder2/config.json") if the file is in primary storage account of the workspace,
   *                 full absolute path (abfss://container@storageAccount.dfs.core.windows.net/folder1/folder2/config.json) otherwise.
   * @param maxBytes Maximum number of bytes to read. Defaults to 200 KB.
   * @return String containing contents of the file, possibly truncated to the maxBytes.
   */
  def getFileAsStringFromURI(fileUri: String, maxBytes: Int = 1024 * 200): String = {
    mssparkutils.fs.head(fileUri, maxBytes)
  }

  /**
   * Returns up to the first 'maxBytes' bytes of the given file as a String encoded in UTF-8
   *
   * @note Uses [[mssparkutils.fs.head()]] to retrieve the contents. Suggestion is to use the [[getFileAsString()]] that takes keyVault params.
   * @param storageAcctName Name of the storage account.
   * @param containerName   Name of the file system or container.
   * @param pathToFile      Relative path from the storageAcctName. For e.g. folder1/folder2/config.json.
   * @param maxBytes        Maximum number of bytes to read. Defaults to 200 KB.
   * @return String containing contents of the file, possibly truncated to the maxBytes.
   */
  def getFileAsString(storageAcctName: String, containerName: String, pathToFile: String, maxBytes: Int = 1024 * 200): String = {
    val fileUri = s"abfss://$containerName@$storageAcctName.dfs.core.windows.net/$pathToFile"
    mssparkutils.fs.head(fileUri, maxBytes)
  }

  /**
   * Returns the file as String. Use this to read configuration and other files.
   *
   * @note Uses Azure Storage API to read the file.
   * @param storageAcctName    Name of the storage account.
   * @param containerName      Name of the file system or container.
   * @param pathToFile         Relative path from the storageAcctName. For e.g. folder1/folder2/config.json.
   * @param keyVaultName       Name of the Key Vault where the access key or SAS is stored as a secret.
   * @param keyVaultSecretName Secret name.
   * @return String containing contents of the file.
   */
  def getFileAsString(storageAcctName: String, containerName: String, pathToFile: String, keyVaultName: String, keyVaultSecretName: String): String = {
    //DefaultEndpointsProtocol=https;AccountName=storagemai01us2dev;AccountKey=xxx;EndpointSuffix=core.windows.net
    val primaryStorageAcctAccessKey = mssparkutils.credentials.getSecret(keyVaultName, keyVaultSecretName)
    val connectionString = s"DefaultEndpointsProtocol=https;AccountName=$storageAcctName;AccountKey=$primaryStorageAcctAccessKey;EndpointSuffix=core.windows.net"
    val account = CloudStorageAccount.parse(connectionString)
    val blobClient: CloudBlobClient = account.createCloudBlobClient()
    val container: CloudBlobContainer = blobClient.getContainerReference(containerName) //"metadata"
    val blob: CloudBlockBlob = container.getBlockBlobReference(pathToFile) //"/content/control_files/dam/AssetCreated.json"
    val fileContent = blob.downloadText()

    fileContent
  }

  /**
   * Copy files from list of source to a single destination.
   *
   * @param fromList        List of files to be copied.
   * @param toDir           Destination folder for the files to be copied.
   * @param overwriteFiles  Parameter to overwrite files if already present.
   *
   */
  def copyFiles(
                 fromList: List[String],
                 toDir: String,
                 overwriteFiles: Boolean = true
               ): Unit = {
    if (SynapseSpark.isLocalEnv) {
      val targetDirPath = Paths.get(toDir)
      if (!Files.exists(targetDirPath)) {
        Files.createDirectories(targetDirPath)
      }
      val CreateDestDir = true

      for (from <- fromList) {
        //Remove file: prefix
        val fromFile =
          if (from.startsWith("file:"))
            new javaFile(from.substring(from.indexOf(":") + 1))
          else new javaFile(from)
        val toFile = new javaFile(toDir)

        if (overwriteFiles) {
          val targetFilePath = toFile + from.substring(from.lastIndexOf("/"))

          Files.deleteIfExists(Paths.get(targetFilePath))
        }
        FileUtils.copyFileToDirectory(fromFile, toFile, CreateDestDir)
      }

      fromList.map(file => {
        val arr = file.split("/")
        val fileName = arr.last
      })
    } else {
      val DoNotCopyRecursively =
        false
      for (from <- fromList) {
        mssparkutils.fs.cp(from, toDir, DoNotCopyRecursively)
      }
    }
  }

  /**
   * Copy files from list of source to a list of destination.
   *
   * @param fromList       List of files to be copied.
   * @param toList         List of destination folder for the files to be copied.
   * @param overwriteFiles Parameter to overwrite files if already present.
   *
   */
  def copyFiles(
                 fromList: List[String],
                 toList: List[String],
                 overwriteFiles: Boolean
               ): Unit = {
    if (SynapseSpark.isLocalEnv) {
      var count = 0
      for (from <- fromList) {
        val tempDir = toList(count)
        val toDir = tempDir.substring(0, tempDir.lastIndexOf(("/")))
        val targetDirPath = Paths.get(toDir)
        if (!Files.exists(targetDirPath)) {
          Files.createDirectories(targetDirPath)
        }
        val CreateDestDir = true

        //Remove file: prefix
        val fromFile =
          if (from.startsWith("file:"))
            new javaFile(from.substring(from.indexOf(":") + 1))
          else new javaFile(from)
        val toFile = new javaFile(toDir)
        if (overwriteFiles) {
          val targetFilePath = toFile + from.substring(from.lastIndexOf("/"))
          logInfo(
            s"overwriteFiles set to true. Deleting from target dir: $targetFilePath"
          )
          Files.deleteIfExists(Paths.get(targetFilePath))
        }
        FileUtils.copyFileToDirectory(fromFile, toFile, CreateDestDir)
        logInfo(s"Copied [$from] to [$targetDirPath]")
        count = count + 1
      }
      fromList.map(file => {
        val arr = file.split("/")
        val fileName = arr.last
      })
    } else {
      var count = 0
      val DoNotCopyRecursively =
        false
      for (from <- fromList) {
        val tempDir = toList(count)
        val toDir = tempDir.substring(0, tempDir.lastIndexOf(("/")))
        mssparkutils.fs.mkdirs(toDir + "/")
        mssparkutils.fs.cp(from, toDir, DoNotCopyRecursively)
        logInfo(s"Copied [$from] to [$toDir]")
        println(s"Copied [$from] to [$toDir]")
        count = count + 1
      }
    }
  }



  /**
   * move files from list of source to a list of destination.
   *
   * @param fromList       List of files to be moved.
   * @param toList         List of destination folder for the files to be moved.
   * @param overwriteFiles Parameter to overwrite files if already present.
   *
   */
  def moveFiles(
                 fromList: List[String],
                 toList: List[String],
                 overwriteFiles: Boolean
               ): Unit = {
    if (SynapseSpark.isLocalEnv) {
      var count = 0
      for (from <- fromList) {
        val tempFile = toList(count)
        val toDir = tempFile.substring(0, tempFile.lastIndexOf(("/")))
        val targetDirPath = Paths.get(toDir)
        if (!Files.exists(targetDirPath)) {
          Files.createDirectories(targetDirPath)
        }
        val CreateDestDir = true
        //Remove file: prefix
        val fromFile =
          if (from.startsWith("file:"))
            new javaFile(from.substring(from.indexOf(":") + 1))
          else new javaFile(from)
        val toFile = new javaFile(toDir)
        if (overwriteFiles) {
          val targetFilePath = toDir
          logInfo(s"overwriteFiles set to true. Deleting from target dir: $targetFilePath")
          Files.deleteIfExists(Paths.get(tempFile))
        }
        FileUtils.moveFileToDirectory(fromFile, toFile, CreateDestDir)
        logInfo(s"Moved [$from] to [$targetDirPath]")
        count = count + 1
      }
      fromList.map(file => {
        val arr = file.split("/")
        val fileName = arr.last
      })
    } else {
      var count = 0
      val CreateParentDir =
        true
      val OverwriteDestFolder =
        true
      for (from <- fromList) {
        val tempDir = toList(count)
        val toDir = tempDir.substring(0, tempDir.lastIndexOf(("/")))
        mssparkutils.fs.mkdirs(toDir + "/")
        mssparkutils.fs.mv(from, toDir, CreateParentDir, OverwriteDestFolder)
        count = count + 1
      }
    }
  }

  /**
   * Move files from list of source to a single destination.
   *
   * @param fromList       List of files to be moved.
   * @param toDir          Destination folder for the files to be moved.
   * @param overwriteFiles Parameter to overwrite files if already present.
   *
   */

  def moveFiles(
                 fromList: List[String],
                 toDir: String,
                 overwriteFiles: Boolean = true
               ): Unit = {
    if (SynapseSpark.isLocalEnv) {
      val targetDirPath = Paths.get(toDir)
      if (!Files.exists(targetDirPath)) {
        Files.createDirectories(targetDirPath)
      }
      val CreateDestDir = true
      for (from <- fromList) {
        //Remove file: prefix
        val fromFile =
          if (from.startsWith("file:"))
            new javaFile(from.substring(from.indexOf(":") + 1))
          else new javaFile(from)
        val toFile = new javaFile(toDir)
        if (overwriteFiles) {
          val targetFilePath = toFile + from.substring(from.lastIndexOf("/"))
          logInfo(
            s"overwriteFiles set to true. Deleting from target dir: $targetFilePath"
          )
          Files.deleteIfExists(Paths.get(targetFilePath))
        }
        FileUtils.moveFileToDirectory(fromFile, toFile, CreateDestDir)
        logInfo(s"Moved [$from] to [$targetDirPath]")
      }
      fromList.map(file => {
        val arr = file.split("/")
        val fileName = arr.last
      })
    } else {
      val CreateParentDir =
        true //If true, will firstly create the parent dir if not exists before move op
      val OverwriteDestFolder =
        true //If true, will overwrite the destination folder if exists
      for (from <- fromList) {
        mssparkutils.fs.mv(from, toDir, CreateParentDir, OverwriteDestFolder)
      }
    }
  }
}