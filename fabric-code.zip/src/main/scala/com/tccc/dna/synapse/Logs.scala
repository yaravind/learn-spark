package com.tccc.dna.synapse

import com.tccc.dna.synapse.spark.SynapseSpark
import org.apache.log4j.Logger
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.core.LoggerContext

object Logs {
  def logDebug(inLog: Logger, msg: => String, throwable: Throwable): Unit = {
    if (inLog.isDebugEnabled) {
      println(msg)
      inLog.debug(msg, throwable)
    }
  }

  def logInfo(inLog: Logger, msg: => String, throwable: Throwable): Unit = {
    if (inLog.isInfoEnabled) {
      inLog.info(msg, throwable)
      println(msg)
    }
  }

  def logWarning(inLog: Logger, msg: => String, throwable: Throwable): Unit = {
    inLog.warn(msg, throwable)
    println(msg)
    throwable.printStackTrace()
  }

  def logError(inLog: Logger, msg: => String, throwable: Throwable): Unit = {
    inLog.error(msg, throwable)
    println(msg)
    throwable.printStackTrace()
  }

  def logFatal(inLog: Logger, msg: => String, throwable: Throwable): Unit = {
    inLog.fatal(msg, throwable)
    println(msg)
    throwable.printStackTrace()
  }

  def logError(inLog: Logger, msg: => String): Unit = {
    inLog.error(msg)
    println(msg)
  }

  def logFatal(inLog: Logger, msg: => String): Unit = {
    inLog.fatal(msg)
    println(msg)
  }

  def logWarning(inLog: Logger, msg: => String): Unit = {
    inLog.warn(msg)
    println(msg)
  }

  def logTrace(inLog: Logger, msg: => String): Unit = {
    if (inLog.isTraceEnabled) {
      inLog.trace(msg)
      println(msg)
    }
  }

  def logTrace(inLog: Logger, msg: => String, throwable: Throwable): Unit = {
    if (inLog.isTraceEnabled) {
      inLog.trace(msg, throwable)
      println(msg)
      throwable.printStackTrace()
    }
  }

  def logInfo(inLog: Logger, msg: => String): Unit = {
    if (inLog.isInfoEnabled) {
      inLog.info(msg)
      println(msg)
    }
  }

  def logDebug(inLog: Logger, msg: => String): Unit = {
    if (inLog.isDebugEnabled) {
      inLog.debug(msg)
      println(msg)
    }
  }

  /** Enables DEBUG Log4J level on the current session. By default, Synapse spark filters out DEBUG logs by default.
    * Removing the filter will help route DEBUG logs to Log Analytics.
    *
    * NOTE: If you are starting new, use INFO level logging. If you are migrating existing spark solutions where DEBUG
    * is used then you can enable DEBUG instead of chaging your working code.
    *
    * @return
    *   true if successful.
    */
  def enableDebug(): Boolean = {
    val ctx    = LogManager.getContext(false).asInstanceOf[LoggerContext]
    val config = ctx.getConfiguration

    // Synapse Spark filters out DEBUG logs by default. Removing the filter will help route DEBUG logs to Log Analytics
    config.removeFilter(config.getFilter)

    SynapseSpark.getActiveSession.sparkContext.setLogLevel("DEBUG")

    true
  }
}
