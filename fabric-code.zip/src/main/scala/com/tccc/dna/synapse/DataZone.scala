package com.tccc.dna.synapse

sealed abstract class DataZone(val name: String)

/**
 * Enums representing different data zones of logical medallion architecture.
 */
object DataZone {
  final case object RawZone extends DataZone(name = "raw")

  final case object RefinedZone extends DataZone(name = "refined")

  final case object CertifiedZone extends DataZone(name = "certified")

  final case object RdbmsCertifiedZone extends DataZone(name = "rdbmsCertified")

  /**
   * Fallback for scenarios where certain processing can't be clearly mapped to [[RawZone]], [[RefinedZone]] or [[CertifiedZone]]. For e.g. processing that
   * happens on the Spark Driver.
   */
  final case object Other extends DataZone(name = "other")
}