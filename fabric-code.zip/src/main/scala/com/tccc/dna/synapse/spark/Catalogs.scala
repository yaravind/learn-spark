package com.tccc.dna.synapse.spark

import com.tccc.dna.synapse.Logs._
import io.delta.tables.DeltaTable
import org.apache.log4j.{LogManager, Logger}
import org.apache.spark.sql.catalog.{Database, Function, Table}
import org.apache.spark.sql.catalyst.TableIdentifier
import org.apache.spark.sql.catalyst.analysis.NoSuchTableException
import org.apache.spark.sql.catalyst.catalog.CatalogTable

object Catalogs {
  @transient private val log: Logger = LogManager.getLogger(getClass.getName.stripSuffix("$"))

  def isDatabaseExists(dbOrSchemaName: String): Boolean = {
    var exists = false
    val spark = SynapseSpark.getActiveSession
    try {
      /*
      throws the following exception when database doesn't exist in catalog
      org.apache.spark.sql.AnalysisException
       */
      exists = spark.catalog.databaseExists(dbOrSchemaName)
    } catch {
      case e: Exception => logDebug(log, s"$dbOrSchemaName does not exist. Error: ${e.getMessage}", e)
    }
    exists
  }

  def isTableExists(dbOrSchemaName: String, tableName: String): Boolean = {
    var exists = false
    val fullName = dbOrSchemaName + "." + tableName
    val spark = SynapseSpark.getActiveSession
    try {
      /*
      throws the following exception when table doesn't exist in catalog
      org.apache.spark.sql.AnalysisException
       */
      exists = spark.catalog.tableExists(fullName)
    } catch {
      case e: Exception => logDebug(log, s"$fullName does not exist. Error: ${e.getMessage}", e)
    }
    exists
  }

  /**
   * Retrieves the general metatadata of a given table fron Catalog.
   *
   * {{{
   *  if(Catalogs.isTableExists(schemaName)) {
   *    logDebug(log, s"Table info: ${Catalogs.getTableInfo(schemaName, yellowTaxiDeltaBackedTable)}")
   *  }
   * }}}
   *
   * @param dbOrSchemaName Name of the schema.
   *
   * @param tableName      Name of the table.
   * @return [[Table]]
   */
  def getTableInfo(dbOrSchemaName: String, tableName: String): Table = {
    val fullName = dbOrSchemaName + "." + tableName
    val spark = SynapseSpark.getActiveSession
    val table = spark.catalog.getTable(fullName)
    table
  }

  /**
   * Retrieves the general metadata of a given database from Catalog.
   *
   * {{{
   *  if(Catalogs.isDatabaseExists(schemaName)) {
   *    logDebug(log, s"Database info: ${Catalogs.getDatabaseInfo(schemaName)}")
   *  }
   * }}}
   *
   * @param dbOrSchemaName Name of the database.
   * @return [[Database]]
   */
  def getDatabaseInfo(dbOrSchemaName: String): Database = {
    val spark = SynapseSpark.getActiveSession
    val db = spark.catalog.getDatabase(dbOrSchemaName)
    db
  }

  def getFunctionInfo(funcName: String): Function = {
    val spark = SynapseSpark.getActiveSession
    val func = spark.catalog.getFunction(funcName)
    func
  }

  /**
   * Checks whether the given table is backed by delta format.
   *
   * {{{
   *   //Delta
   *  println(Catalogs.isDeltaFormat("silver", "mt_nyc_yellow_taxi_trips_delta"))
   *
   *  //Parquet
   *  println(Catalogs.isDeltaFormat("silver", "mt_nyc_yellow_taxi_trips_parquet"))
   *
   *  //Negative tests
   *  println(Catalogs.isDeltaFormat("silver", "random_tbl"))
   *  println(Catalogs.isDeltaFormat("random_db", yellowTaxiDeltaBackedTable))
   * }}}
   *
   * @param schemaOrDbName Name of the database.
   *
   * @param tableName      Name of the table to check.
   * @return true if the provider is delta, false otherwise.
   */
  def isDeltaFormat(schemaOrDbName: String, tableName: String): Boolean = {
    val spark = SynapseSpark.getActiveSession
    var isDelta = false
    val currentDb = spark.catalog.currentDatabase
    switchToDatabase(schemaOrDbName)

    try {
      val metadata: CatalogTable = spark.sessionState.catalog.getTableMetadata(TableIdentifier(tableName))
      val loc = metadata.location.toString
      logDebug(log, s"Location of Table: $loc")
      try {
        isDelta = DeltaTable.isDeltaTable(spark, loc)
      } catch {
        case ex: RuntimeException => isDelta = false
      }
    } catch {
      case nste: NoSuchTableException =>
        logInfo(log, nste.getMessage)
        isDelta = false
    }
    switchToDatabase(currentDb)
    isDelta
  }

  def switchToDatabase(toDb: String): Unit = {
    val spark = SynapseSpark.getActiveSession

    val currentDb = spark.catalog.currentDatabase
    logDebug(log, s"Current Db: $currentDb")

    if (!currentDb.equals(toDb)) {
      /*
         By default, catalog object methods work on 'default' database. We need spark to change to the specified database
         before we request for the table metadata
      */
      if (isDatabaseExists(toDb)) {
        logDebug(log, s"Switching DB from '$currentDb' to '$toDb'")
        //catch the return value to avoid compile time warnings. spark.sql returns empty dataframe for DDL commands
        val df = spark.sql(s"USE $toDb")
      } else {
        logWarning(log, s"Database '$toDb' doesn't exist. Switch to $toDb didn't happen!")
      }
    }
  }
}
