package com.tccc.dna.synapse.spark

import org.apache.spark.sql.execution.datasources.PartitionedFile

case class KOFileSplit(filePath: String, startPos: Long, length: Long, fileSize: Option[Long])

object KOFileSplit {
  def apply(file: PartitionedFile): KOFileSplit =
    KOFileSplit(file.filePath.toString(), file.start, file.length, None)
}