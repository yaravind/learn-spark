package com.tccc.dna.synapse.spark.example

object WordCountUtil {
  //matches a space, a tab, a carriage return, a line feed, or a form feed
  val WhitespaceRegex = "[\\s]"

  def getPaths(args: Array[String]): Seq[String] = {
    val paths: Seq[String] = if (!args.isEmpty && args.length >=2) {
      args(0)
        .split(",")
        .map(x => x.trim)
        .filter(x => x.nonEmpty)
    }
    else {
      Seq("src/main/resources/wordcount/test.txt")
    }

    paths
  }
}
