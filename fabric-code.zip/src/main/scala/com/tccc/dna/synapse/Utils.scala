package com.tccc.dna.synapse

import java.nio.{ByteBuffer, ByteOrder}
import java.time.{Instant, LocalDate, ZoneOffset}
import java.util.UUID
import scala.collection.JavaConverters._
import scala.collection._
import scala.reflect.runtime.universe

object Utils extends Logging {

  import scala.reflect.runtime.universe._

  /** * Get the type information at runtime.
   *
   * @param value
   * variable (val) for which you want the type info
   * @tparam T
   * generic type
   * @return
   * a [[Type]] object
   * @example
   * {{{val a = Seq("1", "3") getType(a)}}}
   */
  def getType[T: TypeTag](value: T): universe.Type = typeOf[T]

  def getOrElse(in: String, default: String = "Not Available"): String = {
    if (in.isEmpty) default else in
  }

  /** Function to convert milliseconds into seconds and minutes
   *
   * @param millis
   * time in milliseconds.
   * @return
   * (Int, Int, Int) (Mins, Secs, Millis)
   */
  def convertMilliseconds(millis: Long): (Int, Int, Int) = {
    val seconds = (millis / 1000).toInt
    val minutes = seconds / 60
    val remainingSeconds = seconds % 60

    (minutes, remainingSeconds, millis.toInt % 1000)
  }

  def toScalaMap[K, V](javaMap: java.util.Map[K, V]): immutable.Map[K, V] = {
    javaMap.asScala.toMap
  }

  /** @see
   * https://stackoverflow.com/questions/3263892/format-file-size-as-mb-gb-etc
   * @see
   * https://en.wikipedia.org/wiki/Zettabyte
   * @param fileSize
   * Up to Exabytes
   * @return
   */
  def humanReadableByteSize(fileSize: Long): String = {
    if (fileSize <= 0) return "0 B"
    // kilo, Mega, Giga, Tera, Peta, Exa, Zetta, Yotta
    val units: Array[String] =
      Array("B", "kB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    val digitGroup: Int =
      (Math.log10(fileSize.toDouble) / Math.log10(1024)).toInt
    f"${fileSize / Math.pow(1024, digitGroup.toDouble)}%3.3f ${units(digitGroup)}"
  }

  /** @param targetMap
   * Initial map.
   * @param sourceMap
   * Map with updates and inserts
   * @return
   * New [[Map]] with merged key/values.
   */
  def merge(
             targetMap: Map[String, String],
             sourceMap: Map[String, String]
           ): Map[String, String] = {
    // sourceMap.foldLeft(targetMap) { case (acc, (key, value)) => acc + (key -> value) }
    targetMap ++ sourceMap
  }

  /** Converts byte array, representing Julian date to Gregorian date.
   *
   * @param parquetDate
   * Byte array representing Julian date.
   * @return
   * [[(LocalDate, Instant]] Parsed date and timestamp.
   */
  def int96ToJulian(parquetDate: Array[Byte]): (LocalDate, Instant) = {
    val buffer = ByteBuffer.wrap(parquetDate)
    buffer.order(ByteOrder.LITTLE_ENDIAN)
    val nano = buffer.getLong(0)
    val dt = buffer.getInt(8)

    var l = dt + 68569
    var n = 4 * l / 146097
    l = l - (146097 * n + 3) / 4
    var i = 4000 * (l + 1) / 1461001
    l = l - 1461 * i / 4 + 31
    var j = 80 * l / 2447
    val k = l - 2447 * j / 80
    l = j / 11
    j = j + 2 - 12 * l
    i = 100 * (n - 49) + i + l

    val date = LocalDate.of(i, j, k)
    val instant = date.atStartOfDay().toInstant(ZoneOffset.UTC)
    val plusI = instant.plusNanos(nano)

    // TODO Make the return type [[Option]] when there are parsing errors.
    (date, plusI)
  }

  def getUserNameFromEmail(email: String): String = {
    val at = email.indexOf("@")
    logInfo(s"User: $email")
    val userPath = if (at != -1) email.substring(0, at) else ""

    userPath
  }

  def getRandomUUID: UUID = UUID.randomUUID

  def getRandomUUIDAsString: String = getRandomUUID.toString

  import java.time.LocalTime
  import java.time.format.DateTimeFormatter

  /**
   * Each time this function is called, it returns the current hour of the day. Note that the hour is in 24-hour format (00-23).
   *
   * @return Current hour of the day.
   */
  def currentHourISOFormat(): String = {
    val now = LocalTime.now()
    val formatter = DateTimeFormatter.ofPattern("HH")
    now.format(formatter)
  }

}