package com.tccc.dna.synapse

import org.apache.hadoop.conf.Configuration
import org.apache.spark.SparkContext

import scala.collection.SortedMap

object HadoopUtils {
  def getConfigOptions(sc: SparkContext): SortedMap[String, String] = {

    // Get the Hadoop configuration from SparkContext
    val hadoopConf: Configuration = sc.hadoopConfiguration

    import scala.collection.JavaConverters._
    // Get all the config options from Hadoop configuration and convert to a Scala iterator
    val props: Iterator[java.util.Map.Entry[String, String]] = hadoopConf.iterator.asScala

    // Convert sorted properties to an immutable Map
    val resultMap: Map[String, String] = props.map(entry => entry.getKey -> entry.getValue).toMap

    // Sort by key
    val sortedProps = SortedMap(resultMap.toSeq: _*)


    // Return the immutable Map
    sortedProps
  }
}
