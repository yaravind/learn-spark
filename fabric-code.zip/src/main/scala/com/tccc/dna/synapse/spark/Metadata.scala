package com.tccc.dna.synapse.spark

import com.fasterxml.jackson.databind.{ObjectMapper, SerializationFeature}
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import com.fasterxml.jackson.module.scala.experimental.ScalaObjectMapper
import com.google.common.annotations.Beta
import com.tccc.dna.synapse.{Logging, Utils}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import org.apache.parquet.HadoopReadOptions
import org.apache.parquet.column.statistics.Statistics
import org.apache.parquet.hadoop.metadata.{BlockMetaData, ColumnChunkMetaData, ParquetMetadata}
import org.apache.parquet.hadoop.util.HadoopInputFile
import org.apache.parquet.hadoop.{Footer, ParquetFileReader}
import org.apache.parquet.schema.{GroupType, MessageType, Type}
import org.apache.parquet.tools.util.{MetadataUtils, PrettyPrintWriter}
import org.apache.spark.sql.execution.datasources.FilePartition
import org.apache.spark.sql.functions.{col, element_at, split}
import org.apache.spark.sql.{DataFrame, DataFrameReader, Dataset, Encoder, Encoders, functions}

import java.io.PrintStream
import java.util
import scala.Console.println
import scala.collection.JavaConverters.{asScalaBufferConverter, asScalaSetConverter}
import scala.collection.mutable.ListBuffer
import scala.collection.{SortedMap, mutable}
//import scala.jdk.CollectionConverters.{asScalaBufferConverter, asScalaSetConverter}
import scala.reflect.ClassTag

/** Helper method to programmatically inspect parquet file metadata.
  *
  * TODO <ul> <li> `org.apache.parquet:parquet-hadoop:1.11.2` bundled with Spark version `3.3.1.5.2-92314920` doesn't
  * have `hasDictionaryPage` and `getRowGroupOrdinal` in [[org.apache.parquet.hadoop.metadata.ColumnChunkMetaData]]
  * API.</li> </ul>
  *
  * @see
  *   [[https://github.com/apache/parquet-format/blob/952c26375eb15c6a27a770f26a6292264b1b7328/src/main/thrift/parquet.thrift#L505 Parquet format specification]]
  *
  * @author
  *   Aravind Yarram
  */
object Metadata extends Logging {

  /** @param parquetFilePath
    *   Absolute or relative path of the parquet file on ADLS Gen 2 or local file system.
    * @return
    *   Either[String, (FileMeta, SchemaMeta, List[RowGroupMeta], mutable.SortedMap[Int, ColSummaryMeta],
    *   mutable.SortedMap[Int, ColStats])
    */
  def getParquetMetadata(parquetFilePath: String): Either[
    String,
    (
        FileMeta,
        SchemaMeta,
        List[RowGroupMeta],
        mutable.SortedMap[Int, ColSummaryMeta],
        mutable.SortedMap[Int, ColStats]
    )
  ] = {
    val path = new Path(parquetFilePath)

    try {
      val hadoopConf =
        SynapseSpark.getActiveSession.sparkContext.hadoopConfiguration
      val pqMeta = ParquetFileReader.readFooter(hadoopConf, path)

      val fileMeta: FileMeta                              = getFileMeta(parquetFilePath, pqMeta)
      val schema: SchemaMeta                              = getSchema(pqMeta)
      val rowGroupMeta: List[RowGroupMeta]                = getRowGroupsMeta(parquetFilePath, pqMeta)
      val colMeta: mutable.SortedMap[Int, ColSummaryMeta] = getColSummaryMeta(parquetFilePath, pqMeta)
      val colStats: mutable.SortedMap[Int, ColStats]      = getColStats(parquetFilePath, pqMeta)

      Right((fileMeta, schema, rowGroupMeta, colMeta, colStats))
    } catch {
      case ex: Exception =>
        logError("Error while reading Parquet file metadata.", ex)
        Left(ex.getMessage)
      case th: Throwable =>
        logError("Fatal error", th)
        Left(th.getMessage)
    }
  }

  /** Returns [[ColStats]] as DataFrame, one row per-rowgroup-column . See [[ColStats]] for the column names and
    * description.
    *
    * @param parquetFilePaths
    *   Absolute or relative path of the parquet file on ADLS Gen 2 or local file system.
    * @return
    *   [[ColStats]] as DataFrame, one row per-rowgroup-column.
    */
  def getColStatsAsDataFrame(parquetFilePaths: Seq[String]): DataFrame = {
    val files = getFiles(null, None, parquetFilePaths, (_, file) => file.filePath)(
      Encoders.STRING
    )
    logInfo("Retrieving ColSummaryMeta metadata for parquet files: " + files.count)
    files
      .flatMap { file =>
        val conf            = new Configuration()
        val inputPath       = new Path(file)
        val inputFileStatus = inputPath.getFileSystem(conf).getFileStatus(inputPath)
        val footers         = ParquetFileReader.readFooters(conf, inputFileStatus, false)
        footers.asScala.flatMap { footer =>
          footer.getParquetMetadata.getBlocks.asScala.zipWithIndex.flatMap { case (block, rowGroupIdx) =>
            block.getColumns.asScala.zipWithIndex.map { case (colMeta, colIdx) =>
              buildColStats(file, rowGroupIdx, colIdx, colMeta)
            }
          }
        }
      }(Encoders.product[ColStats])
      .toDF()
  }

  /** Read the metadata of Parquet files into a [[DataFrame]]. See [[FileMeta]] for the list of columns and description.
    *
    * @param parquetFilePaths
    *   Absolute or relative path of the parquet file on ADLS Gen 2 or local file system.
    * @param parallelism
    *   Number of partitions in the returned DataFrame.
    * @return
    *   File metadata as DataFrame, one row per parquet file in the input param paths.
    */
  def getFileMetaAsDataFrame(parquetFilePaths: Seq[String], parallelism: Int = 2): DataFrame = {
    val files = getFiles(null, Some(parallelism), parquetFilePaths, (_, file) => file.filePath)(
      Encoders.STRING
    )
    import files.sparkSession.implicits._
    logInfo("Retrieving metadata for parquet files: " + files.count)
    val fileMetaDf = files
      .flatMap { file =>
        {
          val hadoopConf         = new Configuration()
          val path               = new Path(file)
          val inputFileStatus    = path.getFileSystem(hadoopConf).getFileStatus(path)
          val DoNotSkipRowGroups = false
          println("path: " + path.toString)
          /*
                    configuration – the configuration to access the FS
                    pathStatus – the root dir
                    skipRowGroups – whether to skip reading row group metadata
           */
          val footers: util.List[Footer] =
            ParquetFileReader.readFooters(hadoopConf, inputFileStatus, DoNotSkipRowGroups)
          footers.asScala.map { footer =>
            getFileMeta(footer.getFile.toString, footer.getParquetMetadata)
          }
        }
      }
      .toDF()

    // Split file name into columns and take last 2 parts
    val splitDF = fileMetaDf
      .withColumn("pathParts", split(col("filePath"), "/"))
      .withColumn("partsLength", functions.size($"pathParts"))
      // .withColumn("domain", element_at($"pathParts", $"partsLength" - 2))
      .withColumn("entity", element_at($"pathParts", $"partsLength" - 1))
      .withColumn("filePart", element_at($"pathParts", $"partsLength"))
      .drop("partsLength")
      .drop("pathParts")

    splitDF
  }

  /** Prints all available metadata of a given parquet file. Metadata: <ul> <li>File</li> <li>Schema</li> <li>Row
    * groups</li> <li>Column</li> <li>Column statistics</li> </ul>
    *
    * @param parquetFilePath
    *   Absolute or relative path of the parquet file on ADLS Gen 2 or local file system.
    */
  def printParquetMetadata(parquetFilePath: String): Unit = {
    val path = new Path(parquetFilePath)

    try {
      val hadoopConf =
        SynapseSpark.getActiveSession.sparkContext.hadoopConfiguration
      val pqMeta = ParquetFileReader.readFooter(hadoopConf, path)

      val fileMeta: FileMeta = getFileMeta(path.toString, pqMeta)
      println("File metadata:")
      println(getMetaJson(fileMeta, prettyPrint = true))

      val rowGroupMeta: List[RowGroupMeta] = getRowGroupsMeta(path.toString, pqMeta)
      println("\nRow Group(s) Metadata:")
      println(getMetaJson(rowGroupMeta, prettyPrint = true))

      val schema: SchemaMeta = getSchema(pqMeta)
      println("\nSchema Metadata:")
      println(getMetaJson(schema, prettyPrint = true))

      val colMeta: mutable.SortedMap[Int, ColSummaryMeta] = getColSummaryMeta(path.toString, pqMeta)
      println("\nColumn(s) Metadata:")
      println(getMetaJson(colMeta, prettyPrint = true))

      val colStats: mutable.SortedMap[Int, ColStats] = getColStats(path.toString, pqMeta)
      println("\nColumn Statistics:")
      println(getMetaJson(colStats, prettyPrint = true))
    } catch {
      case ex: Exception =>
        logError("Error while reading Parquet file metadata.", ex)
      case th: Throwable =>
        logError("Fatal error", th)
    }
  }

  /** Returns metadata stored in file header.
    *
    * @param pqMeta
    *   An instance of [[ParquetMetadata]].
    * @return
    *   An instance of [[FileMeta]].
    */
  def getFileMeta(file: String, pqMeta: ParquetMetadata): FileMeta = {

    val meta = pqMeta.getFileMetaData
    val numberOfRows: Long = pqMeta.getBlocks.stream
      .mapToLong((block: BlockMetaData) => block.getRowCount)
      .sum
    val schema: MessageType = pqMeta.getFileMetaData.getSchema

    val keyValue              = meta.getKeyValueMetaData
    val sizeBeforeCompression = getActualFileSize(pqMeta)
    val sizeAfterCompression  = getCompressedFileSize(pqMeta)
    val reductionPercent = if (sizeBeforeCompression == 0 && sizeAfterCompression == 0) {
      println(s"Zero size file: $file")
      logWarning(s"Zero size file: $file")
      0
    } else {
      getReductionPercent(sizeBeforeCompression, sizeAfterCompression)
    }

    // TODO how to get version
    val fileMetaDto = FileMeta(
      filePath = file,
      createdBy = meta.getCreatedBy,
      formatVersion = None,
      numColumns = schema.getColumns.size(),
      numRows = numberOfRows,
      numRowGroups = pqMeta.getBlocks.size(),
      uncompressedSize = sizeBeforeCompression,
      uncompressedSizeStr = Utils.humanReadableByteSize(getActualFileSize(pqMeta)),
      compressedSize = sizeAfterCompression,
      compressedSizeStr = Utils.humanReadableByteSize(getCompressedFileSize(pqMeta)),
      sizeReducedByPercent = reductionPercent,
      compression = getCompression(pqMeta),
      customProps = Utils.toScalaMap(keyValue)
    )
    // println(ParquetMetadata.toPrettyJSON(pqMeta))

    fileMetaDto
  }

  /** Returns the compression algorithm used in a Parquet file. NOTE that compression and encodings are different
    * things.
    *
    * @param pqMeta
    *   An instance of [[ParquetMetadata]].
    * @return
    *   The name of the compression algorithm used in the file (e.g., 'SNAPPY').
    */
  private def getCompression(pqMeta: ParquetMetadata): Option[String] = {
    if (pqMeta.getBlocks.size > 0) {
      val firstBlock = pqMeta.getBlocks.listIterator(0).next()
      if (firstBlock.getColumns.size() > 0) Some(firstBlock.getColumns.get(0).getCodec.name()) else None
    } else {
      None
    }
  }

  /** Returns the overall '''compressed''' file size calculated by summing the size, after compression, of all row
    * groups in the file.
    *
    * @param pqMeta
    *   Instance of [[ParquetMetadata]].
    * @return
    *   Size of the file after compression, in bytes.
    */
  private def getCompressedFileSize(pqMeta: ParquetMetadata): Long = {
    pqMeta.getBlocks.stream
      .mapToLong((block: BlockMetaData) => block.getCompressedSize)
      .sum
  }

  /** Returns the overall file size calculated by summing the actual size of all row groups in the file.
    *
    * @param pqMeta
    *   Instance of [[ParquetMetadata]].
    * @return
    *   Actual size of the file, in bytes.
    */
  private def getActualFileSize(pqMeta: ParquetMetadata): Long = {
    pqMeta.getBlocks.stream
      .mapToLong((block: BlockMetaData) => block.getTotalByteSize)
      .sum
  }

  /** Returns the available (stored in the metadata) statistics for each column.
    *
    * @param pqMeta
    *   An instance of [[ParquetMetadata]].
    * @return
    *   Keyed and ordered list of [[ColStats]].
    */
  def getColStats(file: String, pqMeta: ParquetMetadata): mutable.SortedMap[Int, ColStats] = {
    val ordinalToColStats = mutable.SortedMap[Int, ColStats]()

    import scala.collection.JavaConversions._
    for (blockMeta: BlockMetaData <- pqMeta.getBlocks) {
      var rgIdx  = 0
      var colIdx = 0
      for (colMeta <- blockMeta.getColumns) {
        val colStat: ColStats = buildColStats(file, rgIdx, colIdx, colMeta)
        ordinalToColStats += (colIdx -> colStat)
        colIdx = colIdx.+(1)
      }
      rgIdx = rgIdx.+(1)
    }
    ordinalToColStats
  }

  private def buildColStats(file: String, rowGroupIdx: Int, i: Int, colMeta: ColumnChunkMetaData) = {
    def isTimestampType(typeName: String) = {
      typeName.equalsIgnoreCase("INT96")
    }

    val stats = colMeta.getStatistics
    // println(ToStringBuilder.reflectionToString(stats, ToStringStyle.MULTI_LINE_STYLE))

    val name     = colMeta.getPath.toDotString
    val typeName = colMeta.getPrimitiveType.getPrimitiveTypeName.name()

    var isMinMaxDefined   = true
    var isStatsDefined    = true
    var isNumNullsDefined = true

    // Determine which stats are set
    if (stats.hasNonNullValue) {
      if (stats.isNumNullsSet) {
        isNumNullsDefined = true
      } else {
        // num_nulls not defined
        isNumNullsDefined = false
      }
    } else {
      if (!stats.isEmpty) {
        // min/max not defined
        isMinMaxDefined = false
      } else {
        isStatsDefined = false
        isNumNullsDefined = false
        // no stats for this column
      }
    }

    val (min, max) = if (isMinMaxDefined && isTimestampType(typeName)) {

      /*val pqMinTime =
      NanoTime.fromBinary(Binary.fromConstantByteArray(int96MinBytes))
    val pqMaxTime =
      NanoTime.fromBinary(Binary.fromConstantByteArray(int96MaxBytes))
    println(s"--> Min: $pqMinTime, Max: $pqMaxTime")

    val str = LocalDate.MIN
                .`with`(JulianFields.JULIAN_DAY, pqMinTime.julianDay)
                .format(DateTimeFormatter.ofPattern("MM/dd/yyyy"))
              /*val timeStr = LocalDateTime.MIN
                .`with`(JulianFields.JULIAN_DAY, pqMinTime.timeOfDayNanos)
                .format(DateTimeFormatter.ISO_ZONED_DATE_TIME)*/
              println(
                pqMinTime.julianDay,
                str,
                NanoTime.fromJulian(pqMinTime.julianDay),
                "day " + NanoTime.julianDateToZonedDateTime(pqMinTime.julianDay)
              )*/
      getMinMaxAsString(stats)
    } else {
      if (isMinMaxDefined) { (Some(stats.minAsString()), Some(stats.maxAsString())) }
      else { (None, None) }
    }

    val colStat = ColStats(
      filePath = file,
      id = i,
      rowGroupId = Some(rowGroupIdx),
      name = name,
      typeSerialized = typeName,
      typeRuntime = "TODO",
      hasStats = isStatsDefined,
      hasMinMax = isMinMaxDefined,
      min = min,
      max = max,
      hasNullCount = isNumNullsDefined,
      nullCount = stats.getNumNulls,
      distinctCount = -1,
      numValues = colMeta.getValueCount
    )
    colStat
  }

  private def getMinMaxAsString[T <: Comparable[T]](stats: Statistics[T]): (Option[String], Option[String]) = {
    val (_, minTs) = Utils.int96ToJulian(stats.getMinBytes)
    val (_, maxTs) = Utils.int96ToJulian(stats.getMaxBytes)

    // (Some(minTs.toString), Some(maxTs.toString))
    val min: Option[String] = if (minTs == null) None else Some(minTs.toString)
    val max: Option[String] = if (maxTs == null) None else Some(maxTs.toString)

    (min, max)
  }

  /** Returns metadata for each column in the file.
    *
    * @param pqMeta
    *   An instance of [[ParquetMetadata]].
    * @return
    *   [[ColSummaryMeta]] keyed by column ordinal.
    */
  def getColSummaryMeta(file: String, pqMeta: ParquetMetadata): mutable.SortedMap[Int, ColSummaryMeta] = {
    val ordinalToColSummary = mutable.SortedMap[Int, ColSummaryMeta]()
    println("Total blocks/rgs: " + pqMeta.getBlocks.size())
    import scala.collection.JavaConversions._
    for (blockMeta: BlockMetaData <- pqMeta.getBlocks) {
      // println(ToStringBuilder.reflectionToString(blockMeta, ToStringStyle.MULTI_LINE_STYLE))
      var rgIdx  = 0
      var colIdx = 0
      for (colMeta <- blockMeta.getColumns) {
        val colSummary: ColSummaryMeta = buildColSummaryMeta(file, rgIdx, colIdx, colMeta)
        ordinalToColSummary += (colIdx -> colSummary)
        colIdx = colIdx.+(1)
      }
      rgIdx = rgIdx.+(1)
    }
    ordinalToColSummary
  }

  private def buildColSummaryMeta(file: String, rowGroupIdx: Int, idx: Int, colMeta: ColumnChunkMetaData) = {
    val sizeBeforeCompression = colMeta.getTotalUncompressedSize
    val sizeAfterCompression  = colMeta.getTotalSize
    val reductionPercent      = getReductionPercent(sizeBeforeCompression, sizeAfterCompression)
    val encodings             = colMeta.getEncodings.asScala.toSeq.map(_.toString).sorted
    val encodes               = encodings.mkString(",") // Joiner.on(',').skipNulls.join(
    val idxOffset =
      if (colMeta.getOffsetIndexReference != null)
        Some(colMeta.getOffsetIndexReference.getOffset)
      else None

    val colSummary = ColSummaryMeta(
      filePath = file,
      id = idx,
      rowGroupId = Some(rowGroupIdx),
      colMeta.getPath.toDotString,
      colMeta.getValueCount,
      colMeta.getPrimitiveType.getPrimitiveTypeName.name(),
      !colMeta.getStatistics.isEmpty,
      colMeta.getCodec.name(),
      None,
      sizeBeforeCompression,
      Utils.humanReadableByteSize(sizeBeforeCompression),
      sizeAfterCompression,
      Utils.humanReadableByteSize(sizeAfterCompression),
      reductionPercent,
      encodings = encodes,
      dataPageOffset = colMeta.getFirstDataPageOffset,
      indexPageOffset = idxOffset,
      dictPageOffset = colMeta.getDictionaryPageOffset,
      customProps = None
    )
    colSummary
  }

  /** Returns the schema of the file as known to Parquet.
    *
    * @param pqMeta
    *   An instance of [[ParquetMetadata]].
    * @return
    *   [[SchemaMeta]]
    */
  def getSchema(pqMeta: ParquetMetadata): SchemaMeta = {
    val ordinalToSchema     = mutable.SortedMap[Int, ColSchemaMeta]()
    val schema: MessageType = pqMeta.getFileMetaData.getSchema
    /*schema.getPaths.forEach(x => {
      x.foreach(p => print(s"\tpath (${x.size}): " + p))
      println("\n----")
    })*/
    // schema.getColumnDescription() TODO future
    val it = schema.getFields.listIterator()

    var i = 0
    while (it.hasNext) {
      val fieldType: Type = it.next()

      if (fieldType.isInstanceOf[GroupType]) {
        // handle structs
        val gField = fieldType.asGroupType()

        val colDef = ColSchemaMeta(
          ordinal = i,
          name = gField.getName,
          typeSerialized = "struct",
          typeRuntime = "N/A",
          repetition = gField.getRepetition.name()
        )
        ordinalToSchema += (i -> colDef)
      } else {
        // handle primitives
        val pField = fieldType.asPrimitiveType()

        val typeSer = pField.getPrimitiveTypeName.name()
        val typeRun =
          if (pField.getLogicalTypeAnnotation != null)
            pField.getLogicalTypeAnnotation.toString
          else "NONE"
        val encoding = pField.getOriginalType

        val colDef = ColSchemaMeta(
          ordinal = i,
          name = pField.getName,
          typeSerialized = typeSer,
          typeRuntime = typeRun,
          repetition = pField.getRepetition.name()
        )
        ordinalToSchema += (i -> colDef)
      }
      i = i.+(1)
    }
    SchemaMeta(schemaName = schema.getName, colDefs = ordinalToSchema)
  }

  /** Returns a [[List]] of all row groups in the file.
    *
    * @param pqMeta
    *   An instance of [[ParquetMetadata]].
    * @return
    *   Ordered List of [[RowGroupMeta]].
    */
  def getRowGroupsMeta(file: String, pqMeta: ParquetMetadata): List[RowGroupMeta] = {
    val rowGroups = new ListBuffer[RowGroupMeta]()
    pqMeta.getBlocks.asScala.zipWithIndex.map { case (blockMeta, idx) =>
      val rg: RowGroupMeta = buildRowGroupMeta(file, idx, blockMeta)
      rowGroups += rg
    }

    rowGroups.toList
  }

  /** Retrieves Json, as a string, for any given class. Uses fasterxml library.
    *
    * @param obj
    *   Instance of any class.
    * @param prettyPrint
    *   Prettify JSON. `false` by default.
    * @return
    *   String version of JSON.
    */
  def getMetaJson(obj: Object, prettyPrint: Boolean = false): String = {
    val mapper = new ObjectMapper() with ScalaObjectMapper
    mapper.registerModule(DefaultScalaModule)
    if (prettyPrint) {
      mapper.enable(SerializationFeature.INDENT_OUTPUT)
    }

    mapper.writeValueAsString(obj)
  }

  /** Returns RwoGroupMeta as DataFrame, one row per row group. See [[RowGroupMeta]] for the column names and
    * description.
    *
    * @param parquetFilePaths
    *   Absolute or relative path of the parquet file on ADLS Gen 2 or local file system.
    * @param parallelism
    *   Number of partitions in the returned DataFrame.
    * @return
    *   File [[RowGroupMeta]] as DataFrame, one row per row group.
    */
  def getRowGroupMetaAsDataFrame(parquetFilePaths: Seq[String], parallelism: Int = 2): DataFrame = {
    val files = getFiles(null, Some(parallelism), parquetFilePaths, (_, file) => file.filePath)(
      Encoders.STRING
    )
    logInfo("Retrieving metadata for parquet files: " + files.count)

    val fileMetaDf: DataFrame = files
      .flatMap { file =>
        {
          val hadoopConf         = new Configuration()
          val path               = new Path(file)
          val inputFileStatus    = path.getFileSystem(hadoopConf).getFileStatus(path)
          val DoNotSkipRowGroups = false
          /*
                  configuration – the configuration to access the FS
                  pathStatus – the root dir
                  skipRowGroups – whether to skip reading row group metadata
           */
          val footers: util.List[Footer] =
            ParquetFileReader.readFooters(hadoopConf, inputFileStatus, DoNotSkipRowGroups)
          val temp = footers.asScala.flatMap { footer =>
            footer.getParquetMetadata.getBlocks.asScala.zipWithIndex.map { case (block, idx) =>
              logInfo("building RG metadata for file: " + footer.getFile.toString + " and row group: " + idx)
              val rgm = buildRowGroupMeta(footer.getFile.toString, idx, block)
              rgm
            }
          }
          temp
        }
      }(Encoders.product[RowGroupMeta])
      .toDF()

    fileMetaDf
  }

  private def buildRowGroupMeta(file: String, idx: Int, blockMeta: BlockMetaData): RowGroupMeta = {
    val sizeBeforeCompression = blockMeta.getTotalByteSize
    val sizeAfterCompression  = blockMeta.getCompressedSize
    val reductionPercent      = getReductionPercent(sizeBeforeCompression, sizeAfterCompression)

    // println("blockMeta.getPath: " + blockMeta.getPath) TODO returns null
    // TODO remove var i and use getRowGroupOrdinal

    val rg = RowGroupMeta(
      filePath = file,
      id = Some(idx),
      numColumns = blockMeta.getColumns.size,
      numRows = blockMeta.getRowCount,
      offset = blockMeta.getStartingPos,
      totalUncompressedSize = sizeBeforeCompression,
      totalUncompressedSizeStr = Utils.humanReadableByteSize(sizeBeforeCompression),
      totalCompressedSize = sizeAfterCompression,
      totalCompressedSizeStr = Utils.humanReadableByteSize(sizeAfterCompression),
      sizeReducedByPercent = reductionPercent
    )
    rg
  }

  private def getReductionPercent(sizeBeforeCompression: Long, sizeAfterCompression: Long): Double = {
    val percent = (sizeAfterCompression / sizeBeforeCompression.toDouble) * 100
    val reductionPercent = BigDecimal(100 - percent)
      .setScale(0, BigDecimal.RoundingMode.HALF_UP)
      .toDouble
    reductionPercent
  }

  def getFiles[T: Encoder](
      reader: DataFrameReader,
      parallelism: Option[Int],
      paths: Seq[String],
      fileFunc: (Int, KOFileSplit) => T
  ): Dataset[T] = {
    val encoder = implicitly[Encoder[T]]
    // Scala needs for certain runtime operations such as creating an array of type T at runtime
    implicit val classTag: ClassTag[T] = encoder.clsTag

    val df = SynapseSpark.getActiveSession.read.parquet(paths: _*)
    val files = df.rdd.partitions
      .flatMap(part =>
        part
          .asInstanceOf[FilePartition]
          .files
          .map(file => fileFunc(part.index, KOFileSplit(file)))
      )
      .toSeq
      .distinct

    if (parallelism.isDefined)
      SynapseSpark.getActiveSession.createDataset(files).repartition(parallelism.get)
    else SynapseSpark.getActiveSession.createDataset(files)
  }

  /** Print all available metadata to given output stream.
    *
    * @param parquetFilePath
    *   Absolute or relative path of the parquet file on ADLS Gen 2 or local file system.
    * @param out
    *   Any PrintStream. For e.g. [[System.out]]
    */
  def printParquetMetadata(parquetFilePath: String, out: PrintStream): Unit = {
    val path = new Path(parquetFilePath)

    try {
      val hadoopConf = SynapseSpark.getActiveSession.sparkContext.hadoopConfiguration
      val pqMeta     = ParquetFileReader.readFooter(hadoopConf, path)

      val printer = PrettyPrintWriter.newPrettyPrinter(out).build()
      MetadataUtils.showDetails(printer, pqMeta)
    } catch {
      case ex: Exception =>
        logError("Error while reading Parquet file metadata.", ex)
      case th: Throwable =>
        logError("Fatal error", th)
    }
  }

  /** Returns ColSummaryMeta as DataFrame, one row per-block-column . See [[ColSummaryMeta]] for the column names and
    * description.
    *
    * @param parquetFilePaths
    *   Absolute or relative path of the parquet file on ADLS Gen 2 or local file system.
    * @return
    *   File [[RowGroupMeta]] as DataFrame, one row per row group.
    */
  def getColSummaryMetaAsDataFrame(parquetFilePaths: Seq[String]): DataFrame = {
    val files = getFiles(null, None, parquetFilePaths, (_, file) => file.filePath)(
      Encoders.STRING
    )
    logInfo("Retrieving ColSummaryMeta metadata for parquet files: " + files.count)

    files
      .flatMap { file =>
        val conf            = new Configuration()
        val inputPath       = new Path(file)
        val inputFileStatus = inputPath.getFileSystem(conf).getFileStatus(inputPath)
        val footers         = ParquetFileReader.readFooters(conf, inputFileStatus, false)
        footers.asScala.flatMap { footer =>
          footer.getParquetMetadata.getBlocks.asScala.zipWithIndex.flatMap { case (block, rowGroupIdx) =>
            block.getColumns.asScala.zipWithIndex.map { case (colMeta, colIdx) =>
              buildColSummaryMeta(file, rowGroupIdx, colIdx, colMeta)
            /*(
              footer.getFile.toString,
              idx + 1,
              column.getPath.toSeq,
              column.getCodec.toString,
              column.getPrimitiveType.toString,
              column.getEncodings.asScala.toSeq.map(_.toString).sorted,
              column.getStatistics.minAsString(),
              column.getStatistics.maxAsString(),
              column.getStartingPos,
              column.getTotalSize,
              column.getTotalUncompressedSize,
              column.getValueCount,
              column.getStatistics.getNumNulls,
            )*/
            }
          }
        }
      }(Encoders.product[ColSummaryMeta])
      .toDF()
  }

  /** Another version that works on local env but doesn't work on Azure due to azure customizations.
    *
    * @param parquetFilePath
    *   Absolute or relative path of the parquet file.
    */
  @Beta
  private def printParquetMetadataNonAzure(parquetFilePath: String): Unit = {
    try {
      val path                      = new Path(parquetFilePath)
      val conf                      = new Configuration()
      val hadoopInputFile           = HadoopInputFile.fromPath(path, conf)
      val parquetReadOptions        = HadoopReadOptions.builder(conf).build()
      val reader: ParquetFileReader = ParquetFileReader.open(hadoopInputFile, parquetReadOptions)
      val pqMeta                    = reader.getFooter

      val fileMeta: FileMeta = getFileMeta(path.toString, pqMeta)
      println("File metadata:")
      println(getMetaJson(pqMeta, prettyPrint = true))

      val rowGroupMeta: List[RowGroupMeta] = getRowGroupsMeta(parquetFilePath, pqMeta)
      println("\nRow Group(s) Metadata:")
      println(getMetaJson(rowGroupMeta, prettyPrint = true))

      val schema: SchemaMeta = getSchema(pqMeta)
      println("\nSchema Metadata:")
      println(getMetaJson(schema, prettyPrint = true))

      val colMeta: mutable.SortedMap[Int, ColSummaryMeta] = getColSummaryMeta(parquetFilePath, pqMeta)
      println("\nColumn(s) Metadata:")
      println(getMetaJson(colMeta, prettyPrint = true))

      val colStats: mutable.SortedMap[Int, ColStats] = getColStats(parquetFilePath, pqMeta)
      println("\nColumn Statistics:")
      println(getMetaJson(colStats, prettyPrint = true))
    } catch {
      case ex: Exception =>
        logError("Error while reading Parquet file metadata.", ex)
      case th: Throwable =>
        logError("Fatal error", th)
    }
  }

  /** Description for file metadata.
    *
    * @param filePath
    *   Full path of the parquet file.
    * @param createdBy
    *   String for application that wrote this file. This should be in the format <Application> version <App Version>
    *   (build <App Build Hash>). E.g. parquet-mr version 1.12.3 (build f8dced182c4c1fbdec6ccb3185537b5a01e6ed6b).
    * @param formatVersion
    *   Parquet Version of this file
    * @param numColumns
    *   Number of columns in the parquet file.
    * @param numRows
    *   Number of rows in this file.
    * @param numRowGroups
    *   Number of row groups in this file.
    * @param uncompressedSize
    *   Actual size of the file i.e. before compression.
    * @param uncompressedSizeStr
    *   Human readable version of [[uncompressedSize]].
    * @param compressedSize
    *   On disk size of the file i.e. after compression.
    * @param compressedSizeStr
    *   Human readable version of [[compressedSize]].
    * @param compression
    *   Compression algorithm used. This is a *derived* attribute based on one column. Assumption is that a file uses
    *   only one compression code.
    * @param sizeReducedByPercent
    *   Calculated property representing how much compression/codec has reduced/increased the size.
    * @param customProps
    *   Optional key/value metadata.
    */
  case class FileMeta(
      filePath: String,
      createdBy: String,
      formatVersion: Option[
        String
      ],                 // "1.0" TODO parquet-tools doesn't provide this info out of the box
      numColumns: Int,   // 21
      numRows: Long,     // 3299869
      numRowGroups: Int, // 1
      uncompressedSize: Long,
      uncompressedSizeStr: String,
      compressedSize: Long,        // 4424
      compressedSizeStr: String,   // 77.827 MB
      compression: Option[String], // "SNAPPY"
      sizeReducedByPercent: Double,
      customProps: Map[
        String,
        String
      ] // Custom key value pairs added by compute engines like spark, pandas, polars, pyarrow etc.
  )

  /** Metadata for each column chunk in this row group. This columns must have the same order as the [[SchemaMeta]]
    * list.
    *
    * @param filePath
    *   Full path of the parquet file.
    * @param id
    *   Optional. Row group number.
    * @param numColumns
    *   Number of columns in the row group.
    * @param numRows
    *   Number of rows in this row group.
    * @param offset
    *   The starting pos of first column.
    * @param totalUncompressedSize
    *   Total byte size of all the uncompressed column data in this row group.
    * @param totalUncompressedSizeStr
    *   Human readable version of [[totalUncompressedSize]].
    * @param totalCompressedSize
    *   Total byte size of all the compressed column data in this row group.
    * @param totalCompressedSizeStr
    *   Human readable version of [[totalCompressedSize]].
    * @param sizeReducedByPercent
    *   Calculated property representing how much compression/codec has reduced/increased the size.
    */
  case class RowGroupMeta(
      filePath: String,
      id: Option[Int], // order #, can be used as primary key
      numColumns: Int,
      numRows: Long, // RC (Row Count)
      offset: Long,
      totalUncompressedSize: Long, // TS (Total Size) in bytes
      totalUncompressedSizeStr: String,
      totalCompressedSize: Long,
      totalCompressedSizeStr: String,
      sizeReducedByPercent: Double
  )

  /** @param schemaName
    *   Name of the schema written by the writer.
    * @param colDefs
    *   Ordered and keyed [[ColSchemaMeta]].
    */
  case class SchemaMeta(
      schemaName: String,
      colDefs: SortedMap[Int, ColSchemaMeta]
  )

  /** Represents a element inside a schema definition.
    *   - if it is a group (inner node) then type is undefined and num_children is defined.
    *   - if it is a primitive type (leaf) then type is defined and num_children is undefined. the nodes are listed in
    *     depth first traversal order.
    *
    * Logical types are used to extend the types that parquet can be used to store, by specifying how the primitive
    * types should be interpreted. This keeps the set of primitive types to a minimum and reuses parquet's efficient
    * encodings. For example, strings are stored as byte arrays (binary) with a UTF8 annotation.
    *
    * @param ordinal
    *   Order of the column in the file. Can be used to join with other meta objects.
    * @param name
    *   Name of the column in the schema.
    * @param typeSerialized
    *   Data type for this field. Not set if the current element is a non-leaf node.
    * @param typeRuntime
    *   AKA Logical type (or Converted type). Only valid for primitives. When the schema is the result of a conversion
    *   from another model (runtime data type model of spark pyarrow etc.). Used to record the original type to help
    *   with cross conversion.
    * @param repetition
    *   Repetition of the column. Specifies how many times a column can occur in a record. Can be one of REQUIRED,
    *   OPTIONAL or REPEATED. The root of the schema does not have a repetition_type. All other nodes must have one.
    */
  case class ColSchemaMeta(
      ordinal: Int,           // can be used as primary key
      name: String,           // tpep_pickup_datetime
      typeSerialized: String, // "INT64"
      typeRuntime: String,    // "TIMESTAMP"
      repetition: String      // OPTIONAL, REQUIRED, REPEATED
      // definition: String //1 or REPEATED TODO add definition if needed
  )

  /** @param filePath
    *   Full path of the parquet file.
    * @param id
    *   Order of the column in respective row group. Can be used as the natural key when joining with [[ColStats]] and
    *   [[ColSchemaMeta]].
    * @param rowGroupId
    *   Optional. Order of the row group. Can be used as a foreign key on [[RowGroupMeta]].
    * @param name
    *   Name of the column.
    * @param valueCount
    *   Number of values in this column.
    * @param typeSerialized
    *   Serialized type of the column. For e.g. TIMESTAMP is runtime type while data gets serialized as INT64.
    * @param isStatsSet
    *   Are [[ColStats]] calculated and saved in the file for this column.
    * @param compressionCodec
    *   One of UNCOMPRESSED, SNAPPY, GZIP, LZO, BROTLI, LZ4, ZSTD.
    * @param hasDictionaryPage
    *   `true` when a column chunk/row group is using dictionary encoding.
    * @param totalUncompressedSize
    *   Total byte size of all uncompressed pages in this column chunk (including the headers).
    * @param totalUncompressedSizeStr
    *   Human readable version of [[totalUncompressedSize]].
    * @param totalCompressedSize
    *   Total byte size of all compressed pages in this column chunk (including the headers).
    * @param totalCompressedSizeStr
    *   Human readable version of [[totalCompressedSize]].
    * @param sizeReducedByPercent
    *   Calculated property representing how much compression/codec has reduced/increased the size.
    * @param encodings
    *   Set of all encodings used for this column. The purpose is to validate whether we can decode those pages.
    * @param dataPageOffset
    *   Byte offset from beginning of file to first data page.
    * @param indexPageOffset
    *   Byte offset from beginning of file to root index page. Added since parquet format version 2.5.
    * @param dictPageOffset
    *   Byte offset from the beginning of file to first (only) dictionary page.
    * @param customProps
    *   Optional key/value metadata.
    */
  case class ColSummaryMeta(
      filePath: String,
      id: Int,                 // can be used as primary key
      rowGroupId: Option[Int], // cab be used as foreign key to row group
      name: String,            // "VendorID"
      valueCount: Long,
      typeSerialized: String,             // "INT64"
      isStatsSet: Boolean,                // true
      compressionCodec: String,           // "GZIP"
      hasDictionaryPage: Option[Boolean], // true
      totalUncompressedSize: Long,        // 462414
      totalUncompressedSizeStr: String,
      totalCompressedSize: Long, // 345647
      totalCompressedSizeStr: String,
      sizeReducedByPercent: Double,
      encodings: String,
      dataPageOffset: Long,
      indexPageOffset: Option[Long], // Added since parquet format version 2.5
      dictPageOffset: Long,
      customProps: Option[
        Map[String, String]
      ] // Custom key value pairs added by compute engines like spark, pandas, polars, pyarrow etc.
  )

  /** Statistics are stored per row group and per page. All fields are optional.
    *
    * @param filePath
    *   Full path of the parquet file.
    * @param id
    *   Order of the column in respective row group. Can be used as the natural key when joining with [[ColSummaryMeta]]
    *   and [[ColSchemaMeta]].
    * @param rowGroupId
    *   Optional. Order of the row group. Can be used as a foreign key on [[RowGroupMeta]].
    * @param name
    *   Name of the column.
    * @param typeSerialized
    *   Serialized type of the column. For e.g. TIMESTAMP is runtime type while data gets serialized as INT64.
    * @param typeRuntime
    *   AKA Logical type (or Converted type). Only valid for primitives. When the schema is the result of a conversion
    *   from another model (runtime data type model of spark pyarrow etc.). Used to record the original type to help
    *   with cross conversion.
    * @param hasStats
    *   `true` when the column has statistics available.
    * @param hasMinMax
    *   `true` when the column has [[min]] and [[max]] available.
    * @param min
    *   Min values for the column.
    * @param max
    *   Max values for the column.
    * @param hasNullCount
    *   If [[nullCount]] is available in stats for the column.
    * @param nullCount
    *   count of null values in the column
    * @param distinctCount
    *   count of distinct values occurring
    * @param numValues
    *   Number of values in this column
    */
  case class ColStats(
      filePath: String,
      id: Int,
      rowGroupId: Option[Int],
      name: String,           // VendorID
      typeSerialized: String, // INT64"
      typeRuntime: String,    // NONE"
      hasStats: Boolean,
      hasMinMax: Boolean, // true
      min: Option[String],
      max: Option[String],
      hasNullCount: Boolean,
      nullCount: Long,
      distinctCount: Long,
      numValues: Long
  )
}