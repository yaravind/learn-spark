package com.tccc.dna.synapse.spark.test

import com.github.mrpowers.spark.fast.tests.DatasetComparer
import com.tccc.dna.synapse.Logging
import com.google.common.io.Resources
import org.apache.commons.io.FileUtils
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Row}
import org.scalatest._
import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.should.Matchers

import java.nio.charset.StandardCharsets
import java.nio.file.{Files, Path, Paths}
import scala.Console.println
import scala.collection.mutable

/**
 * Base class for all spark based integration tests. A [[org.apache.spark.sql.SparkSession]] instance is
 * ''lazily instantiated'' for each TestSuite.
 */
abstract class SparkTestBaseSpec extends AnyFunSuite
  //with DataFrameSuiteBase
  with SparkSessionTestWrapper with DatasetComparer
  with Logging
  with Matchers with OptionValues with Inside with Inspectors with BeforeAndAfterAll {
  protected val TempDirName: String = getClass.getSimpleName
  private val configMap: mutable.Map[String, Path] = mutable.Map.empty

  override protected def beforeAll(): Unit = {
    println("beforeAll spark.hashCode: " + spark.hashCode())
    logInfo("beforeAll spark.isStopped: " + spark.sparkContext.isStopped)
    logInfo("spark.isLocal: " + spark.sparkContext.isLocal)
    logInfo("Spark version: " + spark.version)
    logInfo("Delta format version: " + io.delta.VERSION)
    logInfo("Catalog/Metastore type: " + spark.conf.get("spark.sql.catalogImplementation"))
    logInfo("Spark warehouse location: " + spark.conf.get("spark.sql.warehouse.dir"))

    val tempDir = Files.createTempDirectory(getClass.getSimpleName)
    println("Created temporary directory = " + tempDir)
    configMap.put(TempDirName, tempDir)
  }

  override protected def afterAll: Unit = {
    println("afterAll spark.hashCode: " + spark.hashCode())
    spark.stop()
    logInfo("afterAll spark.isStopped: " + spark.sparkContext.isStopped)

    println(s"deleting: ${configMap(TempDirName)}")
    FileUtils.deleteDirectory(configMap(TempDirName).toFile)
  }

  /**
   * You cannot hardcode the directory names in test cases as they need to be portable. Use this method to get the absolute temporary path
   * for the given file name. A temporary directory is created for every test class. For e.g. if the test class is `SynapseSparkTest`, then
   * the temp directory name would be `/var/folders/zg/sjb40vb10517ytzt5z56q96jxz65ch/T/SynapseSparkTest6189131247630551103`. It is created
   * under the '''var''' folder on unix and macOS. The full file path is equal to `temp_directory_name + "/" + fileName`.
   *
   * @param fileName Name of the file to be created under temporary directory.
   * @return Full path for the temporary file.
   */
  protected def getTempFilePath(fileName: String): String = {
    osAwareFilename(Paths.get(getTempDirPath), fileName)
  }

  /**
   * Absolute path of the temporary directory created for this test case.
   *
   * @return Absolute path of temporary directory.
   */
  protected def getTempDirPath: String = {
    configMap(TempDirName).toString
  }

  /**
   * Get the absolute path of a classpath resource. Use this to make tests portable. If you have a file `file.txt` in
   * `src/main/resources/folder1/file.txt` then pass `folder1/file.txt`.
   *
   * @param resourceName Relative path of the file on classpath: '''src/main/resources''' or '''src/test/resources'''.
   * @return Absolute path of the resource.
   */
  protected def getAbsolutePathOfResource(resourceName: String): String = {
    val res = Resources.getResource(resourceName)
    Paths.get(res.toURI).toFile().toString
  }

  /**
   * Get the contents of a file as String. Use this to read files, that are on classpath () as String.
   *
   * @param resourceName Relative path of the file on classpath: '''src/main/resources''' or '''src/test/resources'''.
   * @return Content of the file as [[String]].
   */
  protected def getResourceAsString(resourceName: String): String = {
    val url = Resources.getResource(resourceName)
    Resources.toString(url, StandardCharsets.UTF_8)
  }

  /**
   * Get the absolute path of a a given relative path. Use this to make tests portable. For example, if you want the absolute path of
   * `src/main/resources`, then you call `getAbsolutePath("src/main/resources")`.
   *
   * @param relativePath Relative path of the folder: '''src/main/resources''' or '''src/test/resources'''.
   * @return Absolute path of the folder.
   */
  protected def getAbsolutePath(relativePath: String): String = {
    Paths.get(relativePath).toAbsolutePath.toString
  }

  protected def createTimestamp(date: java.util.Date): java.sql.Timestamp = {
    val calendar = java.util.Calendar.getInstance()
    calendar.setTime(date)
    calendar.set(java.util.Calendar.HOUR_OF_DAY, 0)
    calendar.set(java.util.Calendar.MINUTE, 0)
    calendar.set(java.util.Calendar.SECOND, 0)
    calendar.set(java.util.Calendar.MILLISECOND, 0)
    val timestamp = new java.sql.Timestamp(calendar.getTimeInMillis)
    timestamp
  }

  protected def show(df: DataFrame): Unit = df.show(numRows = 15, truncate = false)

  protected def createDataframeFromCollection(schema: StructType, data: Seq[Row]): DataFrame = {
    spark.createDataFrame(spark.sparkContext.parallelize(data), schema)
  }

  protected def osAwareFilename(inputPath: Path, filename: String): String = {
    if (System.getProperty("os.name").contains("Windows")) {
      inputPath.toFile.getPath + "\\" + filename
    } else {
      inputPath.toFile.getPath + "/" + filename
    }
  }
}