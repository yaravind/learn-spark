package com.tccc.dna.synapse.spark

import org.apache.spark.sql.types.{ArrayType, BooleanType, IntegerType, StringType, StructField, StructType}

object Ddl {
  def createExternalTable(): Unit = {

  }

  private val Mandatory = false //nullable = false
  private val Optional = true //nullable = true
  /**
   * Schema for JSON Validation output [[org.apache.spark.sql.DataFrame]]. Return type for [[DataFrames.loadAndValidateJsonV2()]].
   */
  val jsonValidatorResultSchema: StructType = StructType(
    Array(
      StructField("input", StringType, Mandatory),
      StructField("is_valid", BooleanType, Mandatory),
      StructField("error_count", IntegerType, Mandatory),
      StructField("error_list", ArrayType(
        StructType(Array(
          StructField("pointer", StringType, Optional),
          StructField("keyword", StringType, Optional),
          StructField("message", StringType, Optional),
          StructField("required", ArrayType(StringType, Optional), Optional),
          StructField("missing", ArrayType(StringType, Optional), Optional),
          StructField("found", StringType, Optional),
          StructField("expected", ArrayType(StringType, Optional), Optional)
        ))
      ), Optional),
      StructField("input_file_path", StringType, Optional)
    )
  )
}