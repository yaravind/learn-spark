package com.tccc.dna.synapse

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import org.apache.logging.log4j.{LogManager, Logger}

import java.io.{PrintWriter, StringWriter}

/**
 *
 * This is strip down version of spark internal logging
 *
 * Utility trait for classes that want to log data. Auto creates a Log4j logger for the class and allows
 * logging messages at different levels.
 *
 * @see Refer [[https://wiki.coke.com/confluence/x/u66lD Platform and Application Monitoring]] for more details.
 */
trait Logging {
  private val objectMapper = {
    val mapper = new ObjectMapper()
    mapper.registerModule(DefaultScalaModule)
    mapper
  }
  // Make the log field transient so that objects with Logging can
  // be serialized and used on another machine
  @transient private var log_ : Logger = _

  // Method to get the logger name for this object
  protected def logName: String = {
    // Ignore trailing $'s in the class names for Scala objects
    this.getClass.getName.stripSuffix("$")
  }

  // Method to get or create the logger for this object
  protected def log: Logger = {
    if (log_ == null) {
      log_ = LogManager.getLogger(logName)
    }
    log_
  }

  def convertMapToJson(data: Map[String, Any]): String = {
    objectMapper.writeValueAsString(data)
  }

  // Log methods that take only a String
  protected def logInfo(msg: => String, logToNotebook: Boolean = false): Unit = {
    if (log.isInfoEnabled) {
      log.info(msg)
      if (logToNotebook) println(msg)
    }
  }

  protected def logDebug(msg: => String, logToNotebook: Boolean = false): Unit = {
    if (log.isDebugEnabled) {
      log.debug(msg)
      if (logToNotebook) println(msg)
    }
  }

  protected def logTrace(msg: => String, logToNotebook: Boolean = false): Unit = {
    if (log.isTraceEnabled) {
      log.trace(msg)
      if (logToNotebook) println(msg)
    }
  }

  protected def logWarning(msg: => String, logToNotebook: Boolean = false): Unit = {
    log.warn(msg)
    if (logToNotebook) println(msg)
  }

  protected def logError(msg: => String, logToNotebook: Boolean = false): Unit = {
    log.error(msg)
    if (logToNotebook) println(msg)
  }

  // Log methods that take Throwables (Exceptions/Errors) too
  protected def logInfo(msg: => String, throwable: Throwable): Unit = {
    if (log.isInfoEnabled) {
      log.info(msg, throwable)
      println(msg)
      throwable.printStackTrace()
    }
  }

  protected def logDebug(msg: => String, throwable: Throwable): Unit = {
    if (log.isDebugEnabled) {
      log.debug(msg, throwable)
      println(msg)
      throwable.printStackTrace()
    }
  }

  protected def logTrace(msg: => String, throwable: Throwable): Unit = {
    if (log.isTraceEnabled) {
      log.trace(msg, throwable)
      println(msg)
      throwable.printStackTrace()
    }
  }


  protected def logWarning(msg: => String, throwable: Throwable): Unit = {
    log.warn(msg, throwable)
    println(msg)
    throwable.printStackTrace()
  }

  protected def logError(msg: => String, throwable: Throwable): Unit = {
    log.error(msg, throwable)
    println(msg)
    throwable.printStackTrace()
  }

  protected def isTraceEnabled: Boolean = {
    log.isTraceEnabled
  }

  /**
   * Return a nice string representation of the exception. It will call "printStackTrace" to
   * recursively generate the stack trace including the exception and its causes.
   */
  def exceptionString(e: Throwable): String = {
    if (e == null) {
      ""
    } else {
      // Use e.printStackTrace here because e.getStackTrace doesn't include the cause
      val stringWriter = new StringWriter()
      e.printStackTrace(new PrintWriter(stringWriter))
      stringWriter.toString
    }
  }

  /**
   * Get Error Cause for the throwable with custom error message and toggle to enable trace
   *
   * @param ex          Throwable Error
   * @param errorMsg    Custom Error Message
   * @param enableTrace Enable to get Full StackTrace string
   * @return
   */
  def getErrorCause(ex: Throwable, errorMsg: String, enableTrace: Boolean): String = {
    if (enableTrace) {
      errorMsg + ": " + exceptionString(ex)
    } else {
      errorMsg + ": " + ex.getMessage
    }
  }

  protected def logDataZoneEvent(dataZone: DataZone, status: String, message: String): Unit = {
    val json = convertMapToJson(
      Map(
        "eventType" -> "DataZoneEvent",
        "dataZone" -> dataZone.name,
        "dataZone.status" -> status,
        "message" -> message
      )
    )
    logInfo(json)
  }

  protected def logEntityJourneyEvent(entityName: String, dataZone: DataZone, zoneSubStep: String, message: String): Unit = {
    val json = convertMapToJson(
      Map(
        "eventType" -> "EntityJourneyEvent",
        "dataZone" -> dataZone.name,
        "zoneSubStep" -> zoneSubStep,
        "entityName" -> entityName,
        "message" -> message
      )
    )
    logInfo(json)
  }

  protected def logEntityJourneyError(entityName: String, dataZone: DataZone, zoneSubStep: String, message: String, ex: Throwable): Unit = {
    val json = convertMapToJson(
      Map(
        "eventType" -> "EntityJourneyEvent",
        "dataZone" -> dataZone.name,
        "zoneSubStep" -> zoneSubStep,
        "entityName" -> entityName,
        "message" -> message
      )
    )
    logError(json, ex)
  }

  protected def logEntityJourneyError(entityName: String, dataZone: DataZone, zoneSubStep: String, message: String = ""): Unit = {
    val json = convertMapToJson(
      Map(
        "eventType" -> "EntityJourneyEvent",
        "dataZone" -> dataZone.name,
        "zoneSubStep" -> zoneSubStep,
        "entityName" -> entityName,
        "message" -> message
      )
    )
    logError(json)
  }

  protected def logFileProcessingEvent(fileName: String, dataZone: DataZone, entityName: String, message: String): Unit = {
    val json = convertMapToJson(
      Map(
        "eventType" -> "FileProcessingEvent",
        "dataZone" -> dataZone.name,
        "entityName" -> entityName,
        "fileName" -> fileName,
        "message" -> message
      )
    )
    logInfo(json)
  }

  protected def logFileProcessingEvent(fileName: String, dataZone: DataZone, zoneSubStep: String, entityName: String, message: String): Unit = {
    val json = convertMapToJson(
      Map(
        "eventType" -> "FileProcessingEvent",
        "dataZone" -> dataZone.name,
        "zoneSubStep" -> zoneSubStep,
        "entityName" -> entityName,
        "fileName" -> fileName,
        "message" -> message
      )
    )
    logInfo(json)
  }
}