package com.tccc.dna.synapse.spark

import com.microsoft.spark.notebook.msutils.MSFileInfo
import com.tccc.dna.datazones.{DbManager, JdbcAuditRepository}
import com.tccc.dna.synapse.AzStorage._
import com.tccc.dna.synapse.{DataZone, Logging}
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import com.tccc.dna.synapse.spark.{SynapseSpark => SS}

/** *
 * Use this as base class for all Synapse Spark Jobs. It contains a strip down version of spark internal logging
 *
 * <p>
 * <b>Logging: </b>
 * Creates a Log4j logger for the class and allows logging messages at different levels using methods that only evaluate
 * parameters lazily if the log level is enabled.
 * </p>
 */
abstract class SynapseSparkBase extends App with Logging {
  private val DbMgr = DbManager(dbName = "appmetadata")
  private val AuditRepo = new JdbcAuditRepository(dbManager = DbMgr)

  protected def getAuditRepository = AuditRepo

  def getSparkSession(appName: String, clusterCfg: Option[String]): SparkSession = {
    /*
    We could alternatively use SynapseSpark.isLocalEnv but we still need user to submit the clusterCfg specifying
    number of cores
     */
    val spark = clusterCfg match {
      case Some(cfg) =>
        // Create spark session for local run. Someone specified "local[x]" as program argument
        SparkSession.builder()
          .appName(appName)
          //Can't assign requested address: Service 'sparkDriver' failed after 16 retries (on a random free port)!
          // Consider explicitly setting the appropriate binding address for the service 'sparkDriver'
          // (for example spark.driver.bindAddress for SparkDriver) to the correct binding address.
          .config("spark.driver.bindAddress", "127.0.0.1")
          .config("spark.driver.host", "localhost")
          // Adding these 2 config to work with delta table.
          .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
          .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
          .master(cfg)
          .getOrCreate()
      case None =>
        //Use it during production run
        SparkSession.builder()
          .appName(appName)
          .master("local[2]")
          .getOrCreate()
    }
    spark
  }

  def getClusterCfg(args: Array[String]): Option[String] = {
    if (!args.isEmpty) {
      //If the program args list contains local or local[n] or local[*] return that otherwise None
      val filtered: Array[String] = args.filter(e => e.contains("local"))
      if (filtered.length == 1) Some(filtered(0)) else None
    } else None
  }

  /**
   * Collects all files and folders of the given path and sub-folders recursively and creates a Spark DataFrame to
   * enable querying and pretty print using Notebook's '''display()''' method.
   *
   * @param rootStr initial directory to start the listing from
   * @param spark   an instance of [[SparkSession]] used to create a [[DataFrame]]
   * @return a Spark [[DataFrame]] with columns '''name, path, size, isDir, isFile'''
   * @example {{{val rootStr = "abfss://container@storage-account.net/data/v1"
   *val fileDf = toDataFrame(rootStr, spark)}}}
   */
  def toDataFrame(rootStr: String, spark: SparkSession): DataFrame = {
    val root = MSFileInfo(name = null, path = rootStr, size = 0, isDir = true, isFile = false, modifyTime = System.currentTimeMillis)
    val files = deepLs(root)

    // sc.parallelize() method creates a distributed and parallelized dataset on existing collection on the "driver"
    val fileDf = spark.createDataFrame(spark.sparkContext.parallelize(files))
    fileDf
  }

  //TODO - AUDIT - Write Spark Environment Variables

  /**
   * getPipelineBridgeTableLog Method
   * etc.
   */

  /**
   * Structured log for all Pipeline, Activity and SJD related variables required to correlate end-to-end execution (Pipeline -> Activity -> SJD/Notebook)
   * using KQL in Log Analytics.
   *
   * Information captured include the following:
   * <ul>
   * <li>MessageType - Type of JSON Structure for Logging</li>
   * <li>PipelineRunID</li>
   * <li>PipelineActivityRunID</li>
   * <li>SparkAppID</li>
   * <li>SparkAppName</li>
   * <li>ApplicationName  Name of the application passed as `appName` function param to this function.</li>
   * <li>LivyID</li>
   * </ul>
   *
   * @param appName User provided name of the spark application.
   */
  protected def logPipelineBridgeEvent(appName: String): Unit = {
    val json = convertMapToJson(Map(
      "eventType" -> "PipelineBridgeTableEvent",
      "pipelineRunID" -> SS.getCurrentPipelineRunId, //9346c85c-df5a-46b9-a0bf-e09cf2c0a4ad
      "pipelineActivityRunID" -> SS.getCurrentPipelineActivityRunId, //87957320-f4bf-4b84-a7d5-5cd2d790d9dd
      "sparkAppID" -> SS.getCurrentSparkAppId, //application_1706373986891_0001
      "sparkAppName" -> SS.getCurrentSparkAppName, //01-SparkConf_mediasparkpool_1706373865
      "LivyID" -> SS.getLivySessionId,
      "applicationName" -> appName,
    ))
    logInfo(json)
  }
}