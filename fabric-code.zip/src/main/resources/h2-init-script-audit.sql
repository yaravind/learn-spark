SET MODE MSSQLServer;
CREATE SCHEMA IF NOT EXISTS [sch_ops];
SET SCHEMA [sch_ops];
CREATE TABLE [sch_ops].[audit]
(
    audit_id                    int IDENTITY NOT NULL,
    app_cd                      varchar(10)  NULL,
    sub_app_cd                  varchar(100) NULL,
    artifact_typ                varchar(30)  NULL,
    artifact_id                 varchar(100) NULL,
    data_zone                   varchar(30)  NULL,
    action_typ                  varchar(30)  NULL,
    total_files_to_be_Processed int          NULL,
    total_rows                  int          NULL,
    total_cols                  int          NULL,
    create_timestamp            timestamp    NULL,
    create_user_id              varchar(100) NULL
);